package com.o2dialer.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.CallLog
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.o2dialer.app.core.data.Store
import com.o2dialer.app.core.domain.campaign.CampaignEngine
import com.o2dialer.app.core.domain.campaign.CampaignEngine.Action
import com.o2dialer.app.core.domain.model.CampaignPhase

/**
 * Android execution adapter for the campaign engine.
 *
 * The service deliberately contains OS/telephony concerns only. Queue order,
 * retries, campaign position and recovery state live in CampaignEngine and its
 * persisted runtime journal.
 */
class DialerService : Service() {

    companion object {
        const val ACT_START = "start"
        const val ACT_STOP = "stop"
        const val ACT_PAUSE = "pause"
        const val ACT_RESUME = "resume"
        const val ACT_SKIP = "skip"
        const val ACT_STAGE_DONE = "stage_done"

        fun send(ctx: Context, action: String, listId: String? = null, restart: Boolean = false) {
            val i = Intent(ctx, DialerService::class.java).setAction(action)
            if (listId != null) i.putExtra("list", listId)
            i.putExtra("restart", restart)
            // All campaign controls can legitimately wake the foreground execution
            // adapter after a process restart. The service immediately enters FGS.
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val S: Cfg get() = Store.cfg
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var engine: CampaignEngine
    private lateinit var tm: TelephonyManager
    private lateinit var telecom: TelecomManager

    private var listId = ""
    private var curId: String? = null
    private var callStart = 0L
    private var offhookAt = 0L
    private var sawOffhook = false
    private var running = false
    private var paused = false
    private var awaiting = false
    private var modernCb: Any? = null
    private var legacyCb: PhoneStateListener? = null
    private var wake: PowerManager.WakeLock? = null

    private val nextRunnable = Runnable { dispatchNext() }
    private val noCallRunnable = Runnable { onNoCall() }
    private val hangupRunnable = Runnable { hangup() }
    private val audioRunnable = Runnable {
        if (sawOffhook && (S.autoSpeaker || S.autoMuteMic)) applyAudio(true)
    }

    override fun onCreate() {
        super.onCreate()
        tm = getSystemService(TelephonyManager::class.java)
        telecom = getSystemService(TelecomManager::class.java)
        engine = CampaignEngine(config = { Store.cfg })
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        when (intent?.action) {
            ACT_START -> {
                if (!running) {
                    startCampaign(
                        intent.getStringExtra("list") ?: "",
                        intent.getBooleanExtra("restart", false)
                    )
                }
            }
            ACT_STOP -> if (running || Store.campActive()) finish(
                T("Campaign stopped", "تم إيقاف الحملة")
            ) else stopSelf()
            ACT_PAUSE -> pause()
            ACT_RESUME -> resume()
            ACT_SKIP -> skipCurrent()
            ACT_STAGE_DONE -> stageDone()
            else -> recoverIfNeeded()
        }
        return START_STICKY
    }

    // -------------------------------------------------------------------------
    // Campaign lifecycle
    // -------------------------------------------------------------------------

    private fun startCampaign(id: String, restart: Boolean) {
        val requested = Store.lists.find { it.id == id }
        if (requested == null || requested.entries.isEmpty()) {
            finish(T("The campaign is empty", "الحملة فارغة"), false, true)
            return
        }

        // Never rebuild an existing session unless the caller explicitly asked for restart.
        if (!restart && Store.campActive() && Store.camp.listId == id) {
            recoverIfNeeded()
            return
        }

        listId = id
        running = true
        paused = false
        awaiting = false
        curId = null
        sawOffhook = false
        acquireWake()

        if (restart) Store.resetForRestart(id, S.skipAnswered)

        val list = Store.lists.find { it.id == id } ?: run {
            finish(T("Campaign disappeared", "الحملة غير موجودة"), false, true)
            return
        }

        val action = engine.start(list, restart = restart)
        registerOrFail()
        if (!running) return

        upd(engine.snapshot(
            status = CS.RUNNING,
            listName = list.name,
            currentName = "",
            currentNumber = "",
            message = T("Starting in", "تبدأ بعد"),
            error = false
        ).copy(
            nextAt = System.currentTimeMillis() + S.startCountdown * 1000L,
            currentPhase = CampaignPhase.COUNTDOWN
        ))

        handler.removeCallbacks(nextRunnable)
        handler.postDelayed(nextRunnable, S.startCountdown * 1000L)

        if (action is Action.Completed) finish(
            T("Nothing left to call", "لا توجد أرقام متبقية للاتصال"), true
        )
    }

    /**
     * Rehydrates the exact persisted execution journal after process/service loss.
     * No queue is rebuilt from contact status here.
     */
    private fun recoverIfNeeded() {
        val persisted = Store.camp
        if (!Store.campActive() && persisted.status != CS.RUNNING &&
            persisted.status != CS.PAUSED && persisted.status != CS.WAITING
        ) {
            stopSelf()
            return
        }

        val id = persisted.listId
        val list = Store.lists.find { it.id == id }
        if (list == null) {
            finish(T("Saved campaign could not be found", "تعذر العثور على الحملة المحفوظة"), false, true)
            return
        }

        listId = id
        running = true
        paused = persisted.status == CS.PAUSED
        awaiting = persisted.awaitingStage
        acquireWake()
        registerOrFail()
        if (!running) return

        val action = engine.restore(list, persisted)

        // Resolve a journaled CALLING claim against actual phone state before
        // deciding whether to place the call again.
        if (persisted.currentEntryId != null && persisted.currentPhase == CampaignPhase.CALLING) {
            val active = tm.callState == TelephonyManager.CALL_STATE_OFFHOOK
            val recovery = engine.recoverInterruptedCall(active)
            when (recovery) {
                is Action.RecoverActiveCall -> bindRecoveredActiveCall(recovery.entry)
                is Action.Wait -> Unit
                is Action.Failed -> {
                    finish(recovery.message, false, true)
                    return
                }
                else -> Unit
            }
            checkpoint(
                status = if (paused) CS.PAUSED else CS.RUNNING,
                message = T(
                    if (active) "Recovered active call" else "Recovered campaign",
                    if (active) "تم استرداد المكالمة الحالية" else "تم استرداد الحملة"
                )
            )
        }

        when {
            paused -> {
                upd(Store.camp.copy(
                    status = CS.PAUSED,
                    message = T("Paused — ready to resume", "متوقفة مؤقتًا — جاهزة للاستئناف")
                ))
            }
            awaiting -> {
                upd(Store.camp.copy(status = CS.RUNNING))
                scheduleStageWait()
            }
            action is Action.Completed -> finish(
                T("Campaign completed ✓", "اكتملت الحملة ✓"), true
            )
            else -> scheduleFromPersisted()
        }
    }

    private fun registerOrFail() {
        try {
            register()
        } catch (_: SecurityException) {
            finish(T("Phone-state permission is missing", "صلاحية حالة الهاتف غير ممنوحة"), false, true)
        }
    }

    private fun dispatchNext() {
        if (!running || paused) return
        if (awaiting) return

        if (!engine.inQuietWindow()) {
            val list = Store.lists.find { it.id == listId }
            engine.setNextAt(System.currentTimeMillis() + 30_000L)
            checkpoint(
                status = CS.WAITING,
                listName = list?.name.orEmpty(),
                message = T(
                    "Outside allowed hours — waiting until ${S.quietFrom}:00",
                    "خارج ساعات السماح — الانتظار حتى ${S.quietFrom}:00"
                )
            )
            handler.postDelayed(nextRunnable, 30_000)
            return
        }

        val action = engine.next()
        when (action) {
            is Action.PlaceCall -> place(action.entry)
            is Action.RecoverActiveCall -> bindRecoveredActiveCall(action.entry)
            Action.Wait -> scheduleNextDelay()
            Action.WaitForStage -> scheduleStageWait()
            Action.Completed -> finish(T("Campaign completed ✓", "اكتملت الحملة ✓"), true)
            is Action.Failed -> finish(action.message, false, true)
        }
    }

    private fun scheduleFromPersisted() {
        val now = System.currentTimeMillis()
        val at = Store.camp.nextAt
        val delay = if (at > now) at - now else 0L
        if (delay > 0) {
            handler.removeCallbacks(nextRunnable)
            handler.postDelayed(nextRunnable, delay)
        } else {
            dispatchNext()
        }
    }

    private fun scheduleNextDelay() {
        if (!running) return
        if (paused) {
            checkpoint(CS.PAUSED, T("Paused", "متوقفة مؤقتًا"))
            return
        }
        if (awaiting) {
            scheduleStageWait()
            return
        }

        val sec = engine.nextDelaySeconds()
        val at = System.currentTimeMillis() + sec * 1000L
        engine.setNextAt(at)
        val list = Store.lists.find { it.id == listId }
        checkpoint(
            status = CS.RUNNING,
            listName = list?.name.orEmpty(),
            message = T("Next call in", "الاتصال التالي بعد")
        )
        handler.removeCallbacks(nextRunnable)
        handler.postDelayed(nextRunnable, sec * 1000L)
    }

    private fun scheduleStageWait() {
        if (!running) return
        awaiting = true
        val ms = S.stageWaitSec.coerceAtLeast(0) * 1000L
        val at = System.currentTimeMillis() + ms
        engine.setNextAt(at)
        val list = Store.lists.find { it.id == listId }
        checkpoint(
            status = CS.RUNNING,
            listName = list?.name.orEmpty(),
            message = T("Choose the call result", "اختر نتيجة المكالمة")
        )
        handler.removeCallbacks(nextRunnable)
        if (ms == 0L) stageDone()
        else handler.postDelayed(nextRunnable, ms)
    }

    // -------------------------------------------------------------------------
    // Telephony execution adapter
    // -------------------------------------------------------------------------

    private fun simHandle(slot: Int) =
        if (slot < 0) null else telecom.callCapablePhoneAccounts.getOrNull(slot)

    private fun place(entry: Entry) {
        val list = Store.lists.find { it.id == listId }
        if (list == null) {
            finish(T("Campaign list unavailable", "قائمة الحملة غير متاحة"), false, true)
            return
        }

        if (entry.number.filter(Char::isDigit).length < 3) {
            record(entry.id, St.FAILED, 0, T("Invalid number", "رقم غير صالح"))
            return
        }

        if (list.simSlot >= 0 && simHandle(list.simSlot) == null) {
            record(entry.id, St.FAILED, 0, T("Selected SIM is unavailable", "الشريحة المحددة غير متاحة"))
            return
        }

        curId = entry.id
        sawOffhook = false
        callStart = System.currentTimeMillis()
        offhookAt = 0L

        // Persist contact ownership BEFORE the irreversible call.
        Store.updateEntry(listId, entry.id) {
            it.copy(status = St.CALLING, attempts = it.attempts + 1)
        }
        engine.markCallStarted(entry.id, callStart)

        checkpoint(
            status = CS.RUNNING,
            listName = list.name,
            currentName = entry.name,
            currentNumber = entry.number,
            message = T("Calling…", "جارٍ الاتصال…")
        )

        try {
            val extras = Bundle()
            simHandle(list.simSlot)?.let {
                extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it)
            }
            telecom.placeCall(
                Uri.fromParts("tel", smartNumber(entry.number, Store.defaultCc()), null),
                extras
            )
            handler.removeCallbacks(noCallRunnable)
            handler.postDelayed(noCallRunnable, 25_000)
        } catch (_: SecurityException) {
            finish(T("Call permission is missing", "صلاحية الاتصال غير ممنوحة"), false, true)
        } catch (_: IllegalArgumentException) {
            record(entry.id, St.FAILED, 0, T("Invalid number", "رقم غير صالح"))
        } catch (_: Exception) {
            record(entry.id, St.FAILED, 0, T("Call could not be placed", "تعذر إجراء المكالمة"))
        }
    }

    private fun bindRecoveredActiveCall(entry: Entry) {
        curId = entry.id
        callStart = engine.snapshot(
            status = CS.RUNNING, listName = Store.lists.find { it.id == listId }?.name.orEmpty(),
            currentName = entry.name, currentNumber = entry.number,
            message = T("Recovered active call", "تم استرداد المكالمة الحالية")
        ).callStartedAt.takeIf { it > 0 } ?: System.currentTimeMillis()
        offhookAt = engine.snapshot(
            status = CS.RUNNING, listName = "", currentName = "", currentNumber = "", message = ""
        ).offhookAt.takeIf { it > 0 } ?: callStart
        sawOffhook = true
        handler.removeCallbacks(noCallRunnable)
        if (S.maxCallSec > 0) {
            val elapsed = ((System.currentTimeMillis() - offhookAt) / 1000L).coerceAtLeast(0)
            val remaining = (S.maxCallSec - elapsed).coerceAtLeast(0)
            handler.postDelayed(hangupRunnable, remaining * 1000L)
        }
    }

    private fun onState(state: Int) {
        if (!running) return

        if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (curId != null && !sawOffhook) {
                sawOffhook = true
                offhookAt = System.currentTimeMillis()
                engine.markOffhook(offhookAt)
                handler.removeCallbacks(noCallRunnable)
                checkpoint(
                    status = if (paused) CS.PAUSED else CS.RUNNING,
                    message = T("Call connected", "تم الاتصال")
                )
                if (S.maxCallSec > 0) {
                    handler.postDelayed(hangupRunnable, S.maxCallSec * 1000L)
                }
                if (S.autoSpeaker) {
                    handler.postDelayed(audioRunnable, 400)
                    handler.postDelayed(audioRunnable, 1500)
                    handler.postDelayed(audioRunnable, 3500)
                }
            }
        } else if (state == TelephonyManager.CALL_STATE_IDLE && sawOffhook && curId != null) {
            sawOffhook = false
            handler.removeCallbacks(hangupRunnable)
            handler.removeCallbacks(audioRunnable)
            if (S.autoSpeaker || S.autoMuteMic) applyAudio(false)

            val id = curId!!
            curId = null
            val dur = ((System.currentTimeMillis() - offhookAt) / 1000).toInt()
            val since = if (callStart > 0) callStart else System.currentTimeMillis()
            handler.postDelayed({ evaluate(id, since, dur, 0) }, 1500)
        }
    }

    private fun onNoCall() {
        val id = curId ?: return
        if (sawOffhook) return
        curId = null
        record(id, St.FAILED, 0, T("No call state was observed", "لم يتم رصد حالة اتصال"))
    }

    private fun evaluate(id: String, since: Long, dur: Int, tries: Int) {
        if (!running) return
        if (S.useCallLog && has(Manifest.permission.READ_CALL_LOG)) {
            val d = queryLog(since)
            if (d == null && tries < 2) {
                handler.postDelayed({ evaluate(id, since, dur, tries + 1) }, 1500)
                return
            }
            if (d != null) {
                record(id, if (d > 0) St.ANSWERED else St.NO_ANSWER, d, "")
                return
            }
        }
        record(id, St.DONE, dur, "")
    }

    private fun queryLog(since: Long): Int? = try {
        contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.DURATION),
            "${CallLog.Calls.DATE} >= ? AND ${CallLog.Calls.TYPE} = ?",
            arrayOf(since.toString(), CallLog.Calls.OUTGOING_TYPE.toString()),
            "${CallLog.Calls.DATE} ASC"
        )?.use { c -> if (c.moveToFirst()) c.getInt(0) else null }
    } catch (_: Exception) {
        null
    }

    private fun record(id: String, status: Int, dur: Int, failureMessage: String) {
        val list = Store.lists.find { it.id == listId }
        if (list == null) {
            finish(T("Campaign list unavailable", "قائمة الحملة غير متاحة"), false, true)
            return
        }

        val e = list.entries.find { it.id == id }
        val started = callStart
        Store.updateEntry(listId, id) {
            it.copy(status = status, duration = dur, calledAt = started)
        }
        if (e != null) {
            Store.addLog(LogItem(
                time = System.currentTimeMillis(), listName = list.name, name = e.name,
                number = e.number, status = status, duration = dur, attempt = e.attempts
            ))
        }

        val action = engine.callFinished(id, status)
        awaiting = action is Action.WaitForStage
        if (failureMessage.isNotBlank()) {
            checkpoint(
                status = CS.RUNNING,
                listName = list.name,
                message = failureMessage
            )
        }

        when (action) {
            Action.Wait -> scheduleNextDelay()
            Action.WaitForStage -> scheduleStageWait()
            is Action.PlaceCall -> place(action.entry)
            is Action.RecoverActiveCall -> bindRecoveredActiveCall(action.entry)
            Action.Completed -> finish(T("Campaign completed ✓", "اكتملت الحملة ✓"), true)
            is Action.Failed -> finish(action.message, false, true)
        }
    }

    // -------------------------------------------------------------------------
    // User controls
    // -------------------------------------------------------------------------

    private fun pause() {
        if (!running) {
            recoverIfNeeded()
            if (!running) return
        }
        if (paused) return

        paused = true
        engine.pause()
        handler.removeCallbacks(nextRunnable)
        checkpoint(CS.PAUSED, T("Paused", "متوقفة مؤقتًا"))
    }

    private fun resume() {
        if (!running) {
            recoverIfNeeded()
            if (!running) return
        }
        if (!paused) return

        paused = false
        engine.resume()
        checkpoint(CS.RUNNING, T("Resuming…", "استئناف…"))

        if (curId != null && sawOffhook) return

        // Reuse the persisted nextAt whenever possible. This preserves the
        // remaining delay instead of restarting the timing window.
        val at = Store.camp.nextAt
        val delay = (at - System.currentTimeMillis()).coerceAtLeast(0)
        handler.removeCallbacks(nextRunnable)
        handler.postDelayed(nextRunnable, if (at > 0) delay else 1_000L)
    }

    private fun stageDone() {
        if (!running) {
            recoverIfNeeded()
            if (!running) return
        }
        if (!awaiting) return
        awaiting = false
        handler.removeCallbacks(nextRunnable)
        engine.stageDone()
        scheduleNextDelay()
    }

    private fun skipCurrent() {
        val id = curId ?: return
        // A user-initiated skip is a first-class outcome, not a failed call.
        val duration = if (sawOffhook && callStart > 0)
            ((System.currentTimeMillis() - callStart) / 1000L).toInt().coerceAtLeast(0) else 0
        hangup()
        curId = null
        sawOffhook = false
        record(id, St.SKIPPED, duration, "")
    }

    @Suppress("DEPRECATION")
    private fun hangup() {
        try {
            if (Build.VERSION.SDK_INT >= 28 && has(Manifest.permission.ANSWER_PHONE_CALLS)) {
                telecom.endCall()
            }
        } catch (_: Exception) {}
    }

    // -------------------------------------------------------------------------
    // Durable checkpoint / lifecycle
    // -------------------------------------------------------------------------

    private fun checkpoint(
        status: Int,
        message: String,
        currentName: String = Store.camp.currentName,
        currentNumber: String = Store.camp.currentNumber,
        error: Boolean = false
    ) {
        val list = Store.lists.find { it.id == listId }
        val snapshot = engine.snapshot(
            status = status,
            listName = list?.name.orEmpty(),
            currentName = currentName,
            currentNumber = currentNumber,
            message = message,
            error = error
        )
        Store.camp = snapshot
        if (running) {
            getSystemService(NotificationManager::class.java).notify(1, notif())
        }
    }

    private fun upd(c: CampState) {
        Store.camp = c
        if (running) getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    private fun finish(msg: String, completed: Boolean = false, error: Boolean = false) {
        if (::telecom.isInitialized && (curId != null || sawOffhook)) hangup()

        running = false
        paused = false
        curId = null
        sawOffhook = false
        awaiting = false
        handler.removeCallbacksAndMessages(null)
        if (S.autoSpeaker || S.autoMuteMic) applyAudio(false)
        unregister()
        releaseWake()

        if (listId.isNotEmpty()) {
            Store.updateList(listId) { l ->
                l.copy(entries = l.entries.map {
                    if (it.status == St.CALLING) it.copy(status = St.PENDING) else it
                })
            }
        }

        val finalPhase = if (completed) CampaignPhase.COMPLETED else CampaignPhase.FAILED
        val snapshot = engine.snapshot(
            status = CS.FINISHED,
            listName = Store.lists.find { it.id == listId }?.name.orEmpty(),
            currentName = "",
            currentNumber = "",
            message = msg,
            error = error
        ).copy(currentEntryId = null, currentPhase = finalPhase, nextAt = 0L)
        Store.camp = snapshot
        Store.archiveCampaign(snapshot, if (completed) "COMPLETED" else if (error) "FAILED" else "STOPPED")

        if (completed) {
            Store.resultsListId = listId
            Store.pendingResultsNav = true
            notifyDone()
            if (S.vibrateOnFinish) buzz()
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        // Do NOT mark a live campaign finished here. The durable journal is the
        // source of truth and Android may destroy/recreate this service normally.
        handler.removeCallbacksAndMessages(null)
        unregister()
        releaseWake()
        if (running) {
            checkpoint(
                status = if (paused) CS.PAUSED else CS.RUNNING,
                message = T("Execution service interrupted — resume to continue",
                    "توقفت خدمة التنفيذ — استأنف للمتابعة")
            )
        }
        super.onDestroy()
    }

    // -------------------------------------------------------------------------
    // Telephony callbacks
    // -------------------------------------------------------------------------

    @RequiresApi(31)
    private inner class Cb : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) = onState(state)
    }

    @Suppress("DEPRECATION")
    private fun register() {
        unregister()
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = Cb()
            modernCb = cb
            tm.registerTelephonyCallback(mainExecutor, cb)
        } else {
            val l = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    onState(state)
                }
            }
            legacyCb = l
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    @Suppress("DEPRECATION")
    private fun unregister() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                (modernCb as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                legacyCb?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (_: Exception) {}
        modernCb = null
        legacyCb = null
    }

    // -------------------------------------------------------------------------
    // Audio / power / notifications
    // -------------------------------------------------------------------------

    private fun acquireWake() {
        releaseWake()
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "o2dialer:run")
            .also { it.acquire(8 * 60 * 60 * 1000L) }
    }

    private fun releaseWake() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    @Suppress("DEPRECATION")
    private fun applyAudio(on: Boolean) {
        try {
            val am = getSystemService(AudioManager::class.java)
            if (S.autoSpeaker) am.isSpeakerphoneOn = on
            if (S.autoMuteMic) am.isMicrophoneMute = on
            else if (!on) am.isMicrophoneMute = false
        } catch (_: Exception) {}
    }

    private fun buzz() {
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun pi(action: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, DialerService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 9, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun notif(): Notification {
        val r = Store.camp
        val p = Store.lists.find { it.id == r.listId }?.let { Store.prog(it) }
        val who = r.currentName.ifEmpty { r.currentNumber }
        val stats = if (p != null) "${p.called}/${p.total} • ${p.pct}%" else ""
        val b = NotificationCompat.Builder(this, "dialer")
            .setSmallIcon(R.drawable.ic_stat_o2dialer)
            .setColor(0xFF6C47FF.toInt())
            .setContentTitle(
                if (who.isNotEmpty()) T("Calling $who", "جارٍ الاتصال بـ $who")
                else r.listName
            )
            .setContentText(
                if (who.isNotEmpty()) "${r.listName} • $stats"
                else "${r.message} • $stats"
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(p?.total ?: 0, p?.called ?: 0, false)
            .setContentIntent(openAppIntent())

        if (paused) b.addAction(0, T("Resume", "استئناف"), pi(ACT_RESUME, 1))
        else b.addAction(0, T("Pause", "إيقاف مؤقت"), pi(ACT_PAUSE, 2))
        b.addAction(0, T("Stop", "إيقاف"), pi(ACT_STOP, 3))
        return b.build()
    }

    private fun notifyDone() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                "done", "Campaign results",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        val l = Store.lists.find { it.id == listId }
        val p = l?.let { Store.prog(it) }
        val text = if (p != null) T(
            "${p.answered} answered • ${p.noAnswer} no answer • ${p.failed} failed",
            "${p.answered} ردّوا • ${p.noAnswer} لم يردّوا • ${p.failed} فشل"
        ) else ""

        nm.notify(
            2,
            NotificationCompat.Builder(this, "done")
                .setSmallIcon(R.drawable.ic_stat_o2dialer)
                .setContentTitle(
                    T("Campaign finished ✓", "اكتملت الحملة ✓") +
                        (l?.let { " · ${it.name}" } ?: "")
                )
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setColor(0xFF6C47FF.toInt())
                .setAutoCancel(true)
                .setContentIntent(openAppIntent())
                .build()
        )
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel(
                    "dialer", "Campaign",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        val type =
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, notif(), type)
    }
}
