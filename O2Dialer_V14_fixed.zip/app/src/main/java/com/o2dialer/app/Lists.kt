@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import com.o2dialer.app.core.data.Store
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun reportAdded(n: Int) {
    if (n > 0) Store.notify(Tk.SUCCESS, T("$n contacts added", "تمت إضافة $n جهة اتصال"))
    else Store.notify(Tk.INFO, T("No new contacts (duplicates or invalid)", "لا جهات اتصال جديدة (مكررة أو غير صالحة)"))
}

private enum class ContactFilter(val key: String) {
    ALL("All"), PENDING("Pending"), ANSWERED("Answered"), NO_ANSWER("No answer"), FAILED("Failed")
}

private fun filterLabel(f: ContactFilter) = when (f) {
    ContactFilter.ALL -> T("All", "الكل")
    ContactFilter.PENDING -> T("Pending", "لم يتم الاتصال")
    ContactFilter.ANSWERED -> T("Answered", "تم الرد")
    ContactFilter.NO_ANSWER -> T("No answer", "لم يُرد")
    ContactFilter.FAILED -> T("Failed", "فشل")
}

private fun matchesFilter(e: Entry, f: ContactFilter) = when (f) {
    ContactFilter.ALL -> true
    ContactFilter.PENDING -> e.status == St.PENDING || e.status == St.CALLING
    ContactFilter.ANSWERED -> St.isAnswered(e.status)
    ContactFilter.NO_ANSWER -> e.status == St.NO_ANSWER
    ContactFilter.FAILED -> e.status == St.FAILED
}

@Composable
fun ListsScreen(onMenu: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CallList?>(null) }
    var deleting by remember { mutableStateOf<CallList?>(null) }

    Scaffold(
        topBar = {
            BlendBar(T("Contact Lists", "قوائم جهات الاتصال"), onMenu,
                subtitle = if (Store.lists.isEmpty()) null else T("${Store.lists.size} lists", "${Store.lists.size} قائمة"))
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { creating = true }, shape = RoundedCornerShape(Rd.l),
                containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text(T("New list", "قائمة جديدة"), style = MaterialTheme.typography.labelLarge) }
            )
        }, containerColor = Color.Transparent
    ) { pad ->
        if (Store.lists.isEmpty()) {
            EmptyState(Icons.Rounded.Groups, T("No contact lists yet", "لا توجد قوائم بعد"),
                T("Create a list, add contacts, then turn it into a campaign.", "أنشئ قائمة وأضف جهات الاتصال ثم حوّلها إلى حملة."),
                Modifier.padding(pad), actionText = T("Create list", "إنشاء قائمة"), onAction = { creating = true })
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                items(Store.lists, key = { it.id }) { l ->
                    CampaignCard(l, onOpen = { Store.selectedListId = l.id }, onEdit = { editing = l }, onDelete = { deleting = l })
                }
            }
        }
    }

    if (creating) CampaignDialog(null, { creating = false }) { n, sim ->
        Store.selectedListId = Store.addList(n, sim); creating = false
        Store.notify(Tk.SUCCESS, T("List created", "تم إنشاء القائمة"))
    }
    editing?.let { l ->
        CampaignDialog(l, { editing = null }) { n, sim ->
            Store.updateList(l.id) { it.copy(name = n, simSlot = sim) }; editing = null
            Store.notify(Tk.SUCCESS, T("List renamed", "تم تعديل اسم القائمة"))
        }
    }
    deleting?.let { l ->
        ConfirmDialog(T("Delete \"${l.name}\" and all its contacts?", "حذف \"${l.name}\" وكل جهات الاتصال بها؟"), { deleting = null }) {
            Store.deleteList(l.id); deleting = null
            Store.notify(Tk.INFO, T("List deleted", "تم حذف القائمة"))
        }
    }
}

@Composable
fun CampaignCard(l: CallList, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val p = Store.prog(l)
    var menu by remember { mutableStateOf(false) }
    val sim = when (l.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }
    val running = Store.campActive() && Store.camp.listId == l.id
    val grey = MaterialTheme.colorScheme.onSurfaceVariant
    val st = when {
        running -> Triple(T("Running", "قيد التشغيل"), Sem.success, Icons.Rounded.PlayArrow)
        p.total == 0 -> Triple(T("Empty", "فارغة"), grey, Icons.Rounded.Info)
        p.called == 0 -> Triple(T("Ready", "جاهزة"), grey, Icons.Rounded.Schedule)
        p.remaining > 0 -> Triple(T("In progress", "جارية"), Sem.info, Icons.Rounded.Replay)
        else -> Triple(T("Completed", "مكتملة"), Sem.success, Icons.Rounded.CheckCircle)
    }
    Panel(Modifier.fillMaxWidth(), onClick = onOpen) {
        Column(Modifier.padding(Sp.l)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.FolderShared)
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(l.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${p.total} ${T("contacts", "جهة اتصال")}  •  $sim", style = MaterialTheme.typography.labelMedium, color = grey)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(T("Rename / edit", "إعادة تسمية / تعديل")) }, leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text(T("View results", "عرض النتائج")) }, leadingIcon = { Icon(Icons.Rounded.BarChart, null) }, onClick = { menu = false; Store.resultsListId = l.id; Store.tab = 2 })
                        DropdownMenuItem(text = { Text(T("Reset progress", "إعادة ضبط التقدم")) }, leadingIcon = { Icon(Icons.Rounded.Refresh, null) }, onClick = { menu = false; Store.resetForRestart(l.id, false) })
                        DropdownMenuItem(text = { Text(T("Remove duplicates", "حذف المكرر")) }, leadingIcon = { Icon(Icons.Rounded.ContentPaste, null) }, onClick = { menu = false; val removed = Store.dedupe(l.id); Store.notify(Tk.SUCCESS, T("Removed $removed duplicates", "تم حذف $removed مكرر")) })
                        DropdownMenuItem(text = { Text(T("Share report", "مشاركة التقرير")) }, leadingIcon = { Icon(Icons.Rounded.Share, null) }, onClick = { menu = false; shareText(ctx, Store.listReport(l)) })
                        DropdownMenuItem(text = { Text(T("Delete", "حذف"), color = Sem.danger) }, leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Sem.danger) }, onClick = { menu = false; onDelete() })
                    }
                }
            }
            if (p.total > 0) {
                Spacer(Modifier.height(Sp.l)); BProgress(p.pct / 100f, color = if (p.remaining == 0) Sem.success else MaterialTheme.colorScheme.primary, height = 6.dp)
                Spacer(Modifier.height(Sp.m)); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Pill(st.first, st.second, st.third); Spacer(Modifier.weight(1f)); Text(T("${p.pct}% • ${p.answered} answered", "${p.pct}% • ${p.answered} ردّوا"), style = MaterialTheme.typography.labelMedium, color = grey)
                }
            } else { Spacer(Modifier.height(Sp.m)); Pill(st.first, st.second, st.third) }
        }
    }
}

@Composable
fun ListDetail(listId: String, act: MainActivity) {
    val list = Store.lists.find { it.id == listId }
    if (list == null) { LaunchedEffect(Unit) { Store.selectedListId = null }; return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var filter by remember { mutableStateOf(ContactFilter.ALL) }
    var selectionMode by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var deleteSelected by remember { mutableStateOf(false) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val text = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: "" }
                val parsed = parseLines(text)
                val n = Store.addEntries(listId, parsed)
                importing = false
                if (parsed.isEmpty()) Store.notify(Tk.ERROR, T("No valid numbers found in the file", "لم يتم العثور على أرقام صالحة في الملف")) else reportAdded(n)
            }
        }
    }
    val p = Store.prog(list)
    val shown = list.entries.filter { e ->
        (query.isBlank() || e.name.contains(query, true) || e.number.contains(query.filter { it.isDigit() }) || e.displayNumber.contains(query, true)) && matchesFilter(e, filter)
    }
    val selectedVisible = shown.count { it.id in selected }
    val allVisibleSelected = shown.isNotEmpty() && selectedVisible == shown.size
    val simText = when (list.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }

    fun toggle(id: String) { if (id in selected) selected.remove(id) else selected.add(id) }
    fun selectAllVisible() { if (allVisibleSelected) selected.removeAll(shown.map { it.id }.toSet()) else shown.forEach { if (it.id !in selected) selected.add(it.id) } }

    val chips: @Composable () -> Unit = {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            ActionChip(Icons.Rounded.Add, T("Add contact", "إضافة جهة")) { dlg = "add" }
            ActionChip(Icons.Rounded.ContentPaste, T("Paste", "لصق")) { dlg = "bulk" }
            ActionChip(Icons.Rounded.UploadFile, T("Import file", "استيراد ملف")) { importer.launch(arrayOf("text/*", "text/csv", "application/csv", "application/vnd.ms-excel")) }
            ActionChip(Icons.Rounded.Contacts, T("Import contacts", "استيراد جهات الاتصال")) { act.ensureContacts { dlg = "contacts" } }
        }
    }

    Scaffold(
        topBar = {
            BlendBar(list.name, null, onBack = { Store.selectedListId = null }, subtitle = T("${p.total} contacts · $simText", "${p.total} جهة · $simText"))
        },
        bottomBar = {
            if (selectionMode && selected.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                    OutlinedButton(onClick = { selected.clear(); selectionMode = false }, modifier = Modifier.weight(1f)) { Text(T("Cancel", "إلغاء")) }
                    Button(onClick = { deleteSelected = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Sem.danger)) { Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(6.dp)); Text(T("Remove ${selected.size}", "حذف ${selected.size}")) }
                }
            } else if (list.entries.isNotEmpty()) {
                val label = when { p.called == 0 -> T("Start campaign", "ابدأ الحملة"); p.remaining > 0 -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي"); else -> T("Restart campaign", "إعادة تشغيل الحملة") }
                Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m)) { BButton(label, { act.startCampaign(listId, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow) }
            }
        }, containerColor = Color.Transparent
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xl), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            item { PermissionBanner(act) }
            if (importing) item { LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(50))) }
            item { SummaryPanel(p) }
            item { chips() }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BTextField(query, { query = it }, placeholder = T("Search name or phone", "بحث بالاسم أو الرقم"), leading = Icons.Rounded.Search, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(Sp.s))
                    IconButton(onClick = { selectionMode = !selectionMode; if (!selectionMode) selected.clear() }) { Icon(if (selectionMode) Icons.Rounded.Close else Icons.Rounded.Checklist, T("Select")) }
                }
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                    ContactFilter.entries.forEach { f ->
                        FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(filterLabel(f)) })
                    }
                }
            }
            if (selectionMode && shown.isNotEmpty()) item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(T("$selectedVisible selected", "تم تحديد $selectedVisible"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { selectAllVisible() }) { Text(if (allVisibleSelected) T("Clear visible", "إلغاء الظاهر") else T("Select visible", "تحديد الظاهر")) }
                    if (selected.isNotEmpty()) TextButton(onClick = { deleteSelected = true }) { Text(T("Remove", "حذف"), color = Sem.danger) }
                }
            }
            if (shown.isEmpty()) item { EmptyState(Icons.Rounded.SearchOff, T("No contacts match", "لا توجد جهات اتصال مطابقة"), T("Try another search or filter.", "جرّب بحثًا أو فلترًا آخر.")) }
            items(shown, key = { it.id }) { e -> EntryRow(e, listId, selectionMode, e.id in selected, { toggle(e.id) }) { editing = e } }
        }
    }

    when (dlg) {
        "add" -> EntryDialog(null, { dlg = "" }) { n, num -> reportAdded(Store.addEntries(listId, listOf(n to num))); dlg = "" }
        "bulk" -> BulkDialog({ dlg = "" }) { t -> reportAdded(Store.addEntries(listId, parseLines(t))); dlg = "" }
        "contacts" -> ContactsDialog({ dlg = "" }) { sel -> reportAdded(Store.addEntries(listId, sel)); dlg = "" }
    }
    editing?.let { e -> EntryDialog(e, { editing = null }) { n, num -> Store.editEntry(listId, e.id, n, num); editing = null; Store.notify(Tk.SUCCESS, T("Contact updated", "تم تحديث جهة الاتصال")) } }
    if (deleteSelected) {
        ConfirmDialog(T("Remove ${selected.size} selected contacts?", "حذف ${selected.size} جهة اتصال محددة؟"), { deleteSelected = false }) {
            val ids = selected.toSet()
            Store.updateList(listId) { it.copy(entries = it.entries.filterNot { e -> e.id in ids }) }
            val n = ids.size; selected.clear(); selectionMode = false; deleteSelected = false
            Store.notify(Tk.INFO, T("$n contacts removed", "تم حذف $n جهة اتصال"))
        }
    }
}

@Composable
private fun SummaryPanel(p: Prog) {
    Panel(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(Sp.l), verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(p.pct / 100f, 72.dp, 7.dp, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline) { Text("${p.pct}%", style = MaterialTheme.typography.titleSmall) }
            Spacer(Modifier.width(Sp.l))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                Text(T("${p.called} of ${p.total} called", "${p.called} من ${p.total} تم الاتصال"), style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m)) { Legend(Sem.success, T("${p.answered} answered", "${p.answered} ردّوا")); Legend(Sem.warning, T("${p.noAnswer} no answer", "${p.noAnswer} لم يُردّوا")) }
                Legend(Sem.danger, T("${p.failed} failed", "${p.failed} فشل"))
            }
        }
    }
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(6.dp)); Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
fun EntryRow(e: Entry, listId: String, selectionMode: Boolean, selected: Boolean, onToggle: () -> Unit, onEdit: () -> Unit) {
    val answered = St.isAnswered(e.status)
    Panel(Modifier.fillMaxWidth(), onClick = if (selectionMode) onToggle else onEdit) {
        Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
            if (selectionMode) {
                Checkbox(checked = selected, onCheckedChange = { onToggle() })
                Spacer(Modifier.width(Sp.s))
            }
            Avatar(e.name.ifBlank { e.number }, if (e.stage != Stg.NONE) Stg.color(e.stage) else MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Sp.m))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(e.name.ifBlank { T("Unknown contact", "جهة اتصال بدون اسم") }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                NumText(e.displayNumber.ifBlank { e.number }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(e.status)
                    if (e.calledAt > 0) Text(T("Last: ${fmtTime(e.calledAt)}", "آخر اتصال: ${fmtTime(e.calledAt)}"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (e.duration > 0) Pill(fmtDur(e.duration), Sem.success, Icons.Rounded.Schedule)
                    if (e.attempts > 0) Text(T("${e.attempts} attempts", "${e.attempts} محاولات"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (e.stage != Stg.NONE) StagePill(e.stage) { Store.stageTarget = listId to e.id }
                else if (answered) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) { Store.stageTarget = listId to e.id }
            }
            if (!selectionMode) {
                if (e.stage == Stg.POTENTIAL || e.stage == Stg.CALL_BACK || e.stage == Stg.WHATSAPP) WhatsAppButton(e.number)
                IconButton(onClick = onEdit) { Icon(Icons.Rounded.ChevronRight, T("Edit"), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}
