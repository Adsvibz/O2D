@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp

@Composable
fun O2AppBar(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    navigationIcon: ImageVector? = null,
    onNavigationClick: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        modifier = modifier,
        title = {
            Column {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        navigationIcon = {
            if (navigationIcon != null && onNavigationClick != null) {
                IconButton(onClick = onNavigationClick) {
                    Icon(navigationIcon, contentDescription = null, modifier = Modifier.size(O2IconSizes.lg))
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
    )
}

@Composable
fun O2BackAppBar(title: String, onBack: () -> Unit, modifier: Modifier = Modifier) = O2AppBar(
    title = title,
    modifier = modifier,
    navigationIcon = Icons.AutoMirrored.Filled.ArrowBack,
    onNavigationClick = onBack
)

@Composable
fun O2NavigationItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val container by animateColorAsState(
        if (selected) cs.primaryContainer else Color.Transparent,
        tween(O2Motion.standard),
        label = "navigationContainer"
    )
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(O2Radii.md))
            .background(container)
            .clickable(onClick = onClick)
            .padding(horizontal = O2Spacing.md, vertical = O2Spacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) cs.primary else cs.onSurfaceVariant, modifier = Modifier.size(O2IconSizes.md))
        Spacer(Modifier.width(O2Spacing.md))
        Text(label, style = MaterialTheme.typography.labelLarge, color = if (selected) cs.primary else cs.onSurface)
    }
}

@Composable
fun O2Card(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(O2Radii.lg)
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val border = BorderStroke(O2Borders.hairline, MaterialTheme.colorScheme.outline)
    if (onClick == null) {
        Card(modifier = modifier, shape = shape, colors = colors, elevation = CardDefaults.cardElevation(O2Elevation.none), border = border, content = content)
    } else {
        Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, elevation = CardDefaults.cardElevation(O2Elevation.none), border = border, content = content)
    }
}

@Composable
fun O2Button(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.Primary,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    compact: Boolean = false,
    iconOnly: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale = if (pressed) 0.98f else 1f
    val height = if (compact) O2ButtonSizes.compact else O2ButtonSizes.standard
    val shape = RoundedCornerShape(O2Radii.md)
    val content: @Composable RowScope.() -> Unit = {
        if (icon != null) Icon(icon, contentDescription = null, modifier = Modifier.size(O2IconSizes.md))
        if (icon != null && !iconOnly) Spacer(Modifier.width(O2Spacing.sm))
        if (!iconOnly) Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
    }
    val modifierWithScale = modifier.heightIn(min = height).graphicsLayerCompat(scale)
    when (kind) {
        BtnKind.Primary -> Button(onClick, modifierWithScale, enabled, shape = shape, interactionSource = interaction, contentPadding = PaddingValues(horizontal = O2Spacing.lg), content = content)
        BtnKind.Tonal -> Button(onClick, modifierWithScale, enabled, shape = shape, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = .12f), contentColor = MaterialTheme.colorScheme.primary), interactionSource = interaction, contentPadding = PaddingValues(horizontal = O2Spacing.lg), content = content)
        BtnKind.Outline -> OutlinedButton(onClick, modifierWithScale, enabled, shape = shape, border = BorderStroke(O2Borders.hairline, MaterialTheme.colorScheme.outline), interactionSource = interaction, contentPadding = PaddingValues(horizontal = O2Spacing.lg), content = content)
        BtnKind.Ghost -> TextButton(onClick, modifierWithScale, enabled, shape = shape, interactionSource = interaction, contentPadding = PaddingValues(horizontal = O2Spacing.lg), content = content)
        BtnKind.Danger -> Button(onClick, modifierWithScale, enabled, shape = shape, colors = ButtonDefaults.buttonColors(containerColor = O2Colors.danger, contentColor = Color.White), interactionSource = interaction, contentPadding = PaddingValues(horizontal = O2Spacing.lg), content = content)
    }
}

@Composable
fun O2IconButton(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, contentDescription: String? = null) {
    IconButton(onClick = onClick, modifier = modifier.size(O2ButtonSizes.minTouchTarget), enabled = enabled) {
        Icon(icon, contentDescription = contentDescription, modifier = Modifier.size(O2IconSizes.lg))
    }
}

@Composable
fun O2TextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    supportingText: String? = null,
    leadingIcon: ImageVector? = null,
    trailingContent: @Composable (() -> Unit)? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    isError: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(O2Radii.md),
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        maxLines = if (singleLine) 1 else 6,
        isError = isError,
        label = label?.let { { Text(it) } },
        placeholder = placeholder?.let { { Text(it) } },
        supportingText = supportingText?.let { { Text(it) } },
        leadingIcon = leadingIcon?.let { { Icon(it, null, modifier = Modifier.size(O2IconSizes.md)) } },
        trailingIcon = trailingContent,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun O2SearchField(value: String, onValueChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) =
    O2TextField(value, onValueChange, modifier, placeholder = placeholder, leadingIcon = Icons.Rounded.Search)

@Composable
fun O2SegmentedControl(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(O2Radii.md)).background(MaterialTheme.colorScheme.surfaceVariant).padding(O2Spacing.xs)) {
        options.forEachIndexed { index, option ->
            val selected = index == selectedIndex
            val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.surface else Color.Transparent, tween(O2Motion.standard), label = "segment")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(O2Radii.sm)).background(bg).clickable(onClick = { onSelect(index) }).padding(vertical = O2Spacing.sm),
                contentAlignment = Alignment.Center
            ) { Text(option, style = MaterialTheme.typography.labelLarge, color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
        }
    }
}

@Composable
fun O2Chip(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, selected: Boolean = false, onClick: (() -> Unit)? = null) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    val content = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val base = modifier.clip(RoundedCornerShape(O2Radii.pill)).background(bg).border(O2Borders.hairline, MaterialTheme.colorScheme.outline, RoundedCornerShape(O2Radii.pill))
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Row(clickable.padding(horizontal = O2Spacing.md, vertical = O2Spacing.sm), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = content, modifier = Modifier.size(O2IconSizes.sm)); Spacer(Modifier.width(O2Spacing.xs)) }
        Text(text, color = content, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun O2Badge(text: String, color: Color = MaterialTheme.colorScheme.primary, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(O2Radii.pill), color = color.copy(alpha = .12f)) {
        Text(text, modifier = Modifier.padding(horizontal = O2Spacing.sm, vertical = O2Spacing.xs), color = color, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun O2ProgressBar(progress: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = modifier.fillMaxWidth().height(O2Spacing.sm).clip(RoundedCornerShape(O2Radii.pill)), color = color, trackColor = MaterialTheme.colorScheme.outline.copy(alpha = .45f))
}

@Composable
fun O2ProgressRing(progress: Float, modifier: Modifier = Modifier, size: Dp = O2CardSizes.progressRing, stroke: Dp = O2Spacing.sm, content: @Composable () -> Unit = {}) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxSize(), strokeWidth = stroke, strokeCap = androidx.compose.ui.graphics.StrokeCap.Round, trackColor = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
        content()
    }
}

@Composable
fun O2EmptyState(icon: ImageVector, title: String, message: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(O2Spacing.xxxl), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(O2CardSizes.emptyIcon).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = .10f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(O2IconSizes.xl))
        }
        Spacer(Modifier.height(O2Spacing.xl))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(O2Spacing.sm))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) { Spacer(Modifier.height(O2Spacing.xl)); action() }
    }
}

@Composable
fun O2StatusIndicator(label: String, color: Color, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(O2IconSizes.xs).clip(CircleShape).background(color))
        Spacer(Modifier.width(O2Spacing.xs))
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun O2ListRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val base = modifier.fillMaxWidth().padding(horizontal = O2Spacing.lg, vertical = O2Spacing.md)
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Row(clickable, verticalAlignment = Alignment.CenterVertically) {
        if (leading != null) { leading(); Spacer(Modifier.width(O2Spacing.md)) }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) { Spacer(Modifier.width(O2Spacing.md)); trailing() }
    }
}

@Composable
fun O2StatCard(label: String, value: String, modifier: Modifier = Modifier, icon: ImageVector? = null, accent: Color = MaterialTheme.colorScheme.primary) {
    O2Card(modifier = modifier.heightIn(min = O2CardSizes.statMinHeight)) {
        Column(Modifier.padding(O2Spacing.lg), verticalArrangement = Arrangement.spacedBy(O2Spacing.sm)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (icon != null) Icon(icon, null, tint = accent, modifier = Modifier.size(O2IconSizes.md))
            }
            Text(value, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun O2ConfirmationDialog(title: String, message: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit, destructive: Boolean = false) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(O2Radii.xl),
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = { O2Button(confirmLabel, onConfirm, compact = true, kind = if (destructive) BtnKind.Danger else BtnKind.Primary) },
        dismissButton = { O2Button("Cancel", onDismiss, compact = true, kind = BtnKind.Ghost) }
    )
}

@Composable
fun O2BottomSheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = O2Radii.xl, topEnd = O2Radii.xl),
        containerColor = MaterialTheme.colorScheme.surface
    ) { Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = O2Spacing.lg, vertical = O2Spacing.xxl), content = content) }
}

private fun Modifier.graphicsLayerCompat(scale: Float): Modifier = this.then(
    Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
)
