package com.o2dialer.app

import androidx.compose.ui.graphics.Color
import com.o2dialer.app.core.data.Store
import com.o2dialer.app.core.domain.model.AppSettings
import com.o2dialer.app.core.domain.model.CallAttempt
import com.o2dialer.app.core.domain.model.CampaignContact
import com.o2dialer.app.core.domain.model.CampaignRuntimeState
import com.o2dialer.app.core.domain.model.CallStatus
import com.o2dialer.app.core.domain.model.ContactList
import org.json.JSONObject

/** Compatibility aliases. New code should depend on core.domain.model types. */
typealias Entry = CampaignContact
typealias CallList = ContactList
typealias LogItem = CallAttempt
typealias Cfg = AppSettings
typealias CampState = CampaignRuntimeState

fun T(en: String, ar: String): String = if (Store.cfg.lang == 1) ar else en

object St {
    const val PENDING = CallStatus.PENDING
    const val CALLING = CallStatus.CALLING
    const val ANSWERED = CallStatus.ANSWERED
    const val NO_ANSWER = CallStatus.NO_ANSWER
    const val FAILED = CallStatus.FAILED
    const val DONE = CallStatus.DONE
    fun isAnswered(s: Int) = s == ANSWERED || s == DONE
    fun label(s: Int): String = when (s) {
        PENDING -> T("Pending", "في الانتظار")
        CALLING -> T("Calling", "جارٍ الاتصال")
        ANSWERED -> T("Answered", "تم الرد")
        NO_ANSWER -> T("No answer", "لم يُرد")
        FAILED -> T("Failed", "فشل")
        else -> T("Completed", "انتهت")
    }
}

object Tk {
    const val INFO = 0
    const val SUCCESS = 1
    const val ERROR = 2
    const val WARN = 3
}

data class UiToast(val kind: Int, val msg: String, val id: Long)

object CS {
    const val IDLE = 0
    const val RUNNING = 1
    const val PAUSED = 2
    const val WAITING = 3
    const val FINISHED = 4
}

object Stg {
    const val NONE = 0
    const val POTENTIAL = 1
    const val NOT_INTERESTED = 2
    const val CALL_BACK = 3
    const val WHATSAPP = 4
    const val VOICEMAIL = 5
    val all = listOf(POTENTIAL, NOT_INTERESTED, CALL_BACK, WHATSAPP, VOICEMAIL)
    fun needsFeedback(s: Int) = s == POTENTIAL || s == CALL_BACK || s == WHATSAPP
    fun label(s: Int): String = when (s) {
        POTENTIAL -> T("Potential", "مهتم")
        NOT_INTERESTED -> T("Not Interested", "غير مهتم")
        CALL_BACK -> T("Call Back", "معاودة الاتصال")
        WHATSAPP -> T("WhatsApp", "واتساب")
        VOICEMAIL -> T("Voicemail", "بريد صوتي")
        else -> "—"
    }
    fun color(s: Int): Color = when (s) {
        POTENTIAL -> O2Colors.stagePotential
        NOT_INTERESTED -> O2Colors.stageNotInterested
        CALL_BACK -> O2Colors.stageCallBack
        WHATSAPP -> O2Colors.stageWhatsApp
        VOICEMAIL -> O2Colors.stageVoicemail
        else -> O2Colors.stageNeutral
    }
}

/** UI projection of campaign statistics. Business calculations remain pure. */
data class Prog(val total: Int, val called: Int, val answered: Int, val noAnswer: Int, val failed: Int) {
    val remaining: Int get() = total - called
    val pct: Int get() = if (total == 0) 0 else called * 100 / total
}
