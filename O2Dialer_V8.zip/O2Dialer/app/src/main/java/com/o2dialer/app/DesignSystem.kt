@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app
import com.o2dialer.app.core.data.Store

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// Legacy compatibility layer: current screens can migrate to O2Components incrementally.

// ====================================================================== layout helpers
/** Caps the content width so tablets / landscape stay tidy. Phones are unaffected. */
@Composable
fun Responsive(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
        Box(Modifier.widthIn(max = 640.dp).fillMaxSize()) { content() }
    }
}

@Composable
fun isCompact(): Boolean = LocalConfiguration.current.screenWidthDp < 360

// ====================================================================== motion
@Composable
fun Modifier.pressScale(src: MutableInteractionSource): Modifier {
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.97f else 1f, tween(110), label = "press")
    return this.graphicsLayer { scaleX = s; scaleY = s }
}

@Composable
fun PulseDot(color: Color, size: Dp = 10.dp) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(1f, 0.35f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Box(Modifier.size(size).clip(CircleShape).background(color.copy(alpha = a)))
}

/** Loading placeholder. */
@Composable
fun Skeleton(modifier: Modifier = Modifier, radius: Dp = 12.dp) {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(0.06f, 0.16f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Box(modifier.clip(RoundedCornerShape(radius)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = a)))
}

// ====================================================================== progress
@Composable
fun BProgress(
    progress: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary,
    track: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), height: Dp = 8.dp
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "bar")
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(O2Radii.pill)).background(track)) {
        Box(Modifier.fillMaxWidth(p).fillMaxHeight().clip(RoundedCornerShape(O2Radii.pill)).background(color))
    }
}

@Composable
fun ProgressRing(
    progress: Float, size: Dp, stroke: Dp, color: Color, track: Color, content: @Composable () -> Unit
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(600), label = "ring")
    Box(Modifier.size(size), Alignment.Center) {
        CircularProgressIndicator(progress = { p }, modifier = Modifier.fillMaxSize(), color = color,
            trackColor = track, strokeWidth = stroke, strokeCap = StrokeCap.Round)
        content()
    }
}

// ====================================================================== buttons
enum class BtnKind { Primary, Tonal, Outline, Ghost, Danger }

@Composable
fun BButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary,
    icon: ImageVector? = null, enabled: Boolean = true, compact: Boolean = false, iconOnly: Boolean = false
) {
    val src = remember { MutableInteractionSource() }
    val m = modifier.pressScale(src).heightIn(min = if (compact) 44.dp else 52.dp)
    val shape = RoundedCornerShape(Rd.m)
    val pad = PaddingValues(horizontal = if (iconOnly) 12.dp else 18.dp)
    val cs = MaterialTheme.colorScheme
    val flat = ButtonDefaults.buttonElevation(0.dp, 0.dp, 0.dp, 0.dp, 0.dp)
    val body: @Composable RowScope.() -> Unit = {
        if (icon != null) Icon(icon, null, Modifier.size(20.dp))
        if (icon != null && !iconOnly) Spacer(Modifier.width(8.dp))
        if (!iconOnly) Text(text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    when (kind) {
        BtnKind.Primary -> Button(onClick, m, enabled, shape, elevation = flat, contentPadding = pad,
            interactionSource = src, content = body)
        BtnKind.Tonal -> Button(onClick, m, enabled, shape,
            colors = ButtonDefaults.buttonColors(containerColor = cs.primary.copy(alpha = 0.12f), contentColor = cs.primary),
            elevation = flat, contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Danger -> Button(onClick, m, enabled, shape,
            colors = ButtonDefaults.buttonColors(containerColor = Sem.danger, contentColor = Color.White),
            elevation = flat, contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Outline -> OutlinedButton(onClick, m, enabled, shape, border = BorderStroke(1.dp, cs.outline),
            contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Ghost -> TextButton(onClick, m, enabled, shape, contentPadding = pad,
            interactionSource = src, content = body)
    }
}

// ====================================================================== inputs
@Composable
fun BTextField(
    value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, label: String? = null,
    placeholder: String? = null, supporting: String? = null, keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true, minLines: Int = 1, leading: ImageVector? = null, isError: Boolean = false
) {
    val cs = MaterialTheme.colorScheme
    OutlinedTextField(
        value, onChange, modifier.fillMaxWidth(), singleLine = singleLine, minLines = minLines,
        maxLines = if (singleLine) 1 else 6, isError = isError, shape = RoundedCornerShape(Rd.m),
        label = if (label != null) { { Text(label) } } else null,
        placeholder = if (placeholder != null) { { Text(placeholder) } } else null,
        supportingText = if (supporting != null) { { Text(supporting) } } else null,
        leadingIcon = if (leading != null) { { Icon(leading, null) } } else null,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = cs.primary, unfocusedBorderColor = cs.outline,
            focusedContainerColor = cs.surface, unfocusedContainerColor = cs.surface
        )
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(O2Radii.sm)).background(cs.surfaceVariant).padding(4.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            val bg by animateColorAsState(if (on) cs.surface else Color.Transparent, tween(180), label = "seg")
            Box(Modifier.weight(1f).clip(RoundedCornerShape(O2Radii.xs)).background(bg).clickable { onSelect(i) }
                .padding(vertical = 10.dp), Alignment.Center) {
                Text(o, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1,
                    color = if (on) cs.onSurface else cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

// ====================================================================== surfaces
@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val shape = RoundedCornerShape(Rd.l)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    val flat = CardDefaults.cardElevation(defaultElevation = 0.dp)
    if (onClick != null) Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, elevation = flat,
        border = border, content = content)
    else Card(modifier = modifier, shape = shape, colors = colors, elevation = flat, border = border, content = content)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun IconTile(icon: ImageVector, color: Color = MaterialTheme.colorScheme.primary, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(O2Radii.sm)).background(color.copy(alpha = 0.12f)), Alignment.Center) {
        Icon(icon, null, tint = color, modifier = Modifier.size(size * 0.5f))
    }
}

// ====================================================================== feedback: banner + toast + empty
@Composable
fun Banner(
    kind: Int, title: String, message: String? = null, modifier: Modifier = Modifier,
    actionText: String? = null, onAction: (() -> Unit)? = null
) {
    val c = when (kind) { Tk.SUCCESS -> Sem.success; Tk.ERROR -> Sem.danger; Tk.WARN -> Sem.warning; else -> Sem.info }
    val icon = when (kind) {
        Tk.SUCCESS -> Icons.Rounded.CheckCircle
        Tk.ERROR -> Icons.Rounded.Error
        Tk.WARN -> Icons.Rounded.Warning
        else -> Icons.Rounded.Info
    }
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).background(c.copy(alpha = 0.10f))
            .border(1.dp, c.copy(alpha = 0.25f), RoundedCornerShape(Rd.m)).padding(Sp.m),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c)
        Spacer(Modifier.width(Sp.m))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (message != null) Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (actionText != null && onAction != null) TextButton(onClick = onAction) { Text(actionText, color = c, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun ToastHost(modifier: Modifier = Modifier) {
    val t = Store.toast
    var last by remember { mutableStateOf<UiToast?>(null) }
    LaunchedEffect(t?.id) {
        if (t != null) {
            last = t
            delay(2600)
            if (Store.toast?.id == t.id) Store.toast = null
        }
    }
    AnimatedVisibility(
        visible = t != null, modifier = modifier,
        enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()
    ) {
        val shown = t ?: last
        if (shown != null) {
            val c = when (shown.kind) { Tk.SUCCESS -> Sem.success; Tk.ERROR -> Sem.danger; Tk.WARN -> Sem.warning; else -> Sem.info }
            val icon = when (shown.kind) {
                Tk.SUCCESS -> Icons.Rounded.CheckCircle
                Tk.ERROR -> Icons.Rounded.Error
                Tk.WARN -> Icons.Rounded.Warning
                else -> Icons.Rounded.Info
            }
            Surface(shape = RoundedCornerShape(Rd.m), color = MaterialTheme.colorScheme.inverseSurface, shadowElevation = 8.dp) {
                Row(Modifier.padding(horizontal = Sp.l, vertical = Sp.m), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, tint = c)
                    Spacer(Modifier.width(Sp.m))
                    Text(shown.msg, color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector, title: String, sub: String, modifier: Modifier = Modifier,
    actionText: String? = null, onAction: (() -> Unit)? = null
) {
    Column(modifier.fillMaxSize().padding(Sp.xxxl), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)), Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(Sp.xl))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Sp.s))
        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(Sp.xl))
            BButton(actionText, onAction, compact = true)
        }
    }
}

// ====================================================================== small atoms
@Composable
fun NumText(
    n: String, modifier: Modifier = Modifier, style: TextStyle = MaterialTheme.typography.bodyMedium,
    color: Color = Color.Unspecified
) {
    Text(n, modifier = modifier, style = style.copy(textDirection = TextDirection.Ltr), color = color)
}

@Composable
fun Avatar(text: String, color: Color = MaterialTheme.colorScheme.primary, size: Dp = 44.dp) {
    val ch = text.trim().firstOrNull { it.isLetter() }?.uppercase() ?: "#"
    Box(Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.14f)), Alignment.Center) {
        Text(ch, color = color, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun Pill(text: String, color: Color, icon: ImageVector? = null, onClick: (() -> Unit)? = null) {
    var m = Modifier.clip(RoundedCornerShape(O2Radii.pill))
    if (onClick != null) m = m.clickable { onClick() }
    Row(m.background(color.copy(alpha = 0.13f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            Icon(icon, null, tint = color, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, color = color, style = MaterialTheme.typography.labelLarge.copy(fontSize = MaterialTheme.typography.labelMedium.fontSize))
    }
}

fun stageIcon(s: Int): ImageVector = when (s) {
    Stg.POTENTIAL -> Icons.Rounded.Star
    Stg.NOT_INTERESTED -> Icons.Rounded.ThumbDown
    Stg.CALL_BACK -> Icons.Rounded.Replay
    Stg.WHATSAPP -> Icons.Rounded.Chat
    Stg.VOICEMAIL -> Icons.Rounded.Voicemail
    else -> Icons.Rounded.Label
}

@Composable
fun StatusPill(s: Int) = Pill(St.label(s), statusColor(s))

@Composable
fun StagePill(s: Int, onClick: (() -> Unit)? = null) = Pill(Stg.label(s), Stg.color(s), stageIcon(s), onClick)

@Composable
fun ActionChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(RoundedCornerShape(O2Radii.pill)).background(cs.surface).border(1.dp, cs.outline, RoundedCornerShape(O2Radii.pill))
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = cs.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun WhatsAppButton(number: String, size: Dp = 34.dp) {
    val ctx = LocalContext.current
    Box(Modifier.size(size).clip(CircleShape).background(O2Colors.whatsapp).clickable { openWhatsApp(ctx, number) },
        Alignment.Center) {
        Icon(Icons.Rounded.Call, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun LogoMark(dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val r = this.size.minDimension * 0.28f
        val cy = this.size.height / 2f
        drawCircle(Color.White, r, Offset(this.size.width * 0.40f, cy))
        drawCircle(Color.White.copy(alpha = 0.55f), r, Offset(this.size.width * 0.62f, cy))
    }
}

// ====================================================================== top bar
@Composable
private fun LivePill() {
    val pct = Store.lists.find { it.id == Store.camp.listId }?.let { Store.prog(it).pct } ?: 0
    Row(
        Modifier.padding(end = 4.dp).clip(RoundedCornerShape(O2Radii.pill)).background(Sem.success.copy(alpha = 0.14f))
            .clickable { Store.tab = 1 }.padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PulseDot(Sem.success, 8.dp)
        Spacer(Modifier.width(6.dp))
        Text("${T("Live", "مباشر")} $pct%", color = Sem.success, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun BlendBar(
    title: String, onMenu: (() -> Unit)?, onBack: (() -> Unit)? = null, showSettings: Boolean = true,
    subtitle: String? = null, actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Text(title, style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            else if (onMenu != null) IconButton(onClick = onMenu) { Icon(Icons.Rounded.Menu, null) }
        },
        actions = {
            if (Store.campActive() && Store.tab != 1) LivePill()
            actions()
            if (showSettings) IconButton(onClick = { Store.openSettings() }) { Icon(Icons.Rounded.Settings, null) }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
    )
}

// ====================================================================== dialog
@Composable
fun BDialog(
    title: String?, onDismiss: () -> Unit, confirmText: String? = null, onConfirm: (() -> Unit)? = null,
    dismissText: String = T("Cancel", "إلغاء"), destructive: Boolean = false, confirmEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss, shape = RoundedCornerShape(Rd.xl), containerColor = MaterialTheme.colorScheme.surface,
        title = if (title != null) { { Text(title, style = MaterialTheme.typography.titleLarge) } } else null,
        text = { Column(verticalArrangement = Arrangement.spacedBy(Sp.m), content = content) },
        confirmButton = {
            if (confirmText != null && onConfirm != null)
                BButton(confirmText, onConfirm, kind = if (destructive) BtnKind.Danger else BtnKind.Primary,
                    compact = true, enabled = confirmEnabled)
        },
        dismissButton = { BButton(dismissText, onDismiss, kind = BtnKind.Ghost, compact = true) }
    )
}
