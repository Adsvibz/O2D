package com.o2dialer.app.core.domain.campaign

import com.o2dialer.app.core.domain.model.CallStatus
import com.o2dialer.app.core.domain.model.CampaignContact
import com.o2dialer.app.core.domain.model.CampaignStatistics

object CampaignStatisticsCalculator {
    fun calculate(entries: List<CampaignContact>): CampaignStatistics {
        val called = entries.count { it.status != CallStatus.PENDING && it.status != CallStatus.CALLING }
        return CampaignStatistics(
            total = entries.size,
            called = called,
            answered = entries.count { it.status == CallStatus.ANSWERED || it.status == CallStatus.DONE },
            noAnswer = entries.count { it.status == CallStatus.NO_ANSWER },
            failed = entries.count { it.status == CallStatus.FAILED }
        )
    }
}
