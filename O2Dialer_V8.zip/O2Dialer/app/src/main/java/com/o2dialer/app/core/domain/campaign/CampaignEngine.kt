package com.o2dialer.app.core.domain.campaign

import com.o2dialer.app.CallList
import com.o2dialer.app.Cfg
import com.o2dialer.app.Entry
import com.o2dialer.app.St
import com.o2dialer.app.St.isAnswered
import kotlin.random.Random

/**
 * Android-free campaign orchestration. It decides what should happen next;
 * an Android foreground service is responsible for executing those decisions.
 */
class CampaignEngine(
    private val config: () -> Cfg,
    private val nowMs: () -> Long = { System.currentTimeMillis() },
    private val random: Random = Random.Default
) {
    sealed interface Action {
        data object Wait : Action
        data class PlaceCall(val entry: Entry) : Action
        data object WaitForStage : Action
        data object Completed : Action
        data class Failed(val message: String) : Action
    }

    private val queue = ArrayDeque<String>()
    private val retriesLeft = HashMap<String, Int>()
    private var list: CallList? = null
    private var loop = 1
    private var paused = false
    private var awaitingStage = false

    fun start(source: CallList, restart: Boolean): Action {
        list = source
        loop = 1
        paused = false
        awaitingStage = false
        return rebuildQueue(source, restart)
    }

    fun pause() { paused = true }
    fun resume() { paused = false }

    fun stageDone(): Action {
        awaitingStage = false
        return next()
    }

    fun callFinished(entryId: String, status: Int): Action {
        val current = list ?: return Action.Failed("Campaign is not initialized")
        val entry = current.entries.firstOrNull { it.id == entryId }
            ?: return Action.Failed("Entry no longer exists")

        if (status == St.NO_ANSWER || status == St.FAILED) {
            val left = retriesLeft[entryId] ?: 0
            if (left > 0) {
                retriesLeft[entryId] = left - 1
                queue.addLast(entryId)
            }
        }

        if (config().askStage && isAnswered(status)) {
            awaitingStage = true
            return Action.WaitForStage
        }
        return next()
    }

    fun next(): Action {
        if (paused) return Action.Wait
        if (awaitingStage) return Action.WaitForStage

        if (queue.isEmpty()) {
            val cfg = config()
            if (loop < cfg.loops) {
                loop++
                val source = list ?: return Action.Failed("Campaign is not initialized")
                return rebuildQueue(source, restart = true)
            }
            return Action.Completed
        }

        val current = list ?: return Action.Failed("Campaign is not initialized")
        val id = queue.removeFirst()
        val entry = current.entries.firstOrNull { it.id == id }
            ?: return next()
        return Action.PlaceCall(entry)
    }

    private fun rebuildQueue(source: CallList, restart: Boolean): Action {
        queue.clear()
        retriesLeft.clear()
        val cfg = config()

        var fresh = source.entries.filter {
            if (restart && cfg.skipAnswered && isAnswered(it.status)) false
            else it.status == St.PENDING || it.status == St.CALLING
        }
        if (cfg.shuffle) fresh = fresh.shuffled(random)
        queue.addAll(fresh.map(Entry::id))

        source.entries
            .filter { (it.status == St.NO_ANSWER || it.status == St.FAILED) && it.attempts - 1 < cfg.retries }
            .forEach {
                retriesLeft[it.id] = cfg.retries - (it.attempts - 1)
                queue.addLast(it.id)
            }

        return if (queue.isEmpty()) Action.Completed else Action.Wait
    }

    fun currentLoop(): Int = loop
    fun isPaused(): Boolean = paused
    fun isAwaitingStage(): Boolean = awaitingStage
    fun remaining(): Int = queue.size
    fun nextDelaySeconds(): Int {
        val cfg = config()
        return if (cfg.randomDelay) random.nextInt(cfg.delaySec, maxOf(cfg.delaySec, cfg.delayMaxSec) + 1)
        else cfg.delaySec
    }

    fun inQuietWindow(): Boolean {
        val cfg = config()
        if (!cfg.quietEnabled) return true
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (cfg.quietFrom <= cfg.quietTo) hour >= cfg.quietFrom && hour < cfg.quietTo
        else hour >= cfg.quietFrom || hour < cfg.quietTo
    }
}
