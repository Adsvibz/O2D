O2Dialer v3.1
Upload O2Dialer.zip as-is to your GitHub repo root, keep .github/workflows/build.yml (unzips O2Dialer*.zip), run Actions, download O2Dialer-APK.


COMMAND 05 — CORE DATA ARCHITECTURE
-----------------------------------
O2Dialer now uses immutable domain models and repository boundaries for settings, contact lists, campaign data, call history, and persisted campaign runtime recovery. Existing SharedPreferences keys and the application ID remain unchanged for in-place Android upgrades. Version code is now 5 (3.2).

Install/update safety:
- Keep the same application ID: com.o2dialer.app
- Keep the same signing key
- Install the new APK over the existing installation
- Do NOT uninstall first, or Android will remove the existing app data
