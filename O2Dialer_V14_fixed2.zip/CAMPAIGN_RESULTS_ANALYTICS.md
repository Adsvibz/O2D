# COMMAND 12 — Results & Analytics

## Product goal

Campaign results are designed for fast understanding, not a dense BI dashboard. The screen answers three questions immediately:

1. How did the campaign perform?
2. Where are the calls?
3. What happened on each individual call?

## Overview

The Results screen provides tappable metrics for:

- Total contacts
- Answered
- Unanswered
- Failed
- Skipped
- Remaining

Tapping a metric filters the call list in place. No secondary navigation is required.

## Performance metrics

- Completion percentage
- Answer rate = answered / completed calls
- Total call time
- Average call duration

Duration metrics are calculated from persisted contact durations and never depend on transient Compose state.

## Stage distribution

The five post-call stages are shown with their existing visual identities:

- Potential
- Not Interested
- Call Back
- WhatsApp
- Voicemail

Each stage is tappable and filters the call list immediately. Stage percentages are relative to answered calls.

## Call detail rows

Every displayed call includes:

- Name
- Number
- Call time
- Duration
- Call result
- Stage
- Feedback
- Attempt count

The row remains compact while preserving all requested information. Feedback is truncated visually when long, while the stored value remains unchanged.

## Skipped calls

`SKIPPED` is now a first-class domain call status. A user-initiated Skip action records the outcome before the campaign engine continues. This prevents skipped calls from being incorrectly reported as failed or unanswered.

## Architecture

Analytics are calculated by `CampaignStatisticsCalculator`, a platform-independent domain component. The Compose screen consumes the calculated statistics and persisted campaign entries; it does not own telephony or campaign state.
