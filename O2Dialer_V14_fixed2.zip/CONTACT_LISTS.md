# O2Dialer — Contact Lists (COMMAND 07)

The Lists experience is now a contact-management workspace rather than a campaign-only screen.

## Included
- Create, rename, edit and delete contact lists.
- Add one contact, paste many contacts, import CSV/TXT, or import Android contacts.
- Search by contact name or phone number.
- Filter by all, pending, answered, no answer, or failed.
- Multi-select visible contacts and remove them in one action.
- Contact rows clearly separate name, display phone number, call status, last call, duration and attempts.
- Canonical phone numbers are normalized for dialing while the entered/display form is retained separately when available.

## Phone normalization
Examples:
- `966xxxxxxxxx` → `+966xxxxxxxxx`
- `2010xxxxxxxx` → `+2010xxxxxxxx`
- `010xxxxxxxx` with Egypt country code configured/available → `+2010xxxxxxxx`
- Existing `+` numbers and `00` international prefixes are preserved as international numbers.
- Valid international-looking numbers are not blindly prefixed with the local country code.

Persistence remains backward-compatible with existing O2Dialer list data; older entries without `displayNumber` fall back to their stored number.
