package com.o2dialer.app.core.domain.campaign

import com.o2dialer.app.CallList
import com.o2dialer.app.Cfg
import com.o2dialer.app.Entry
import com.o2dialer.app.St
import com.o2dialer.app.St.isAnswered
import com.o2dialer.app.core.domain.model.CampaignPhase
import com.o2dialer.app.core.domain.model.CampaignRuntimeState
import java.util.UUID
import kotlin.random.Random

/**
 * Android-free campaign execution engine.
 *
 * The engine owns the logical campaign position. The foreground service is only
 * an execution adapter: it performs telephony operations and feeds observations
 * back into this engine.
 *
 * IMPORTANT: queue entries are removed only when claimed for execution, and the
 * claim is part of the persisted snapshot. A restored session therefore resumes
 * from the exact logical position instead of rebuilding from contact status.
 */
class CampaignEngine(
    private val config: () -> Cfg,
    private val nowMs: () -> Long = { System.currentTimeMillis() },
    private val random: Random = Random.Default
) {
    sealed interface Action {
        data object Wait : Action
        data class PlaceCall(val entry: Entry) : Action
        data class RecoverActiveCall(val entry: Entry) : Action
        data object WaitForStage : Action
        data object Completed : Action
        data class Failed(val message: String) : Action
    }

    private val queue = ArrayDeque<String>()
    private val retriesLeft = HashMap<String, Int>()
    private var list: CallList? = null
    private var loop = 1
    private var paused = false
    private var awaitingStage = false
    private var currentEntryId: String? = null
    private var currentPhase = CampaignPhase.IDLE
    private var nextAt = 0L
    private var callStartedAt = 0L
    private var offhookAt = 0L
    private var simSlot = -1
    private var sessionId = ""
    private var sessionStartedAt = 0L

    fun start(source: CallList, restart: Boolean): Action {
        list = source
        if (restart) {
            loop = 1
            paused = false
            awaitingStage = false
            currentEntryId = null
            currentPhase = CampaignPhase.IDLE
            nextAt = 0L
            callStartedAt = 0L
            offhookAt = 0L
            simSlot = source.simSlot
            sessionId = UUID.randomUUID().toString()
        sessionStartedAt = nowMs()
            return rebuildQueue(source, restart = false)
        }

        // A normal start is a new session only when no durable session exists.
        if (sessionId.isBlank()) {
            sessionId = UUID.randomUUID().toString()
            sessionStartedAt = nowMs()
        }
        loop = 1
        paused = false
        awaitingStage = false
        currentEntryId = null
        currentPhase = CampaignPhase.IDLE
        nextAt = 0L
        callStartedAt = 0L
        offhookAt = 0L
        simSlot = source.simSlot
        return rebuildQueue(source, restart = false)
    }

    fun restore(source: CallList, persisted: CampaignRuntimeState): Action {
        list = source
        sessionId = persisted.sessionId.ifBlank { UUID.randomUUID().toString() }
        sessionStartedAt = persisted.startedAt
        loop = persisted.loop.coerceAtLeast(1)
        paused = persisted.status == 2 || persisted.currentPhase == CampaignPhase.PAUSED
        awaitingStage = persisted.awaitingStage || persisted.currentPhase == CampaignPhase.WAITING_STAGE
        currentEntryId = persisted.currentEntryId
        currentPhase = persisted.currentPhase
        nextAt = persisted.nextAt
        callStartedAt = persisted.callStartedAt
        offhookAt = persisted.offhookAt
        simSlot = if (persisted.simSlot >= 0) persisted.simSlot else source.simSlot

        queue.clear()
        queue.addAll(persisted.queue)
        retriesLeft.clear()
        retriesLeft.putAll(persisted.retriesLeft)

        return when {
            paused -> Action.Wait
            awaitingStage -> Action.WaitForStage
            queue.isEmpty() && currentEntryId == null -> {
                if (loop < config().loops) rebuildForNextLoop(source) else Action.Completed
            }
            else -> Action.Wait
        }
    }

    /**
     * Resolve a restored CALLING claim after the Android adapter has observed the
     * real phone state. If no call is active, the exact contact is returned to
     * the front of the queue. If a call is active, keep ownership of the claim.
     */
    fun recoverInterruptedCall(callIsActive: Boolean): Action {
        val id = currentEntryId ?: return Action.Wait
        if (currentPhase != CampaignPhase.CALLING) return Action.Wait
        if (callIsActive) {
            return Action.RecoverActiveCall(list?.entries?.firstOrNull { it.id == id }
                ?: return Action.Failed("Current contact no longer exists"))
        }
        if (!queue.contains(id)) queue.addFirst(id)
        currentEntryId = null
        currentPhase = CampaignPhase.RECOVERING
        callStartedAt = 0L
        offhookAt = 0L
        return Action.Wait
    }

    fun pause() {
        paused = true
        currentPhase = CampaignPhase.PAUSED
        // Keep nextAt: resume must continue the same logical timing point.
    }

    fun resume() {
        paused = false
        if (currentPhase == CampaignPhase.PAUSED) currentPhase = CampaignPhase.DELAY
    }

    fun stageDone(): Action {
        awaitingStage = false
        currentPhase = CampaignPhase.DELAY
        nextAt = 0L
        return next()
    }

    fun markCallStarted(entryId: String, startedAt: Long = nowMs()): Boolean {
        if (currentEntryId != entryId) return false
        currentPhase = CampaignPhase.CALLING
        callStartedAt = startedAt
        nextAt = 0L
        return true
    }

    fun markOffhook(at: Long = nowMs()) {
        if (currentEntryId != null) {
            offhookAt = at
            currentPhase = CampaignPhase.CALLING
        }
    }

    fun callFinished(entryId: String, status: Int): Action {
        val current = list ?: return Action.Failed("Campaign is not initialized")
        val entry = current.entries.firstOrNull { it.id == entryId }
            ?: return Action.Failed("Entry no longer exists")

        if (currentEntryId == entryId) {
            currentEntryId = null
            callStartedAt = 0L
            offhookAt = 0L
        }

        if (status == St.NO_ANSWER || status == St.FAILED) {
            val left = retriesLeft[entryId] ?: 0
            if (left > 0) {
                retriesLeft[entryId] = left - 1
                queue.addLast(entryId)
            }
        }

        if (config().askStage && isAnswered(status)) {
            awaitingStage = true
            currentPhase = CampaignPhase.WAITING_STAGE
            return Action.WaitForStage
        }

        currentPhase = CampaignPhase.DELAY
        nextAt = 0L
        return Action.Wait
    }

    fun next(): Action {
        if (paused) {
            currentPhase = CampaignPhase.PAUSED
            return Action.Wait
        }
        if (awaitingStage) {
            currentPhase = CampaignPhase.WAITING_STAGE
            return Action.WaitForStage
        }
        if (currentEntryId != null) return Action.Wait

        if (queue.isEmpty()) {
            val source = list ?: return Action.Failed("Campaign is not initialized")
            if (loop < config().loops) return rebuildForNextLoop(source)
            currentPhase = CampaignPhase.COMPLETED
            return Action.Completed
        }

        val current = list ?: return Action.Failed("Campaign is not initialized")
        while (queue.isNotEmpty()) {
            val id = queue.removeFirst()
            val entry = current.entries.firstOrNull { it.id == id } ?: continue
            currentEntryId = entry.id
            currentPhase = CampaignPhase.CALLING
            callStartedAt = 0L
            offhookAt = 0L
            nextAt = 0L
            return Action.PlaceCall(entry)
        }

        return next()
    }

    fun setNextAt(at: Long) {
        nextAt = at
        if (!paused && !awaitingStage) currentPhase = CampaignPhase.DELAY
    }

    private fun rebuildForNextLoop(source: CallList): Action {
        loop++
        return rebuildQueue(source, restart = true)
    }

    private fun rebuildQueue(source: CallList, restart: Boolean): Action {
        queue.clear()
        retriesLeft.clear()
        val cfg = config()

        var fresh = source.entries.filter {
            if (restart && cfg.skipAnswered && isAnswered(it.status)) false
            else it.status == St.PENDING || it.status == St.CALLING
        }
        if (cfg.shuffle) fresh = fresh.shuffled(random)
        queue.addAll(fresh.map(Entry::id))

        source.entries
            .filter { (it.status == St.NO_ANSWER || it.status == St.FAILED) && it.attempts - 1 < cfg.retries }
            .forEach {
                retriesLeft[it.id] = cfg.retries - (it.attempts - 1)
                queue.addLast(it.id)
            }

        currentEntryId = null
        currentPhase = if (queue.isEmpty()) CampaignPhase.COMPLETED else CampaignPhase.DELAY
        nextAt = 0L
        return if (queue.isEmpty()) Action.Completed else Action.Wait
    }

    fun snapshot(status: Int, listName: String, currentName: String, currentNumber: String, message: String, error: Boolean = false): CampaignRuntimeState =
        CampaignRuntimeState(
            status = status,
            listId = list?.id ?: "",
            listName = listName,
            currentName = currentName,
            currentNumber = currentNumber,
            message = message,
            loop = loop,
            loops = config().loops,
            nextAt = nextAt,
            awaitingStage = awaitingStage,
            error = error,
            queue = queue.toList(),
            retriesLeft = retriesLeft.toMap(),
            currentEntryId = currentEntryId,
            currentPhase = currentPhase,
            callStartedAt = callStartedAt,
            offhookAt = offhookAt,
            simSlot = simSlot,
            sessionId = sessionId,
            startedAt = sessionStartedAt,
            checkpointAt = nowMs()
        )

    fun currentLoop(): Int = loop
    fun isPaused(): Boolean = paused
    fun isAwaitingStage(): Boolean = awaitingStage
    fun remaining(): Int = queue.size + if (currentEntryId != null) 1 else 0
    fun currentEntry(): String? = currentEntryId

    fun nextDelaySeconds(): Int {
        val cfg = config()
        return if (cfg.randomDelay) random.nextInt(cfg.delaySec, maxOf(cfg.delaySec, cfg.delayMaxSec) + 1)
        else cfg.delaySec
    }

    fun inQuietWindow(): Boolean {
        val cfg = config()
        if (!cfg.quietEnabled) return true
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (cfg.quietFrom <= cfg.quietTo) hour >= cfg.quietFrom && hour < cfg.quietTo
        else hour >= cfg.quietFrom || hour < cfg.quietTo
    }
}
