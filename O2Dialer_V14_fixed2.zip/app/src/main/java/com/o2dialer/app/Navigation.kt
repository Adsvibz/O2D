package com.o2dialer.app

import android.net.Uri

/** Stable product-level destinations. Keep this small; secondary actions belong in-context. */
enum class O2Destination(val route: String, val titleEn: String, val titleAr: String) {
    HOME("home", "Home", "الرئيسية"),
    LISTS("lists", "Lists", "القوائم"),
    CAMPAIGNS("campaigns", "Campaigns", "الحملات"),
    HISTORY("history", "History", "السجل"),
    ANALYTICS("analytics", "Analytics", "التحليلات"),
    SETTINGS("settings", "Settings", "الإعدادات");

    fun title() = T(titleEn, titleAr)
}

data class O2NavState(
    val destination: O2Destination = O2Destination.HOME,
    val selectedListId: String? = null
)

fun O2Destination.toLegacyTab(): Int = when (this) {
    O2Destination.HOME, O2Destination.LISTS -> 0
    O2Destination.CAMPAIGNS -> 1
    O2Destination.ANALYTICS -> 2
    O2Destination.HISTORY -> 3
    O2Destination.SETTINGS -> 4
}

fun O2Destination.deepLinkUri(listId: String? = null): Uri = buildString {
    append("o2dialer://")
    append(route)
    if (!listId.isNullOrBlank()) append('/').append(Uri.encode(listId))
}.let(Uri::parse)

fun parseO2DeepLink(uri: Uri?): O2NavState? {
    if (uri == null || uri.scheme != "o2dialer") return null
    val route = uri.host?.lowercase() ?: uri.pathSegments.firstOrNull()?.lowercase() ?: return null
    val destination = when (route) {
        "home" -> O2Destination.HOME
        "lists", "list" -> O2Destination.LISTS
        "campaigns", "campaign" -> O2Destination.CAMPAIGNS
        "history" -> O2Destination.HISTORY
        "analytics", "results" -> O2Destination.ANALYTICS
        "settings" -> O2Destination.SETTINGS
        else -> return null
    }
    val id = uri.pathSegments.firstOrNull()?.takeIf { destination == O2Destination.LISTS || destination == O2Destination.CAMPAIGNS }
    return O2NavState(destination, id)
}
