package com.o2dialer.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.o2dialer.app.core.data.AppContainer
import com.o2dialer.app.core.data.AppUiState
import com.o2dialer.app.core.domain.model.CallStatus
import com.o2dialer.app.presentation.AppViewModel
import com.o2dialer.app.presentation.AppViewModelFactory
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    onMenu: () -> Unit,
    onOpenLists: () -> Unit,
    onCreateCampaign: () -> Unit,
    onOpenCampaigns: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenAnalytics: () -> Unit
) {
    val vm: AppViewModel = viewModel(factory = AppViewModelFactory(AppContainer.get().runtime))
    val uiState by vm.uiState.collectAsStateWithLifecycle()
    HomeContent(
        uiState = uiState,
        onMenu = onMenu,
        onOpenLists = onOpenLists,
        onCreateCampaign = onCreateCampaign,
        onOpenCampaigns = onOpenCampaigns,
        onOpenHistory = onOpenHistory,
        onOpenAnalytics = onOpenAnalytics
    )
}

@Composable
private fun HomeContent(
    uiState: AppUiState,
    onMenu: () -> Unit,
    onOpenLists: () -> Unit,
    onCreateCampaign: () -> Unit,
    onOpenCampaigns: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenAnalytics: () -> Unit
) {
    val campaigns = uiState.lists
    val active = uiState.campaign.status == CS.RUNNING || uiState.campaign.status == CS.PAUSED || uiState.campaign.status == CS.WAITING
    val activeList = campaigns.firstOrNull { it.id == uiState.campaign.listId }
    val activeStats = activeList?.let(::homeStats)
    val todayCalls = uiState.log.count { it.time.isToday() }
    val todayAnswered = uiState.log.count { it.time.isToday() && St.isAnswered(it.status) }
    val todayNoAnswer = uiState.log.count { it.time.isToday() && it.status == CallStatus.NO_ANSWER }
    val totalAnswered = uiState.log.count { St.isAnswered(it.status) }
    val totalCalls = uiState.log.size
    val answerRate = if (totalCalls == 0) 0 else (totalAnswered * 100 / totalCalls)

    Scaffold(
        topBar = {
            BlendBar(
                T("Home", "الرئيسية"),
                onMenu,
                subtitle = T("Your calling workspace", "مساحة عمل الاتصال الخاصة بك")
            )
        },
        containerColor = Color.Transparent
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xxxl),
            verticalArrangement = Arrangement.spacedBy(Sp.xl)
        ) {
            if (campaigns.isEmpty()) {
                item {
                    O2Card(Modifier.fillMaxWidth()) {
                        O2EmptyState(
                            icon = Icons.Rounded.Campaign,
                            title = T("Build your first campaign", "أنشئ حملتك الأولى"),
                            message = T(
                                "Import contacts, set your calling preferences, and start your first automated campaign.",
                                "استورد جهات الاتصال، اضبط إعدادات الاتصال، وابدأ أول حملة اتصال آلية."
                            ),
                            modifier = Modifier.padding(horizontal = Sp.l, vertical = Sp.xxl),
                            action = {
                                O2Button(
                                    T("Create Campaign", "إنشاء حملة"),
                                    onClick = onCreateCampaign,
                                    icon = Icons.Rounded.Add,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        )
                    }
                }
            } else if (active) {
                item {
                    ActiveCampaignHero(
                        name = uiState.campaign.listName.ifBlank { activeList?.name ?: T("Active campaign", "الحملة النشطة") },
                        stats = activeStats,
                        runtimeMessage = uiState.campaign.message,
                        onOpen = onOpenCampaigns
                    )
                }
            } else {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                        Text(T("Good to go", "جاهز للبدء"), style = MaterialTheme.typography.headlineMedium)
                        Text(
                            T("Pick a campaign when you're ready to start calling.", "اختر حملة عندما تكون مستعدًا لبدء الاتصال."),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        O2Button(T("Open campaigns", "فتح الحملات"), onOpenCampaigns, icon = Icons.Rounded.Campaign)
                    }
                }
            }

            item {
                HomeMetricStrip(
                    totalCampaigns = campaigns.size,
                    todayCalls = todayCalls,
                    answered = todayAnswered,
                    unanswered = todayNoAnswer,
                    answerRate = answerRate
                )
            }

            if (active) {
                item {
                    CompactMetricRow(
                        label = T("Remaining", "المتبقي"),
                        value = activeStats?.remaining?.toString() ?: "—",
                        supporting = T("in active campaign", "في الحملة النشطة"),
                        icon = Icons.Rounded.PendingActions,
                        accent = MaterialTheme.colorScheme.primary
                    )
                }
            }

            item {
                SectionLabel(T("Recent activity", "النشاط الأخير"))
            }

            if (uiState.log.isEmpty()) {
                item {
                    O2ListRow(
                        title = T("No calls yet", "لا توجد مكالمات بعد"),
                        subtitle = T("Your recent call activity will appear here.", "سيظهر نشاط مكالماتك الأخير هنا."),
                        leading = { IconTile(Icons.Rounded.History) },
                        onClick = onOpenHistory
                    )
                }
            } else {
                items(uiState.log.take(5), key = { it.id }) { log ->
                    RecentActivityRow(log, onClick = onOpenHistory)
                }
            }

            item {
                SectionLabel(T("Workspace", "مساحة العمل"))
            }
            item {
                O2ListRow(
                    T("Lists", "القوائم"),
                    subtitle = T("Manage contacts and campaign lists", "إدارة جهات الاتصال وقوائم الحملات"),
                    leading = { IconTile(Icons.Rounded.List) },
                    onClick = onOpenLists
                )
            }
            item {
                O2ListRow(
                    T("Analytics", "التحليلات"),
                    subtitle = T("Understand campaign performance", "فهم أداء الحملات"),
                    leading = { IconTile(Icons.Rounded.BarChart) },
                    onClick = onOpenAnalytics
                )
            }
        }
    }
}

@Composable
private fun ActiveCampaignHero(
    name: String,
    stats: HomeStats?,
    runtimeMessage: String,
    onOpen: () -> Unit
) {
    O2Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.xl), verticalArrangement = Arrangement.spacedBy(Sp.l)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                O2StatusIndicator(T("Active campaign", "حملة نشطة"), Sem.success)
                Spacer(Modifier.weight(1f))
                O2Badge(
                    when {
                        runtimeMessage.contains("pause", true) || runtimeMessage.contains("استرد", true) -> T("Paused", "متوقفة")
                        else -> T("Running", "تعمل")
                    },
                    Sem.success
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(name, style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    runtimeMessage.ifBlank { T("Automated calling is ready.", "الاتصال الآلي جاهز.") },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (stats != null) {
                O2ProgressBar(stats.progress)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    NumText("${stats.called}/${stats.total}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
                    NumText("${stats.progressPercent}%", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.xl)) {
                    HeroMetric(T("Remaining", "المتبقي"), stats.remaining.toString())
                    HeroMetric(T("Answered", "تم الرد"), stats.answered.toString())
                    HeroMetric(T("Rate", "النسبة"), "${stats.answerRate}%")
                }
            }
            O2Button(T("Open active campaign", "فتح الحملة النشطة"), onOpen, icon = Icons.Rounded.Call, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun RowScope.HeroMetric(label: String, value: String) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        NumText(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold))
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HomeMetricStrip(
    totalCampaigns: Int,
    todayCalls: Int,
    answered: Int,
    unanswered: Int,
    answerRate: Int
) {
    O2Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.l)) {
            Text(T("Today", "اليوم"), style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                MetricCell(T("Campaigns", "الحملات"), totalCampaigns.toString(), Icons.Rounded.Campaign)
                MetricCell(T("Calls", "المكالمات"), todayCalls.toString(), Icons.Rounded.Phone)
                MetricCell(T("Answered", "تم الرد"), answered.toString(), Icons.Rounded.CheckCircle)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                MetricCell(T("Unanswered", "بدون رد"), unanswered.toString(), Icons.Rounded.PhoneMissed, Sem.warning)
                MetricCell(T("Answer rate", "نسبة الرد"), "$answerRate%", Icons.Rounded.Percent, MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RowScope.MetricCell(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color = MaterialTheme.colorScheme.primary) {
    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(O2IconSizes.md))
        Spacer(Modifier.width(Sp.s))
        Column {
            NumText(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun CompactMetricRow(label: String, value: String, supporting: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color) {
    O2ListRow(
        title = label,
        subtitle = supporting,
        leading = { IconTile(icon, accent, 40.dp) },
        trailing = { NumText(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold), color = accent) }
    )
}

@Composable
private fun RecentActivityRow(log: LogItem, onClick: () -> Unit) {
    O2ListRow(
        title = log.name.ifBlank { log.number },
        subtitle = "${log.listName} • ${St.label(log.status)} • ${formatActivityTime(log.time)}",
        leading = { IconTile(if (St.isAnswered(log.status)) Icons.Rounded.CheckCircle else Icons.Rounded.Phone, if (St.isAnswered(log.status)) Sem.success else MaterialTheme.colorScheme.primary, 40.dp) },
        trailing = { NumText(formatDuration(log.duration), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        onClick = onClick
    )
}

private data class HomeStats(
    val total: Int,
    val called: Int,
    val answered: Int,
    val remaining: Int,
    val answerRate: Int,
    val progress: Float,
    val progressPercent: Int
)

private fun homeStats(list: CallList): HomeStats {
    val total = list.entries.size
    val called = list.entries.count { it.status != St.PENDING }
    val answered = list.entries.count { St.isAnswered(it.status) }
    val remaining = (total - called).coerceAtLeast(0)
    val rate = if (called == 0) 0 else answered * 100 / called
    val percent = if (total == 0) 0 else called * 100 / total
    return HomeStats(total, called, answered, remaining, rate, (percent / 100f).coerceIn(0f, 1f), percent)
}

private fun Long.isToday(): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = this@isToday }
    return now.get(Calendar.ERA) == date.get(Calendar.ERA) &&
        now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR)
}

private fun formatActivityTime(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

private fun formatDuration(seconds: Int): String = when {
    seconds <= 0 -> ""
    seconds < 60 -> "${seconds}s"
    else -> "${seconds / 60}m ${seconds % 60}s"
}

@Composable
fun CampaignsScreen(onMenu: () -> Unit, onOpen: (String) -> Unit, onStart: (String) -> Unit, onCreate: () -> Unit) {
    val activeId = com.o2dialer.app.core.data.Store.camp.listId.takeIf { com.o2dialer.app.core.data.Store.campActive() }
    Scaffold(
        topBar = { BlendBar(T("Campaigns", "الحملات"), onMenu, subtitle = T("Create and run professional calling workflows", "أنشئ وشغّل حملات اتصال احترافية")) },
        containerColor = Color.Transparent
    ) { pad ->
        if (com.o2dialer.app.core.data.Store.lists.isEmpty()) {
            O2EmptyState(
                Icons.Rounded.Campaign,
                T("No campaigns yet", "لا توجد حملات بعد"),
                T("Create a list first, then use it as a campaign.", "أنشئ قائمة أولًا ثم استخدمها كحملة."),
                Modifier.padding(pad).fillMaxSize(),
                action = { O2Button(T("Open lists", "فتح القوائم"), onClick = { com.o2dialer.app.core.data.Store.tab = 0 }, icon = Icons.Rounded.List) }
            )
        } else {
            androidx.compose.foundation.lazy.LazyColumn(
                Modifier.padding(pad),
                contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xxl),
                verticalArrangement = Arrangement.spacedBy(Sp.m)
            ) {
                if (activeId != null) item {
                    Banner(Tk.INFO, T("Campaign running", "حملة قيد التشغيل"), com.o2dialer.app.core.data.Store.camp.listName)
                }
                item { O2Button(T("Create Campaign", "إنشاء حملة"), onCreate, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add) }
            items(com.o2dialer.app.core.data.Store.lists, key = { it.id }) { list ->
                    val p = com.o2dialer.app.core.data.Store.prog(list)
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                                IconTile(Icons.Rounded.Campaign)
                                Column(Modifier.weight(1f)) {
                                    Text(list.name, style = MaterialTheme.typography.titleMedium)
                                    Text(T("${p.total} contacts · ${p.called} called", "${p.total} جهة · ${p.called} تم الاتصال"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (activeId == list.id) O2Badge(T("Running", "تعمل"), Sem.success)
                            }
                            O2ProgressBar(p.pct / 100f)
                            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                                O2Button(T("Open", "فتح"), { onOpen(list.id) }, Modifier.weight(1f), icon = Icons.Rounded.OpenInNew)
                                if (activeId != list.id) O2Button(
                                    if (p.called == 0) T("Start", "بدء") else if (p.remaining > 0) T("Resume", "استئناف") else T("Restart", "إعادة"),
                                    { onStart(list.id) }, Modifier.weight(1f), kind = BtnKind.Tonal, icon = Icons.Rounded.PlayArrow
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
