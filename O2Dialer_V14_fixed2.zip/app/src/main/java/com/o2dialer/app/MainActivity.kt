@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.o2dialer.app.core.data.AppContainer
import com.o2dialer.app.core.data.Store
import com.o2dialer.app.presentation.AppViewModel
import com.o2dialer.app.presentation.AppViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null
    private var pendingDeepLink: O2NavState? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        Store.permTick++
        if (has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
        else Store.notify(Tk.ERROR, T("Calling and phone-state permissions are required", "صلاحيات الاتصال وحالة الهاتف مطلوبة"))
        afterPerms = null
    }

    private val contactsLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) afterContacts?.invoke()
        else Store.notify(Tk.ERROR, T("Contacts permission was denied", "تم رفض صلاحية جهات الاتصال"))
        afterContacts = null
    }

    fun consumePendingDeepLink(): O2NavState? = pendingDeepLink.also { pendingDeepLink = null }

    fun ensureContacts(after: () -> Unit) {
        if (has(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    fun requestCallPermissions(after: (() -> Unit)? = null) {
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !has(it) }
        if (missing.isEmpty()) { after?.invoke(); return }
        afterPerms = after
        permLauncher.launch(missing.toTypedArray())
    }

    fun startCampaign(listId: String, restart: Boolean = false) {
        if (Store.campActive()) {
            Store.notify(Tk.INFO, T("A campaign is already running", "توجد حملة جارية بالفعل"))
            Store.tab = 1
            return
        }
        requestCallPermissions {
            Store.runListId = listId
            Store.tab = 1
            DialerService.send(this, DialerService.ACT_START, listId, restart)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        pendingDeepLink = parseO2DeepLink(intent.data)
        setContent {
            val dir = if (Store.cfg.lang == 1) LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(LocalLayoutDirection provides dir) { AppTheme { Root(this@MainActivity) } }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDeepLink = parseO2DeepLink(intent?.data)
    }

    override fun onResume() {
        super.onResume()
        Store.permTick++
    }
}

@Composable
fun Root(act: MainActivity) {
    val vm: AppViewModel = viewModel(factory = AppViewModelFactory(AppContainer.get().runtime))
    val uiState by vm.uiState.collectAsStateWithLifecycle()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val activity = LocalContext.current as Activity

    var nav by rememberSaveable(stateSaver = O2NavSaver) { mutableStateOf(O2NavState()) }
    var history by rememberSaveable { mutableStateOf(listOf(O2Destination.HOME.route)) }
    var initialized by rememberSaveable { mutableStateOf(false) }

    fun go(destination: O2Destination, listId: String? = null, replace: Boolean = false) {
        val next = O2NavState(destination, listId)
        if (!replace && (nav.destination != destination || nav.selectedListId != listId)) {
            history = (history + destination.route).takeLast(20)
        }
        nav = next
        Store.selectedListId = listId
        Store.tab = destination.toLegacyTab()
        if (destination == O2Destination.ANALYTICS) Store.resultsListId = listId ?: Store.resultsListId
        scope.launch { drawer.close() }
    }

    LaunchedEffect(Unit) {
        if (!initialized) {
            val deepLink = act.consumePendingDeepLink()
            if (deepLink != null) go(deepLink.destination, deepLink.selectedListId, replace = true)
            else go(O2Destination.HOME, replace = true)
            initialized = true
        }
    }

    // Legacy screens still mutate Store.tab. Translate those changes into the new product IA.
    LaunchedEffect(Store.selectedListId) {
        if (!initialized) return@LaunchedEffect
        if ((nav.destination == O2Destination.LISTS || nav.destination == O2Destination.CAMPAIGNS) && nav.selectedListId != Store.selectedListId) {
            nav = O2NavState(nav.destination, Store.selectedListId)
        }
    }

    LaunchedEffect(Store.tab) {
        if (!initialized) return@LaunchedEffect
        val legacy = when (Store.tab) {
            1 -> O2Destination.CAMPAIGNS
            2 -> O2Destination.ANALYTICS
            3 -> O2Destination.HISTORY
            4 -> O2Destination.SETTINGS
            else -> if (nav.destination == O2Destination.LISTS || nav.destination == O2Destination.HOME) nav.destination else O2Destination.HOME
        }
        if (legacy != nav.destination) nav = O2NavState(legacy, Store.selectedListId)
    }

    val keep = uiState.cfg.keepScreenOn && (uiState.campaign.status == CS.RUNNING || uiState.campaign.status == CS.WAITING)
    LaunchedEffect(keep) {
        if (keep) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    LaunchedEffect(uiState.pendingResultsNavigation) {
        if (uiState.pendingResultsNavigation) {
            go(O2Destination.ANALYTICS, uiState.campaign.listId, replace = false)
            Store.pendingResultsNav = false
            Store.publishRuntime()
        }
    }

    BackHandler(enabled = drawer.isOpen || history.size > 1 || nav.destination != O2Destination.HOME || nav.selectedListId != null) {
        when {
            drawer.isOpen -> scope.launch { drawer.close() }
            nav.selectedListId != null && (nav.destination == O2Destination.LISTS || nav.destination == O2Destination.CAMPAIGNS) -> {
                nav = O2NavState(nav.destination, null); Store.selectedListId = null
            }
            history.size > 1 -> {
                val trimmed = history.dropLast(1)
                history = trimmed
                val route = trimmed.lastOrNull() ?: O2Destination.HOME.route
                val destination = O2Destination.entries.firstOrNull { it.route == route } ?: O2Destination.HOME
                nav = O2NavState(destination)
                Store.selectedListId = null
                Store.tab = destination.toLegacyTab()
            }
            else -> go(O2Destination.HOME, replace = true)
        }
    }

    val cs = MaterialTheme.colorScheme
    val drawerItems = listOf(
        O2Destination.HOME to Icons.Rounded.Home,
        O2Destination.LISTS to Icons.Rounded.List,
        O2Destination.CAMPAIGNS to Icons.Rounded.Campaign,
        O2Destination.HISTORY to Icons.Rounded.History,
        O2Destination.ANALYTICS to Icons.Rounded.BarChart,
        O2Destination.SETTINGS to Icons.Rounded.Settings
    )

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = cs.surface) {
                Box(Modifier.fillMaxWidth().background(Brand).padding(horizontal = Sp.xxl, vertical = Sp.xxxl)) {
                    Column(verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                        LogoMark(56.dp)
                        Text("O2Dialer", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                        Text(T("Smart calling, beautifully simple", "اتصال ذكي بكل بساطة"), color = Color.White.copy(alpha = .85f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(Sp.m))
                drawerItems.forEach { (destination, icon) ->
                    O2NavigationItem(
                        label = destination.title(),
                        selected = nav.destination == destination && nav.selectedListId == null,
                        icon = icon,
                        onClick = { go(destination) },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
                Spacer(Modifier.weight(1f))
                Text("v3.1", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = Sp.xxl, vertical = Sp.l))
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
            val screenKey = "${nav.destination.route}:${nav.selectedListId ?: "root"}"
            Responsive {
                AnimatedContent(targetState = screenKey, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) }, label = "o2-navigation") {
                    when (nav.destination) {
                        O2Destination.HOME -> HomeScreen(
                            onMenu = { scope.launch { drawer.open() } },
                            onOpenLists = { go(O2Destination.LISTS) },
                            onCreateCampaign = { go(O2Destination.LISTS) },
                            onOpenCampaigns = { go(O2Destination.CAMPAIGNS) },
                            onOpenHistory = { go(O2Destination.HISTORY) },
                            onOpenAnalytics = { go(O2Destination.ANALYTICS) }
                        )
                        O2Destination.LISTS -> if (nav.selectedListId != null) ListDetail(nav.selectedListId!!, act) else ListsScreen { scope.launch { drawer.open() } }
                        O2Destination.CAMPAIGNS -> if (nav.selectedListId == "__create__") CampaignCreator(
                            onBack = { go(O2Destination.CAMPAIGNS, null) },
                            onStart = { act.startCampaign(it) },
                            onSaved = { go(O2Destination.CAMPAIGNS, null) }
                        ) else if (nav.selectedListId != null) ListDetail(nav.selectedListId!!, act) else CampaignsScreen(
                            onMenu = { scope.launch { drawer.open() } },
                            onOpen = { go(O2Destination.CAMPAIGNS, it) },
                            onStart = { act.startCampaign(it) },
                            onCreate = { go(O2Destination.CAMPAIGNS, "__create__") }
                        )
                        O2Destination.HISTORY -> HistoryScreen { scope.launch { drawer.open() } }
                        O2Destination.ANALYTICS -> ResultsScreen { scope.launch { drawer.open() } }
                        O2Destination.SETTINGS -> SettingsScreen()
                    }
                }
            }
            ToastHost(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp, start = Sp.l, end = Sp.l))
            Store.stageTarget?.let { (lid, eid) -> StageSheet(lid, eid) }
        }
    }
}

private val O2NavSaver = androidx.compose.runtime.saveable.Saver<O2NavState, List<String>>(
    save = { listOf(it.destination.route, it.selectedListId ?: "") },
    restore = { saved ->
        val destination = O2Destination.entries.firstOrNull { it.route == saved.getOrNull(0) } ?: O2Destination.HOME
        O2NavState(destination, saved.getOrNull(1)?.takeIf(String::isNotBlank))
    }
)
