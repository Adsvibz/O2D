package com.o2dialer.app.core.data

import android.content.Context
import android.content.SharedPreferences
import com.o2dialer.app.Cfg
import com.o2dialer.app.CampState
import com.o2dialer.app.CallList
import com.o2dialer.app.Entry
import com.o2dialer.app.LogItem
import com.o2dialer.app.St
import com.o2dialer.app.core.domain.model.CampaignProfile
import com.o2dialer.app.core.domain.model.CampaignHistory
import com.o2dialer.app.core.domain.model.CampaignContact
import org.json.JSONArray
import org.json.JSONObject

private const val KEY_CFG = "cfg"
private const val KEY_LISTS = "lists"
private const val KEY_LOG = "log"
private const val KEY_RUNTIME = "campaign_runtime"
private const val KEY_CAMPAIGNS = "campaign_profiles"
private const val KEY_HISTORY = "campaign_history_v1"

/** Persistence boundary. Implementations can later be replaced by Room/SQLite without changing callers. */
interface SettingsRepository {
    fun load(): Cfg
    fun save(value: Cfg)
}

interface CampaignRepository {
    fun loadLists(): List<CallList>
    fun saveLists(value: List<CallList>)
    fun loadLog(): List<LogItem>
    fun saveLog(value: List<LogItem>)
    fun loadRuntime(): CampState?
    fun saveRuntime(value: CampState)
    fun clearRuntime()
    fun loadCampaignProfiles(): List<CampaignProfile>
    fun saveCampaignProfiles(value: List<CampaignProfile>)
    fun loadCampaignHistory(): List<CampaignHistory>
    fun saveCampaignHistory(value: List<CampaignHistory>)
}

interface DataRepository : SettingsRepository, CampaignRepository

private class SharedPreferencesDataRepository(
    private val preferences: SharedPreferences
) : DataRepository {
    override fun load(): Cfg = runCatching {
        preferences.getString(KEY_CFG, null)?.let { Cfg.fromJson(JSONObject(it)) } ?: Cfg()
    }.getOrDefault(Cfg())

    override fun save(value: Cfg) {
        preferences.edit().putString(KEY_CFG, value.toJson().toString()).apply()
    }

    override fun loadLists(): List<CallList> = runCatching {
        val raw = preferences.getString(KEY_LISTS, null) ?: return emptyList()
        val a = JSONArray(raw)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val listId = o.getString("id")
                val ea = o.getJSONArray("entries")
                val entries = buildList {
                    for (k in 0 until ea.length()) {
                        val e = ea.getJSONObject(k)
                        val status = e.optInt("status")
                        add(Entry(
                            id = e.getString("id"),
                            name = e.optString("name"),
                            number = e.getString("number"),
                            displayNumber = e.optString("displayNumber", e.optString("number")),
                            campaignId = e.optString("campaignId", listId),
                            contactId = e.optString("contactId", e.getString("id")),
                            status = if (status == St.CALLING) St.PENDING else status,
                            attempts = e.optInt("attempts"),
                            duration = e.optInt("duration"),
                            calledAt = e.optLong("calledAt"),
                            stage = e.optInt("stage"),
                            feedback = e.optString("feedback")
                        ))
                    }
                }
                add(CallList(o.getString("id"), o.getString("name"), entries, o.optInt("sim", -1)))
            }
        }
    }.getOrDefault(emptyList())

    override fun saveLists(value: List<CallList>) {
        val a = JSONArray()
        value.forEach { list ->
            val entries = JSONArray()
            list.entries.forEach { e ->
                entries.put(JSONObject()
                    .put("id", e.id).put("name", e.name).put("number", e.number)
                    .put("displayNumber", e.displayNumber.ifBlank { e.number })
                    .put("campaignId", e.campaignId.ifEmpty { list.id })
                    .put("contactId", e.contactId.ifEmpty { e.id })
                    .put("status", e.status).put("attempts", e.attempts).put("duration", e.duration)
                    .put("calledAt", e.calledAt).put("stage", e.stage).put("feedback", e.feedback))
            }
            a.put(JSONObject().put("id", list.id).put("name", list.name).put("sim", list.simSlot).put("entries", entries))
        }
        // Keep the original key for backward compatibility with O2Dialer 3.x installs.
        preferences.edit().putString(KEY_LISTS, a.toString()).commit()
    }

    override fun loadLog(): List<LogItem> = runCatching {
        val raw = preferences.getString(KEY_LOG, null) ?: return emptyList()
        val a = JSONArray(raw)
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(LogItem(
                    time = o.optLong("t"), listName = o.optString("l"), name = o.optString("n"),
                    number = o.optString("p"), status = o.optInt("s"), duration = o.optInt("d"),
                    attempt = o.optInt("a"), campaignId = o.optString("c"), contactId = o.optString("contact")
                ))
            }
        }
    }.getOrDefault(emptyList())

    override fun saveLog(value: List<LogItem>) {
        val a = JSONArray()
        value.forEach { item ->
            a.put(JSONObject().put("t", item.time).put("l", item.listName).put("n", item.name)
                .put("p", item.number).put("s", item.status).put("d", item.duration).put("a", item.attempt)
                .put("c", item.campaignId).put("contact", item.contactId))
        }
        preferences.edit().putString(KEY_LOG, a.toString()).apply()
    }

    override fun loadRuntime(): CampState? = runCatching {
        preferences.getString(KEY_RUNTIME, null)?.let { o ->
            val j = JSONObject(o)
            CampState(
                status = j.optInt("status", 0), listId = j.optString("listId"), listName = j.optString("listName"),
                currentName = j.optString("currentName"), currentNumber = j.optString("currentNumber"),
                message = j.optString("message"), loop = j.optInt("loop", 1), loops = j.optInt("loops", 1),
                nextAt = j.optLong("nextAt", 0), awaitingStage = j.optBoolean("awaitingStage", false),
                error = j.optBoolean("error", false),
                queue = j.optJSONArray("queue")?.let { a ->
                    buildList { for (i in 0 until a.length()) add(a.optString(i)) }
                } ?: emptyList(),
                retriesLeft = j.optJSONObject("retriesLeft")?.let { o ->
                    buildMap {
                        o.keys().forEach { key -> put(key, o.optInt(key, 0)) }
                    }
                } ?: emptyMap(),
                currentEntryId = j.optString("currentEntryId").takeIf { it.isNotBlank() },
                currentPhase = j.optInt("currentPhase", com.o2dialer.app.core.domain.model.CampaignPhase.IDLE),
                callStartedAt = j.optLong("callStartedAt", 0),
                offhookAt = j.optLong("offhookAt", 0),
                simSlot = j.optInt("simSlot", -1),
                sessionId = j.optString("sessionId"),
                startedAt = j.optLong("startedAt", 0),
                checkpointAt = j.optLong("checkpointAt", System.currentTimeMillis())
            )
        }
    }.getOrNull()

    override fun saveRuntime(value: CampState) {
        val queue = JSONArray().apply { value.queue.forEach { put(it) } }
        val retries = JSONObject().apply { value.retriesLeft.forEach { (id, left) -> put(id, left) } }
        // Runtime checkpoints are crash-safety data. Use commit() so a process kill
        // immediately after a checkpoint cannot silently lose the logical cursor.
        preferences.edit().putString(KEY_RUNTIME, JSONObject()
            .put("status", value.status).put("listId", value.listId).put("listName", value.listName)
            .put("currentName", value.currentName).put("currentNumber", value.currentNumber).put("message", value.message)
            .put("loop", value.loop).put("loops", value.loops).put("nextAt", value.nextAt)
            .put("awaitingStage", value.awaitingStage).put("error", value.error)
            .put("queue", queue).put("retriesLeft", retries)
            .put("currentEntryId", value.currentEntryId ?: "")
            .put("currentPhase", value.currentPhase)
            .put("callStartedAt", value.callStartedAt).put("offhookAt", value.offhookAt)
            .put("simSlot", value.simSlot).put("sessionId", value.sessionId)
            .put("startedAt", value.startedAt)
            .put("checkpointAt", value.checkpointAt).toString()).commit()
    }

    override fun clearRuntime() { preferences.edit().remove(KEY_RUNTIME).apply() }

    override fun loadCampaignProfiles(): List<CampaignProfile> = runCatching {
        val raw = preferences.getString(KEY_CAMPAIGNS, null) ?: return emptyList()
        val a = JSONArray(raw)
        buildList {
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                add(CampaignProfile(
                    id = j.optString("id"), name = j.optString("name"),
                    contactListId = j.optString("listId"), simSlot = j.optInt("sim", -1),
                    settings = Cfg.fromJson(j.optJSONObject("settings") ?: JSONObject())
                ))
            }
        }
    }.getOrDefault(emptyList())

    override fun saveCampaignProfiles(value: List<CampaignProfile>) {
        val a = JSONArray()
        value.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("listId", c.contactListId)
                .put("sim", c.simSlot).put("settings", c.settings.toJson()))
        }
        preferences.edit().putString(KEY_CAMPAIGNS, a.toString()).apply()
    }

    override fun loadCampaignHistory(): List<CampaignHistory> = runCatching {
        val raw = preferences.getString(KEY_HISTORY, null) ?: return emptyList()
        val a = JSONArray(raw)
        buildList {
            for (i in 0 until a.length()) {
                val h = a.getJSONObject(i)
                val ea = h.optJSONArray("entries") ?: JSONArray()
                val entries = buildList {
                    for (k in 0 until ea.length()) {
                        val e = ea.getJSONObject(k)
                        add(CampaignContact(
                            id = e.optString("id"), name = e.optString("name"), number = e.optString("number"),
                            displayNumber = e.optString("displayNumber", e.optString("number")), campaignId = e.optString("campaignId"),
                            contactId = e.optString("contactId"), status = e.optInt("status"), attempts = e.optInt("attempts"),
                            duration = e.optInt("duration"), calledAt = e.optLong("calledAt"), stage = e.optInt("stage"), feedback = e.optString("feedback")
                        ))
                    }
                }
                add(CampaignHistory(h.optString("id"), h.optString("sessionId"), h.optString("name"), h.optLong("startedAt"), h.optLong("completedAt"), h.optString("state"), entries))
            }
        }
    }.getOrDefault(emptyList())

    override fun saveCampaignHistory(value: List<CampaignHistory>) {
        val a = JSONArray()
        value.forEach { h ->
            val ea = JSONArray()
            h.entries.forEach { e ->
                ea.put(JSONObject().put("id", e.id).put("name", e.name).put("number", e.number).put("displayNumber", e.displayNumber)
                    .put("campaignId", e.campaignId).put("contactId", e.contactId).put("status", e.status).put("attempts", e.attempts)
                    .put("duration", e.duration).put("calledAt", e.calledAt).put("stage", e.stage).put("feedback", e.feedback))
            }
            a.put(JSONObject().put("id", h.id).put("sessionId", h.sessionId).put("name", h.campaignName)
                .put("startedAt", h.startedAt).put("completedAt", h.completedAt).put("state", h.completionState).put("entries", ea))
        }
        preferences.edit().putString(KEY_HISTORY, a.toString()).commit()
    }
}

class AppContainer private constructor(context: Context) {
    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    val data: DataRepository = SharedPreferencesDataRepository(preferences)
    val settings: SettingsRepository = data
    val campaigns: CampaignRepository = data
    val runtime = RuntimeStateRepository()

    companion object {
        private const val PREFERENCES_NAME = "o2dialer"

        @Volatile private var instance: AppContainer? = null

        fun initialize(context: Context): AppContainer =
            instance ?: synchronized(this) { instance ?: AppContainer(context).also { instance = it } }

        fun get(): AppContainer = instance
            ?: error("AppContainer is not initialized. Call initialize() from Application.onCreate().")
    }
}
