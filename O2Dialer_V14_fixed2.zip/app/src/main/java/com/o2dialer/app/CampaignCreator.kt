@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.data.Store
import com.o2dialer.app.core.domain.model.CampaignProfile

@Composable
fun CampaignCreator(
    onBack: () -> Unit,
    onStart: (String) -> Unit,
    onSaved: () -> Unit
) {
    val lists = Store.lists.toList()
    var selectedListId by remember { mutableStateOf(lists.firstOrNull()?.id) }
    var name by remember { mutableStateOf(lists.firstOrNull()?.name ?: "") }
    var sim by remember { mutableIntStateOf(lists.firstOrNull()?.simSlot ?: -1) }
    var cfg by remember { mutableStateOf(Store.profileFor(selectedListId ?: "")?.settings ?: Store.cfg) }
    val selected = lists.firstOrNull { it.id == selectedListId }

    fun selectList(id: String) {
        selectedListId = id
        val l = lists.firstOrNull { it.id == id }
        val profile = Store.profileFor(id)
        name = profile?.name ?: l?.name ?: ""
        sim = profile?.simSlot ?: l?.simSlot ?: -1
        cfg = profile?.settings ?: Store.cfg
    }

    Scaffold(
        topBar = {
            O2BackAppBar(
                title = T("Create Campaign", "إنشاء حملة"),
                onBack = onBack
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(Sp.l).navigationBarsPadding(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                    O2Button(T("Save Campaign", "حفظ الحملة"), {
                        val id = selectedListId
                        if (id != null) {
                            Store.saveCampaignProfile(CampaignProfile(name = name.trim(), contactListId = id, simSlot = sim, settings = cfg))
                            Store.updateList(id) { it.copy(simSlot = sim) }
                            Store.notify(Tk.SUCCESS, T("Campaign saved", "تم حفظ الحملة"))
                            onSaved()
                        }
                    }, Modifier.weight(1f), kind = BtnKind.Tonal, icon = Icons.Rounded.Save, enabled = name.isNotBlank() && selected != null)
                    O2Button(T("Start Campaign", "بدء الحملة"), {
                        val id = selectedListId
                        if (id != null) {
                            Store.updateCfg { cfg }
                            Store.updateList(id) { it.copy(simSlot = sim) }
                            Store.saveCampaignProfile(CampaignProfile(name = name.trim(), contactListId = id, simSlot = sim, settings = cfg))
                            onStart(id)
                        }
                    }, Modifier.weight(1f), icon = Icons.Rounded.PlayArrow, enabled = name.isNotBlank() && selected != null && selected.entries.isNotEmpty())
                }
            }
        }, containerColor = Color.Transparent
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xxl), verticalArrangement = Arrangement.spacedBy(Sp.l)) {
            item { CreatorIntro(name, selected?.entries?.size ?: 0) }
            item { CreatorSection(Icons.Rounded.Badge, T("1 · Campaign identity", "١ · هوية الحملة")) {
                O2TextField(name, { name = it }, label = T("Campaign name", "اسم الحملة"), leadingIcon = Icons.Rounded.Campaign)
            } }
            item { CreatorSection(Icons.Rounded.List, T("2 · Contact list", "٢ · قائمة جهات الاتصال")) {
                if (lists.isEmpty()) EmptyState(Icons.Rounded.Groups, T("No contact lists", "لا توجد قوائم"), T("Create a contact list before starting a campaign.", "أنشئ قائمة جهات اتصال قبل بدء الحملة."))
                else lists.forEach { l ->
                    SelectRow(l.name, T("${l.entries.size} contacts", "${l.entries.size} جهة اتصال"), l.id == selectedListId) { selectList(l.id) }
                }
            } }
            item { CreatorSection(Icons.Rounded.SimCard, T("3 · SIM selection", "٣ · اختيار الشريحة")) { SimPicker(sim) { sim = it } } }
            item { CreatorSection(Icons.Rounded.Tune, T("4 · Calling behavior", "٤ · سلوك الاتصال")) {
                NumberSlider(T("Maximum call duration", "أقصى مدة للمكالمة"), cfg.maxCallSec, 0, 600, T("Off", "معطّل")) { cfg = cfg.copy(maxCallSec = it) }
                Toggle(T("Shuffle contacts", "خلط ترتيب جهات الاتصال"), T("Use a randomized calling order", "استخدم ترتيب اتصال عشوائي"), cfg.shuffle) { cfg = cfg.copy(shuffle = it) }
                Toggle(T("Skip answered contacts", "تخطّي من تم الرد عليهم"), T("Keep answered contacts out on restart", "لا تعاود الاتصال بمن تم الرد عليهم عند الاستئناف"), cfg.skipAnswered) { cfg = cfg.copy(skipAnswered = it) }
            } }
            item { CreatorSection(Icons.Rounded.Replay, T("5 · Retry behavior", "٥ · سلوك إعادة المحاولة")) {
                NumberSlider(T("Retry count", "عدد المحاولات الإضافية"), cfg.retries, 0, 5, T("None", "بدون")) { cfg = cfg.copy(retries = it) }
                NumberSlider(T("Rounds", "عدد الجولات"), cfg.loops, 1, 20, "1") { cfg = cfg.copy(loops = it) }
            } }
            item { CreatorSection(Icons.Rounded.Timer, T("6 · Timing", "٦ · التوقيت")) {
                NumberSlider(T("Delay between calls", "الانتظار بين المكالمات"), cfg.delaySec, 0, 120, "0s") { cfg = cfg.copy(delaySec = it) }
                Toggle(T("Randomize delay", "توقيت عشوائي"), T("Vary the delay between calls", "غيّر مدة الانتظار بين المكالمات"), cfg.randomDelay) { cfg = cfg.copy(randomDelay = it) }
                if (cfg.randomDelay) NumberSlider(T("Maximum delay", "أقصى انتظار"), cfg.delayMaxSec, cfg.delaySec.coerceAtLeast(1), 300, "") { cfg = cfg.copy(delayMaxSec = it) }
                NumberSlider(T("Start countdown", "العد التنازلي قبل البدء"), cfg.startCountdown, 0, 30, T("Instant", "فوري")) { cfg = cfg.copy(startCountdown = it) }
            } }
            item { CreatorSection(Icons.Rounded.Schedule, T("7 · Quiet hours", "٧ · ساعات الهدوء")) {
                Toggle(T("Limit calling hours", "تحديد ساعات الاتصال"), T("Pause automatically outside this window", "توقف تلقائيًا خارج هذه الفترة"), cfg.quietEnabled) { cfg = cfg.copy(quietEnabled = it) }
                if (cfg.quietEnabled) {
                    NumberSlider(T("From", "من"), cfg.quietFrom, 0, 23, ":00") { cfg = cfg.copy(quietFrom = it) }
                    NumberSlider(T("To", "إلى"), cfg.quietTo, 0, 23, ":00") { cfg = cfg.copy(quietTo = it) }
                }
            } }
            item { CreatorSection(Icons.Rounded.VolumeUp, T("8 · Audio behavior", "٨ · سلوك الصوت")) {
                Toggle(T("Speaker behavior", "سلوك السماعة"), T("Automatically use speaker during calls", "تشغيل السماعة تلقائيًا أثناء المكالمات"), cfg.autoSpeaker) { cfg = cfg.copy(autoSpeaker = it) }
                Toggle(T("Microphone behavior", "سلوك الميكروفون"), T("Mute microphone automatically", "كتم الميكروفون تلقائيًا"), cfg.autoMuteMic) { cfg = cfg.copy(autoMuteMic = it) }
            } }
            item { CreatorSection(Icons.Rounded.Flag, T("9 · Completion behavior", "٩ · سلوك الإنهاء")) {
                Toggle(T("Ask for call result", "طلب نتيجة المكالمة"), T("Show the stage selector after answered calls", "إظهار نتيجة المكالمة بعد الرد"), cfg.askStage) { cfg = cfg.copy(askStage = it) }
                if (cfg.askStage) NumberSlider(T("Result wait", "وقت انتظار النتيجة"), cfg.stageWaitSec, 0, 60, T("No wait", "بدون انتظار")) { cfg = cfg.copy(stageWaitSec = it) }
                Toggle(T("Vibrate on completion", "اهتزاز عند الإنهاء"), null, cfg.vibrateOnFinish) { cfg = cfg.copy(vibrateOnFinish = it) }
            } }
            item { LiveCampaignSummary(name, selected, sim, cfg) }
        }
    }
}

@Composable private fun CreatorIntro(name: String, count: Int) = O2Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
        Text(T("Campaign workflow", "سير عمل الحملة"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(if (name.isBlank()) T("Configure once. Start with confidence.", "اضبط الحملة مرة واحدة وابدأ بثقة.") else name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(T("$count contacts selected", "تم اختيار $count جهة اتصال"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun CreatorSection(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) = O2Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        content()
    }
}

@Composable private fun SelectRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    O2Card(Modifier.fillMaxWidth(), onClick = onClick) { Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (selected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked, null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(Sp.m)); Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    } }
}

@Composable private fun Toggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) = Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
    Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.bodyLarge); subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    Switch(checked = checked, onCheckedChange = onChange)
}

@Composable private fun NumberSlider(title: String, value: Int, min: Int, max: Int, zeroLabel: String, onChange: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Text(if (value == 0) zeroLabel else value.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
        Slider(value = value.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = min.toFloat()..max.toFloat(), steps = 0)
    }
}

@Composable private fun LiveCampaignSummary(name: String, list: CallList?, sim: Int, cfg: Cfg) {
    O2Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Visibility, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(Sp.s)); Text(T("Live summary", "ملخص مباشر"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            SummaryLine(T("Campaign", "الحملة"), name.ifBlank { T("Untitled", "بدون اسم") })
            SummaryLine(T("Contacts", "جهات الاتصال"), "${list?.entries?.size ?: 0}")
            SummaryLine(T("SIM", "الشريحة"), if (sim < 0) T("Default", "الافتراضية") else "SIM ${sim + 1}")
            SummaryLine(T("Delay", "الانتظار"), if (cfg.randomDelay) "${cfg.delaySec}–${cfg.delayMaxSec}s" else "${cfg.delaySec}s")
            SummaryLine(T("Retries", "المحاولات"), cfg.retries.toString())
            SummaryLine(T("Max duration", "أقصى مدة"), if (cfg.maxCallSec == 0) T("Off", "معطّل") else "${cfg.maxCallSec}s")
            SummaryLine(T("Quiet hours", "ساعات الهدوء"), if (cfg.quietEnabled) "${cfg.quietFrom}:00–${cfg.quietTo}:00" else T("Not limited", "بدون تقييد"))
            SummaryLine(T("Audio", "الصوت"), "${if (cfg.autoSpeaker) "Speaker" else "Earpiece"} · ${if (cfg.autoMuteMic) "Mic muted" else "Mic on"}")
        }
    }
}

@Composable private fun SummaryLine(label: String, value: String) = Row(Modifier.fillMaxWidth()) { Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontWeight = FontWeight.SemiBold) }
