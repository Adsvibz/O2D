package com.o2dialer.app.core.data

import com.o2dialer.app.CallList
import com.o2dialer.app.CampState
import com.o2dialer.app.Cfg
import com.o2dialer.app.LogItem
import com.o2dialer.app.UiToast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-local immutable snapshot shared between UI ViewModels and Android adapters. */
data class AppUiState(
    val lists: List<CallList> = emptyList(),
    val log: List<LogItem> = emptyList(),
    val cfg: Cfg = Cfg(),
    val campaign: CampState = CampState(),
    val selectedListId: String? = null,
    val runListId: String? = null,
    val resultsListId: String? = null,
    val stageTarget: Pair<String, String>? = null,
    val pendingResultsNavigation: Boolean = false,
    val tab: Int = 0,
    val previousTab: Int = 0,
    val toast: UiToast? = null,
    val permissionsRevision: Int = 0
)

class RuntimeStateRepository {
    private val _state = MutableStateFlow(AppUiState())
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    fun publish(state: AppUiState) {
        _state.value = state
    }
}
