@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import com.o2dialer.app.core.data.Store
import com.o2dialer.app.core.domain.campaign.CampaignStatisticsCalculator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private const val FILTER_ALL = 0
private const val FILTER_ANSWERED = 1
private const val FILTER_UNANSWERED = 2
private const val FILTER_FAILED = 3
private const val FILTER_SKIPPED = 4
private const val FILTER_PENDING = 5
private const val FILTER_STAGE_BASE = 100

private fun filterStage(s: Int) = FILTER_STAGE_BASE + s

@Composable
private fun MetricTile(
    label: String,
    value: String,
    color: Color,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(Rd.m))
            .background(color.copy(alpha = if (selected) .16f else .06f))
            .border(if (selected) 2.dp else 1.dp, color.copy(alpha = if (selected) 1f else .22f), RoundedCornerShape(Rd.m))
            .clickable { onClick() }
            .padding(Sp.m),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(value, style = MaterialTheme.typography.headlineSmall, color = color)
    }
}

@Composable
private fun ResultRow(e: Entry, listId: String) {
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.m), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(e.name.ifBlank { e.number }, if (e.stage != Stg.NONE) Stg.color(e.stage) else statusColor(e.status))
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(e.name.ifBlank { T("Unnamed contact", "جهة اتصال بدون اسم") }, style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    NumText(e.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (e.stage == Stg.POTENTIAL || e.stage == Stg.CALL_BACK || e.stage == Stg.WHATSAPP) WhatsAppButton(e.number)
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                StatusPill(e.status)
                if (e.calledAt > 0) Pill(fmtTime(e.calledAt), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.History)
                Pill(fmtDur(e.duration), if (e.duration > 0) Sem.success else MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.Schedule)
                Pill(T("Attempt #${e.attempts}", "المحاولة #${e.attempts}"), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.Replay)
                if (e.stage != Stg.NONE) StagePill(e.stage) { Store.stageTarget = listId to e.id }
                else if (St.isAnswered(e.status)) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) {
                    Store.stageTarget = listId to e.id
                }
            }

            if (e.feedback.isNotBlank()) {
                Text(
                    e.feedback,
                    style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ResultsScreen(onMenu: () -> Unit) {
    val ctx = LocalContext.current
    val sel = Store.resultsListId?.takeIf { id -> Store.lists.any { it.id == id } }
        ?: Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } }
        ?: Store.lists.firstOrNull()?.id
    val list = Store.lists.find { it.id == sel }
    var filter by remember { mutableIntStateOf(FILTER_ALL) }

    Scaffold(
        topBar = {
            BlendBar(T("Campaign Results", "نتائج الحملة"), onMenu, subtitle = list?.name, actions = {
                if (list != null) IconButton(onClick = { shareText(ctx, Store.listReport(list)) }) {
                    Icon(Icons.Rounded.Share, T("Share results", "مشاركة النتائج"))
                }
            })
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (list == null) {
            EmptyState(
                Icons.Rounded.BarChart,
                T("No campaign results", "لا توجد نتائج للحملة"),
                T("Run a campaign and its performance will appear here.", "شغّل حملة وستظهر نتائجها هنا."),
                Modifier.padding(pad),
                actionText = T("Go to campaigns", "الذهاب إلى الحملات"),
                onAction = { Store.tab = 0 }
            )
        } else {
            val stats = CampaignStatisticsCalculator.calculate(list.entries)
            val rows = list.entries.filter { entry ->
                when {
                    filter == FILTER_ALL -> entry.status != St.PENDING && entry.status != St.CALLING
                    filter == FILTER_ANSWERED -> St.isAnswered(entry.status)
                    filter == FILTER_UNANSWERED -> entry.status == St.NO_ANSWER
                    filter == FILTER_FAILED -> entry.status == St.FAILED
                    filter == FILTER_SKIPPED -> entry.status == St.SKIPPED
                    filter == FILTER_PENDING -> entry.status == St.PENDING || entry.status == St.CALLING
                    filter >= FILTER_STAGE_BASE -> entry.stage == filter - FILTER_STAGE_BASE
                    else -> true
                }
            }.sortedByDescending { it.calledAt }

            val answeredShare = if (stats.called == 0) 0f else stats.answered / stats.called.toFloat()
            val completed = stats.total > 0 && stats.remaining == 0

            LazyColumn(
                Modifier.padding(pad),
                contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.l)
            ) {
                if (Store.lists.size > 1) item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                        Store.lists.forEach { l ->
                            FilterChip(
                                selected = l.id == list.id,
                                onClick = { Store.resultsListId = l.id; filter = FILTER_ALL },
                                label = { Text(l.name, maxLines = 1) }
                            )
                        }
                    }
                }

                if (completed) item {
                    Banner(
                        Tk.SUCCESS,
                        T("Campaign completed", "اكتملت الحملة"),
                        T("${stats.answered} answered · ${stats.skipped} skipped", "${stats.answered} ردّوا · ${stats.skipped} تم تخطيهم")
                    )
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(T("Campaign performance", "أداء الحملة"), style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        T("Tap any metric to inspect its calls", "اضغط على أي مؤشر لعرض مكالماته"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text("${stats.percent}%", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
                            }
                            BProgress(stats.percent / 100f)
                            Text(
                                T("${stats.called} called · ${stats.remaining} remaining", "${stats.called} تم الاتصال بهم · ${stats.remaining} متبقي"),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                                MetricTile(T("Total", "الإجمالي"), stats.total.toString(), MaterialTheme.colorScheme.primary,
                                    filter == FILTER_ALL, Icons.Rounded.People, Modifier.weight(1f)) { filter = FILTER_ALL }
                                MetricTile(T("Answered", "ردّوا"), stats.answered.toString(), Sem.success,
                                    filter == FILTER_ANSWERED, Icons.Rounded.Call, Modifier.weight(1f)) { filter = FILTER_ANSWERED }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                                MetricTile(T("Unanswered", "لم يردّوا"), stats.noAnswer.toString(), Sem.warning,
                                    filter == FILTER_UNANSWERED, Icons.Rounded.PhoneMissed, Modifier.weight(1f)) { filter = FILTER_UNANSWERED }
                                MetricTile(T("Failed", "فشل"), stats.failed.toString(), Sem.danger,
                                    filter == FILTER_FAILED, Icons.Rounded.ErrorOutline, Modifier.weight(1f)) { filter = FILTER_FAILED }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                                MetricTile(T("Skipped", "تم التخطي"), stats.skipped.toString(), MaterialTheme.colorScheme.secondary,
                                    filter == FILTER_SKIPPED, Icons.Rounded.SkipNext, Modifier.weight(1f)) { filter = FILTER_SKIPPED }
                                MetricTile(T("Remaining", "متبقي"), stats.remaining.toString(), MaterialTheme.colorScheme.onSurfaceVariant,
                                    filter == FILTER_PENDING, Icons.Rounded.PendingActions, Modifier.weight(1f)) { filter = FILTER_PENDING }
                            }
                        }
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                        SmallStatCard(T("Total call time", "إجمالي وقت المكالمات"), fmtDur(stats.totalCallTimeSeconds.toInt()), Icons.Rounded.Timer, Modifier.weight(1f))
                        SmallStatCard(T("Average duration", "متوسط مدة المكالمة"), fmtDur(stats.averageCallDurationSeconds), Icons.Rounded.Speed, Modifier.weight(1f))
                    }
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(T("Answer rate", "نسبة الرد"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Text("${stats.answerRate}%", style = MaterialTheme.typography.titleMedium, color = Sem.success)
                            }
                            BProgress(answeredShare, color = Sem.success, track = Sem.success.copy(alpha = .12f), height = 8.dp)
                            Text(
                                T("${stats.answered} answered out of ${stats.called} completed calls", "${stats.answered} ردّوا من ${stats.called} مكالمة مكتملة"),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Text(T("Stage distribution", "توزيع النتائج"), style = MaterialTheme.typography.titleMedium)
                            Stg.all.forEach { stage ->
                                val n = list.entries.count { it.stage == stage }
                                val share = if (stats.answered == 0) 0f else n / stats.answered.toFloat()
                                Row(
                                    Modifier.fillMaxWidth()
                                        .clip(RoundedCornerShape(Rd.s))
                                        .background(if (filter == filterStage(stage)) Stg.color(stage).copy(alpha = .11f) else Color.Transparent)
                                        .clickable { filter = filterStage(stage) }
                                        .padding(Sp.xs),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconTile(stageIcon(stage), Stg.color(stage), size = 38.dp)
                                    Spacer(Modifier.width(Sp.m))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(Stg.label(stage), style = MaterialTheme.typography.titleSmall)
                                            Text("$n · ${(share * 100).toInt()}%", color = Stg.color(stage), style = MaterialTheme.typography.labelLarge)
                                        }
                                        BProgress(share, color = Stg.color(stage), track = Stg.color(stage).copy(alpha = .12f), height = 6.dp)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            when {
                                filter == FILTER_ALL -> T("All calls", "كل المكالمات")
                                filter == FILTER_ANSWERED -> T("Answered calls", "المكالمات التي تم الرد عليها")
                                filter == FILTER_UNANSWERED -> T("Unanswered calls", "المكالمات التي لم يتم الرد عليها")
                                filter == FILTER_FAILED -> T("Failed calls", "المكالمات الفاشلة")
                                filter == FILTER_SKIPPED -> T("Skipped calls", "المكالمات التي تم تخطيها")
                                filter == FILTER_PENDING -> T("Remaining contacts", "جهات الاتصال المتبقية")
                                else -> Stg.label(filter - FILTER_STAGE_BASE)
                            },
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text("${rows.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (rows.isEmpty()) item {
                    EmptyState(Icons.Rounded.SearchOff, T("Nothing here", "لا توجد نتائج هنا"),
                        T("Try another category.", "جرّب تصنيفًا آخر."), Modifier.fillMaxWidth())
                } else {
                    items(rows, key = { it.id }) { e -> ResultRow(e, list.id) }
                }
            }
        }
    }
}

@Composable
private fun SmallStatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Panel(modifier) {
        Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(Sp.s))
            Column {
                Text(value, style = MaterialTheme.typography.titleMedium)
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
