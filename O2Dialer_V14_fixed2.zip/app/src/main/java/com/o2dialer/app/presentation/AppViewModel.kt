package com.o2dialer.app.presentation

import androidx.lifecycle.ViewModel
import com.o2dialer.app.core.data.AppUiState
import com.o2dialer.app.core.data.RuntimeStateRepository
import kotlinx.coroutines.flow.StateFlow

/** Single source of truth exposed to Compose. Screens should consume this instead of global mutable state. */
class AppViewModel(
    private val runtime: RuntimeStateRepository
) : ViewModel() {
    val uiState: StateFlow<AppUiState> = runtime.state
}

class AppViewModelFactory(
    private val runtime: RuntimeStateRepository
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        AppViewModel(runtime) as T
}
