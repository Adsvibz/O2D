package com.o2dialer.app

import android.app.Application
import com.o2dialer.app.core.data.AppContainer
import com.o2dialer.app.core.data.Store

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContainer.initialize(this)
        Store.init(this)
    }
}
