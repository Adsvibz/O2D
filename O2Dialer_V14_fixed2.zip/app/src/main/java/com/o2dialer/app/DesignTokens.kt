package com.o2dialer.app

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * O2Dialer Design System
 *
 * Single source of truth for visual decisions. Screens and components should
 * consume these tokens instead of inventing local dp/color values.
 */
object O2Colors {
    // Brand
    val primary = Color(0xFF6246EA)
    val primaryStrong = Color(0xFF4F46E5)
    val secondary = Color(0xFF0EA5E9)
    val primaryContainer = Color(0xFFECE8FF)
    val onPrimaryContainer = Color(0xFF1B0B5C)

    // Light surfaces
    val lightBackground = Color(0xFFF7F7FA)
    val lightSurface = Color.White
    val lightSurfaceVariant = Color(0xFFF0F0F6)
    val lightOnSurface = Color(0xFF14131A)
    val lightOnSurfaceVariant = Color(0xFF6A6A7A)
    val lightOutline = Color(0xFFE3E3EC)

    // Dark surfaces
    val darkBackground = Color(0xFF0B0B10)
    val darkSurface = Color(0xFF15151C)
    val darkSurfaceVariant = Color(0xFF1E1E27)
    val darkOnSurface = Color(0xFFF2F2F7)
    val darkOnSurfaceVariant = Color(0xFF9A9AAC)
    val darkOutline = Color(0xFF2B2B37)

    // Semantic states
    val success = Color(0xFF16A34A)
    val warning = Color(0xFFF59E0B)
    val danger = Color(0xFFDC2626)
    val info = Color(0xFF2563EB)
    val teal = Color(0xFF0D9488)
    val neutral = Color(0xFF8A90A5)
    val whatsapp = Color(0xFF25D366)

    // Campaign-stage accents
    val stagePotential = Color(0xFF3B82F6)
    val stageNotInterested = Color(0xFFEF4444)
    val stageCallBack = Color(0xFFF59E0B)
    val stageWhatsApp = Color(0xFF22C55E)
    val stageVoicemail = Color(0xFF8B5CF6)
    val stageNeutral = Color(0xFF94A3B8)

    val brandGradient: Brush = Brush.linearGradient(
        listOf(primary, primaryStrong, secondary)
    )
}

object O2Spacing {
    val hairline = 1.dp
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 20.dp
    val xxl = 24.dp
    val xxxl = 32.dp
    val huge = 40.dp
    val section = 48.dp
}

object O2Radii {
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 20.dp
    val xl = 28.dp
    val pill = 999.dp
}

object O2Borders {
    val hairline = 1.dp
    val selected = 2.dp
}

object O2IconSizes {
    val xs = 14.dp
    val sm = 18.dp
    val md = 20.dp
    val lg = 24.dp
    val xl = 32.dp
    val tile = 44.dp
    val avatar = 44.dp
}

object O2ButtonSizes {
    val compact = 44.dp
    val standard = 52.dp
    val minTouchTarget = 48.dp
}

object O2CardSizes {
    val statMinHeight = 104.dp
    val progressRing = 64.dp
    val emptyIcon = 88.dp
    val contentMaxWidth = 640.dp
    val narrowContentMaxWidth = 480.dp
}

object O2Elevation {
    val none = 0.dp
    val subtle = 1.dp
    val raised = 4.dp
    val floating = 10.dp
}

object O2Motion {
    const val fast = 110
    const val standard = 180
    const val emphasis = 300
    const val progress = 500
    const val slow = 600
    const val pulse = 800
    const val toast = 2600L
}

object O2Layout {
    val screenHorizontal = O2Spacing.lg
    val screenVertical = O2Spacing.lg
    val compactHorizontal = O2Spacing.md
    val contentMaxWidth = O2CardSizes.contentMaxWidth
    val narrowContentMaxWidth = O2CardSizes.narrowContentMaxWidth
}

object O2TypographyMetrics {
    const val displayLarge = 40
    const val displayMedium = 34
    const val displaySmall = 30
    const val headlineLarge = 28
    const val headlineMedium = 24
    const val headlineSmall = 22
    const val titleLarge = 20
    const val titleMedium = 16
    const val titleSmall = 14
    const val bodyLarge = 16
    const val bodyMedium = 14
    const val bodySmall = 12
    const val labelLarge = 14
    const val labelMedium = 12
    const val labelSmall = 11
}

/** Compatibility aliases for the current codebase. New code should use O2* tokens. */
object Sp {
    val xs: Dp = O2Spacing.xs
    val s: Dp = O2Spacing.sm
    val m: Dp = O2Spacing.md
    val l: Dp = O2Spacing.lg
    val xl: Dp = O2Spacing.xl
    val xxl: Dp = O2Spacing.xxl
    val xxxl: Dp = O2Spacing.xxxl
}

object Rd {
    val s: Dp = O2Radii.sm
    val m: Dp = O2Radii.md
    val l: Dp = O2Radii.lg
    val xl: Dp = O2Radii.xl
}

object Sem {
    val success: Color = O2Colors.success
    val warning: Color = O2Colors.warning
    val danger: Color = O2Colors.danger
    val info: Color = O2Colors.info
}

val Brand: Brush = O2Colors.brandGradient
