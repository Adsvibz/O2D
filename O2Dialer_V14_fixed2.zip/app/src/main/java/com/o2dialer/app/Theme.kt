package com.o2dialer.app

import com.o2dialer.app.core.data.Store

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

private val Outfit = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

private val LightC = lightColorScheme(
    primary = O2Colors.primary,
    onPrimary = Color.White,
    primaryContainer = O2Colors.primaryContainer,
    onPrimaryContainer = O2Colors.onPrimaryContainer,
    secondary = O2Colors.secondary,
    background = O2Colors.lightBackground,
    surface = O2Colors.lightSurface,
    surfaceVariant = O2Colors.lightSurfaceVariant,
    onSurface = O2Colors.lightOnSurface,
    onBackground = O2Colors.lightOnSurface,
    onSurfaceVariant = O2Colors.lightOnSurfaceVariant,
    outline = O2Colors.lightOutline,
    inverseSurface = Color(0xFF1F1E26),
    inverseOnSurface = Color(0xFFF4F4F8)
)

private val DarkC = darkColorScheme(
    primary = Color(0xFFB3A1FF),
    onPrimary = O2Colors.onPrimaryContainer,
    primaryContainer = Color(0xFF3A2A8F),
    onPrimaryContainer = O2Colors.primaryContainer,
    secondary = Color(0xFF7DD3FC),
    background = O2Colors.darkBackground,
    surface = O2Colors.darkSurface,
    surfaceVariant = O2Colors.darkSurfaceVariant,
    onSurface = O2Colors.darkOnSurface,
    onBackground = O2Colors.darkOnSurface,
    onSurfaceVariant = O2Colors.darkOnSurfaceVariant,
    outline = O2Colors.darkOutline,
    inverseSurface = Color(0xFFEDEDF3),
    inverseOnSurface = Color(0xFF1B1B22)
)

fun statusColor(s: Int): Color = when (s) {
    St.ANSWERED -> O2Colors.success
    St.NO_ANSWER -> O2Colors.warning
    St.FAILED -> O2Colors.danger
    St.CALLING -> O2Colors.info
    St.DONE -> O2Colors.teal
    else -> O2Colors.neutral
}

private fun typo(ff: FontFamily): Typography {
    fun st(w: FontWeight, size: Int, lh: Int) =
        TextStyle(fontFamily = ff, fontWeight = w, fontSize = size.sp, lineHeight = lh.sp)
    val b = FontWeight.Bold
    val n = FontWeight.Normal
    return Typography(
        displayLarge = st(b, O2TypographyMetrics.displayLarge, 48),
        displayMedium = st(b, O2TypographyMetrics.displayMedium, 42),
        displaySmall = st(b, O2TypographyMetrics.displaySmall, 38),
        headlineLarge = st(b, O2TypographyMetrics.headlineLarge, 36),
        headlineMedium = st(b, O2TypographyMetrics.headlineMedium, 32),
        headlineSmall = st(b, O2TypographyMetrics.headlineSmall, 28),
        titleLarge = st(b, O2TypographyMetrics.titleLarge, 26),
        titleMedium = st(b, O2TypographyMetrics.titleMedium, 22),
        titleSmall = st(b, O2TypographyMetrics.titleSmall, 20),
        bodyLarge = st(n, O2TypographyMetrics.bodyLarge, 24),
        bodyMedium = st(n, O2TypographyMetrics.bodyMedium, 20),
        bodySmall = st(n, O2TypographyMetrics.bodySmall, 16),
        labelLarge = st(b, O2TypographyMetrics.labelLarge, 20),
        labelMedium = st(n, O2TypographyMetrics.labelMedium, 16),
        labelSmall = st(n, O2TypographyMetrics.labelSmall, 14)
    )
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val c = Store.cfg
    val dark = when (c.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (c.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkC else LightC
    val ty = remember(c.lang) { typo(if (c.lang == 1) FontFamily.Default else Outfit) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val ic = WindowCompat.getInsetsController(w, view)
                ic.isAppearanceLightStatusBars = !dark
                ic.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = ty,
        shapes = Shapes(
            extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(O2Radii.xs),
            small = androidx.compose.foundation.shape.RoundedCornerShape(O2Radii.sm),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(O2Radii.md),
            large = androidx.compose.foundation.shape.RoundedCornerShape(O2Radii.lg),
            extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(O2Radii.xl)
        )
    ) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
