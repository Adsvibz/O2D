package com.o2dialer.app.core.domain.model

import java.util.UUID
import org.json.JSONObject


object CallStatus {
    const val PENDING = 0
    const val CALLING = 1
    const val ANSWERED = 2
    const val NO_ANSWER = 3
    const val FAILED = 4
    const val DONE = 5
    const val SKIPPED = 6
}

/** Immutable persisted contact. Kept independent from Compose and Android APIs. */
data class Contact(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val number: String
)

/** Immutable persisted contact list. The entries are an immutable snapshot. */
data class ContactList(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val entries: List<CampaignContact> = emptyList(),
    val simSlot: Int = -1
)

data class Campaign(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val contactListId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val loops: Int = 1
)

/** Persisted campaign configuration, kept separate from global app preferences. */
data class CampaignProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val contactListId: String,
    val simSlot: Int = -1,
    val settings: AppSettings = AppSettings()
)

/** Contact as it participates in a campaign; mutable-looking fields are immutable values. */
data class CampaignContact(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    /** Canonical dialable form, e.g. +2010... */
    val number: String,
    /** Original/user-friendly form when preserving display formatting is useful. */
    val displayNumber: String = "",
    val campaignId: String = "",
    val contactId: String = "",
    val status: Int = 0,
    val attempts: Int = 0,
    val duration: Int = 0,
    val calledAt: Long = 0,
    val stage: Int = 0,
    val feedback: String = ""
)

data class CallAttempt(
    val id: String = UUID.randomUUID().toString(),
    val time: Long,
    val campaignId: String = "",
    val contactId: String = "",
    val listName: String,
    val name: String,
    val number: String,
    val status: Int,
    val duration: Int,
    val attempt: Int,
    val startedAt: Long = 0,
    val completedAt: Long = time
)

data class CallResult(
    val status: Int,
    val durationSeconds: Int = 0,
    val recordedAt: Long = System.currentTimeMillis()
)

enum class CallStage(val code: Int) {
    NONE(0), POTENTIAL(1), NOT_INTERESTED(2), CALL_BACK(3), WHATSAPP(4), VOICEMAIL(5);
    companion object { fun fromCode(code: Int) = entries.firstOrNull { it.code == code } ?: NONE }
}

data class Feedback(
    val stage: CallStage,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CampaignStatistics(
    val total: Int = 0,
    val called: Int = 0,
    val answered: Int = 0,
    val noAnswer: Int = 0,
    val failed: Int = 0,
    val skipped: Int = 0,
    val totalCallTimeSeconds: Long = 0,
    val averageCallDurationSeconds: Int = 0
) {
    val remaining: Int get() = (total - called).coerceAtLeast(0)
    val percent: Int get() = if (total == 0) 0 else called * 100 / total
    val answerRate: Int get() = if (called == 0) 0 else answered * 100 / called
}

/** Persisted application configuration. Values are immutable and versionable. */
data class AppSettings(
    val lang: Int = 0,
    val delaySec: Int = 5,
    val randomDelay: Boolean = false,
    val delayMaxSec: Int = 15,
    val startCountdown: Int = 3,
    val maxCallSec: Int = 0,
    val retries: Int = 0,
    val loops: Int = 1,
    val shuffle: Boolean = false,
    val skipAnswered: Boolean = true,
    val useCallLog: Boolean = true,
    val countryCode: String = "",
    val autoSpeaker: Boolean = true,
    val autoMuteMic: Boolean = true,
    val askStage: Boolean = true,
    val stageWaitSec: Int = 15,
    val quietEnabled: Boolean = false,
    val quietFrom: Int = 9,
    val quietTo: Int = 21,
    val keepScreenOn: Boolean = true,
    val vibrateOnFinish: Boolean = true,
    val themeMode: Int = 0,
    val dynamicColor: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("lang", lang).put("delaySec", delaySec).put("randomDelay", randomDelay)
        .put("delayMaxSec", delayMaxSec).put("startCountdown", startCountdown).put("maxCallSec", maxCallSec)
        .put("retries", retries).put("loops", loops).put("shuffle", shuffle)
        .put("skipAnswered", skipAnswered).put("useCallLog", useCallLog).put("countryCode", countryCode)
        .put("autoSpeaker", autoSpeaker).put("autoMuteMic", autoMuteMic).put("askStage", askStage).put("stageWaitSec", stageWaitSec)
        .put("quietEnabled", quietEnabled).put("quietFrom", quietFrom).put("quietTo", quietTo)
        .put("keepScreenOn", keepScreenOn).put("vibrateOnFinish", vibrateOnFinish)
        .put("themeMode", themeMode).put("dynamicColor", dynamicColor)

    companion object {
        fun fromJson(o: JSONObject): AppSettings {
            val d = AppSettings()
            return AppSettings(
                lang = o.optInt("lang", d.lang), delaySec = o.optInt("delaySec", d.delaySec),
                randomDelay = o.optBoolean("randomDelay", d.randomDelay), delayMaxSec = o.optInt("delayMaxSec", d.delayMaxSec),
                startCountdown = o.optInt("startCountdown", d.startCountdown), maxCallSec = o.optInt("maxCallSec", d.maxCallSec),
                retries = o.optInt("retries", d.retries), loops = o.optInt("loops", d.loops), shuffle = o.optBoolean("shuffle", d.shuffle),
                skipAnswered = o.optBoolean("skipAnswered", d.skipAnswered), useCallLog = o.optBoolean("useCallLog", d.useCallLog),
                countryCode = o.optString("countryCode", d.countryCode), autoSpeaker = o.optBoolean("autoSpeaker", d.autoSpeaker),
                autoMuteMic = o.optBoolean("autoMuteMic", d.autoMuteMic), askStage = o.optBoolean("askStage", d.askStage), stageWaitSec = o.optInt("stageWaitSec", d.stageWaitSec),
                quietEnabled = o.optBoolean("quietEnabled", d.quietEnabled), quietFrom = o.optInt("quietFrom", d.quietFrom),
                quietTo = o.optInt("quietTo", d.quietTo), keepScreenOn = o.optBoolean("keepScreenOn", d.keepScreenOn),
                vibrateOnFinish = o.optBoolean("vibrateOnFinish", d.vibrateOnFinish), themeMode = o.optInt("themeMode", d.themeMode),
                dynamicColor = o.optBoolean("dynamicColor", d.dynamicColor)
            )
        }
    }
}

/**
 * Durable campaign execution journal.
 *
 * This is deliberately more detailed than UI state. The queue contains the exact
 * remaining work in execution order, while currentEntryId represents work already
 * claimed by the engine. Every state transition is checkpointed before the Android
 * adapter performs an irreversible telephony action.
 */
data class CampaignRuntimeState(
    val status: Int = 0,
    val listId: String = "",
    val listName: String = "",
    val currentName: String = "",
    val currentNumber: String = "",
    val message: String = "",
    val loop: Int = 1,
    val loops: Int = 1,
    val nextAt: Long = 0,
    val awaitingStage: Boolean = false,
    val error: Boolean = false,
    val queue: List<String> = emptyList(),
    val retriesLeft: Map<String, Int> = emptyMap(),
    val currentEntryId: String? = null,
    val currentPhase: Int = CampaignPhase.IDLE,
    val callStartedAt: Long = 0,
    val offhookAt: Long = 0,
    val simSlot: Int = -1,
    val sessionId: String = "",
    val startedAt: Long = 0,
    val checkpointAt: Long = System.currentTimeMillis()
)

/** Durable execution phases. These are domain values, not Android/Compose concepts. */
object CampaignPhase {
    const val IDLE = 0
    const val COUNTDOWN = 1
    const val DELAY = 2
    const val CALLING = 3
    const val WAITING_STAGE = 4
    const val QUIET_WAIT = 5
    const val PAUSED = 6
    const val RECOVERING = 7
    const val COMPLETED = 8
    const val FAILED = 9
}

/** Immutable archive of a finished campaign. It is intentionally independent from the live queue. */
data class CampaignHistory(
    val id: String,
    val sessionId: String,
    val campaignName: String,
    val startedAt: Long,
    val completedAt: Long,
    val completionState: String,
    val entries: List<CampaignContact>
)

data class TelephonyState(
    val callState: Int = 0,
    val activeNumber: String? = null,
    val startedAt: Long = 0,
    val offhookAt: Long = 0
)
