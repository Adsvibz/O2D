package com.o2dialer.app.core.data

import android.content.Context
import android.telephony.TelephonyManager
import androidx.compose.runtime.*
import com.o2dialer.app.*
import com.o2dialer.app.core.domain.model.CampaignHistory
import com.o2dialer.app.core.domain.campaign.CampaignStatisticsCalculator
object Store {
    private var simCc = ""

    val lists = mutableStateListOf<CallList>()
    val log = mutableStateListOf<LogItem>()
    var cfg by mutableStateOf(Cfg())
    private var _camp by mutableStateOf(CampState())
    var camp: CampState
        get() = _camp
        set(value) {
            _camp = value
            if (initialized) AppContainer.get().campaigns.saveRuntime(value)
        }
    var selectedListId by mutableStateOf<String?>(null)
    var runListId by mutableStateOf<String?>(null)
    var resultsListId by mutableStateOf<String?>(null)
    var stageTarget by mutableStateOf<Pair<String, String>?>(null)
    var pendingResultsNav by mutableStateOf(false)
    var tab by mutableIntStateOf(0)
    var prevTab = 0
    var toast by mutableStateOf<UiToast?>(null)
    var permTick by mutableIntStateOf(0)

    fun notify(kind: Int, msg: String) { toast = UiToast(kind, msg, System.nanoTime()) }

    fun openSettings() { if (tab != 4) { prevTab = tab; tab = 4 } }

    fun campActive(): Boolean =
        camp.status == CS.RUNNING || camp.status == CS.PAUSED || camp.status == CS.WAITING

    /** Country code used to fix local numbers: user setting, else guessed from the SIM country. */
    fun defaultCc(): String = cfg.countryCode.filter { it.isDigit() }.ifEmpty { simCc }

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        val container = AppContainer.initialize(ctx)
        simCc = runCatching {
            val iso = (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).simCountryIso ?: ""
            isoCc[iso.lowercase()] ?: ""
        }.getOrDefault("")
        cfg = container.settings.load()
        _camp = container.campaigns.loadRuntime()?.let { recovered ->
            if (recovered.status == CS.RUNNING || recovered.status == CS.WAITING) {
                recovered.copy(status = CS.PAUSED, message = T("Recovered campaign — tap Resume to continue", "تم استرداد الحملة — اضغط استئناف للمتابعة"))
            } else recovered
        } ?: CampState()
        lists.clear()
        val loadedLists = container.campaigns.loadLists()
        // One-time safe normalization pass for legacy entries. Existing display formatting is retained.
        lists.addAll(loadedLists.map { list ->
            list.copy(entries = list.entries.map { entry ->
                val display = entry.displayNumber.ifBlank { entry.number }
                entry.copy(number = smartNumber(entry.number, defaultCc()), displayNumber = display)
            })
        })
        if (lists.isNotEmpty()) saveLists()
        log.clear()
        log.addAll(container.campaigns.loadLog())
        publishRuntime()
    }

    private var initialized = false
    private val container: AppContainer get() = AppContainer.get()

    fun publishRuntime() {
        if (initialized) container.campaigns.saveRuntime(_camp)
        container.runtime.publish(
            AppUiState(
                lists = lists.toList(),
                log = log.toList(),
                cfg = cfg,
                campaign = camp,
                selectedListId = selectedListId,
                runListId = runListId,
                resultsListId = resultsListId,
                stageTarget = stageTarget,
                pendingResultsNavigation = pendingResultsNav,
                tab = tab,
                previousTab = prevTab,
                toast = toast,
                permissionsRevision = permTick
            )
        )
    }

    fun updateCfg(f: (Cfg) -> Cfg) {
        cfg = f(cfg)
        container.settings.save(cfg)
        publishRuntime()
    }

    private fun saveLists() {
        container.campaigns.saveLists(lists.toList())
    }

    private fun saveLog() {
        container.campaigns.saveLog(log.toList())
    }

    fun campaignProfiles(): List<com.o2dialer.app.core.domain.model.CampaignProfile> = container.campaigns.loadCampaignProfiles()

    fun saveCampaignProfile(profile: com.o2dialer.app.core.domain.model.CampaignProfile) {
        val current = container.campaigns.loadCampaignProfiles().filterNot { it.contactListId == profile.contactListId } + profile
        container.campaigns.saveCampaignProfiles(current)
    }

    fun profileFor(listId: String): com.o2dialer.app.core.domain.model.CampaignProfile? =
        container.campaigns.loadCampaignProfiles().firstOrNull { it.contactListId == listId }

    fun addList(name: String, simSlot: Int): String {
        val l = CallList(name = name, simSlot = simSlot)
        lists.add(l); saveLists(); publishRuntime(); return l.id
    }

    fun deleteList(id: String) { lists.removeAll { it.id == id }; saveLists(); publishRuntime() }

    fun updateList(id: String, f: (CallList) -> CallList) {
        val i = lists.indexOfFirst { it.id == id }
        if (i >= 0) { lists[i] = f(lists[i]); saveLists(); publishRuntime() }
    }

    fun updateEntry(listId: String, entryId: String, f: (Entry) -> Entry) =
        updateList(listId) { l -> l.copy(entries = l.entries.map { if (it.id == entryId) f(it) else it }) }

    fun deleteEntry(listId: String, entryId: String) =
        updateList(listId) { l -> l.copy(entries = l.entries.filter { it.id != entryId }) }

    fun editEntry(listId: String, entryId: String, name: String, number: String) =
        updateEntry(listId, entryId) { it.copy(name = name.trim(), number = smartNumber(number, defaultCc()), displayNumber = number.trim()) }

    fun setStage(listId: String, entryId: String, stage: Int, feedback: String) =
        updateEntry(listId, entryId) { it.copy(stage = stage, feedback = feedback) }

    fun addEntries(listId: String, items: List<Pair<String, String>>): Int {
        var added = 0
        val cc = defaultCc()
        updateList(listId) { l ->
            val seen = l.entries.map { it.number }.toMutableSet()
            val fresh = items.mapNotNull { (n, num) ->
                val c = smartNumber(num, cc)
                if (c.filter { it.isDigit() }.length < 3 || !seen.add(c)) null else Entry(name = n.trim(), number = c, displayNumber = num.trim())
            }
            added = fresh.size
            l.copy(entries = l.entries + fresh)
        }
        return added
    }

    fun dedupe(listId: String): Int {
        var removed = 0
        updateList(listId) { l ->
            val seen = HashSet<String>()
            val out = l.entries.filter { seen.add(it.number) }
            removed = l.entries.size - out.size
            l.copy(entries = out)
        }
        return removed
    }

    /** Back to "not called yet". Answered numbers can be kept (Skip answered setting). Stages are kept. */
    fun resetForRestart(listId: String, keepAnswered: Boolean) = updateList(listId) { l ->
        l.copy(entries = l.entries.map {
            if (keepAnswered && St.isAnswered(it.status)) it
            else it.copy(status = St.PENDING, attempts = 0, duration = 0, calledAt = 0)
        })
    }

    fun resetAll(listId: String) = updateList(listId) { l ->
        l.copy(entries = l.entries.map {
            it.copy(status = St.PENDING, attempts = 0, duration = 0, calledAt = 0, stage = Stg.NONE, feedback = "")
        })
    }

    fun prog(l: CallList): Prog {
        val called = l.entries.count { it.status != St.PENDING && it.status != St.CALLING }
        return Prog(
            total = l.entries.size, called = called,
            answered = l.entries.count { St.isAnswered(it.status) },
            noAnswer = l.entries.count { it.status == St.NO_ANSWER },
            failed = l.entries.count { it.status == St.FAILED }
        )
    }


    fun campaignHistory(): List<CampaignHistory> = container.campaigns.loadCampaignHistory().sortedByDescending { it.completedAt }

    fun archiveCampaign(state: CampState, completionState: String) {
        val list = lists.find { it.id == state.listId } ?: return
        val now = System.currentTimeMillis()
        val entries = list.entries.map { it.copy(campaignId = state.sessionId.ifBlank { it.campaignId.ifBlank { state.listId } }) }
        val history = CampaignHistory(
            id = state.sessionId.ifBlank { "${state.listId}-$now" },
            sessionId = state.sessionId,
            campaignName = list.name,
            startedAt = state.startedAt.takeIf { it > 0 } ?: now,
            completedAt = now,
            completionState = completionState,
            entries = entries
        )
        val existing = container.campaigns.loadCampaignHistory().filterNot { it.id == history.id }
        container.campaigns.saveCampaignHistory((existing + history).takeLast(100))
        publishRuntime()
    }

    /** Marks the persisted campaign session as finished while retaining its last UI result. */
    fun clearPersistedCampaignSession() {
        container.campaigns.clearRuntime()
    }

    fun addLog(i: LogItem) {
        log.add(0, i)
        while (log.size > 1000) log.removeAt(log.lastIndex)
        saveLog()
        publishRuntime()
    }

    fun clearLog() { log.clear(); saveLog(); publishRuntime() }

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun listReport(l: CallList): String =
        "Name,Number,Status,Duration(s),Called at,Stage,Feedback\n" + l.entries.joinToString("\n") {
            listOf(csv(it.name), it.number, St.label(it.status), it.duration.toString(),
                if (it.calledAt > 0) fmtTime(it.calledAt) else "", if (it.stage > 0) Stg.label(it.stage) else "",
                csv(it.feedback)).joinToString(",")
        }

    fun logReport(items: List<LogItem>): String =
        "Time,Campaign,Name,Number,Status,Duration(s),Attempt\n" + items.joinToString("\n") {
            "${fmtTime(it.time)},${csv(it.listName)},${csv(it.name)},${it.number},${St.label(it.status)},${it.duration},${it.attempt}"
        }
}
