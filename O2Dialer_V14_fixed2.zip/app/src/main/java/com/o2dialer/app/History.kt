@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import com.o2dialer.app.core.data.Store
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.domain.campaign.CampaignStatisticsCalculator
import com.o2dialer.app.core.domain.model.CampaignHistory

private fun historyStateColor(state: String): Color = when (state) {
    "COMPLETED" -> Sem.success
    "FAILED" -> Sem.danger
    else -> Sem.warning
}

private fun historyStateLabel(state: String): String = when (state) {
    "COMPLETED" -> T("Completed", "مكتملة")
    "FAILED" -> T("Failed", "فشلت")
    else -> T("Stopped", "متوقفة")
}

private fun historyDuration(h: CampaignHistory): Int =
    ((h.completedAt - h.startedAt).coerceAtLeast(0L) / 1000L).toInt()

@Composable
private fun RowScope.HistoryMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        Modifier.weight(1f).clip(RoundedCornerShape(Rd.m)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)).padding(Sp.m),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HistoryCard(h: CampaignHistory, onClick: () -> Unit) {
    val stats = CampaignStatisticsCalculator.calculate(h.entries)
    val stateColor = historyStateColor(h.completionState)
    Panel(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(h.campaignName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtTime(h.completedAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Pill(historyStateLabel(h.completionState), stateColor, if (h.completionState == "COMPLETED") Icons.Rounded.CheckCircle else Icons.Rounded.Info)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                HistoryMetric(T("Contacts", "جهات الاتصال"), stats.total.toString(), Icons.Rounded.People)
                HistoryMetric(T("Answered", "تم الرد"), stats.answered.toString(), Icons.Rounded.Call)
                HistoryMetric(T("Answer rate", "نسبة الرد"), "${stats.answerRate}%", Icons.Rounded.Percent)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(T("Duration ${fmtDur(historyDuration(h))}", "المدة ${fmtDur(historyDuration(h))}"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text(T("${stats.noAnswer} unanswered", "${stats.noAnswer} بلا رد"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Rounded.ChevronRight, T("Open", "فتح"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun HistoryDetail(h: CampaignHistory, onBack: () -> Unit) {
    var filter by remember { mutableIntStateOf(0) }
    val stats = CampaignStatisticsCalculator.calculate(h.entries)
    val entries = when (filter) {
        1 -> h.entries.filter { St.isAnswered(it.status) }
        2 -> h.entries.filter { it.status == St.NO_ANSWER }
        3 -> h.entries.filter { it.status == St.FAILED }
        4 -> h.entries.filter { it.status == St.SKIPPED }
        else -> h.entries
    }
    Scaffold(
        topBar = { BlendBar(h.campaignName, onBack, subtitle = "${fmtTime(h.completedAt)} · ${historyStateLabel(h.completionState)}") },
        containerColor = Color.Transparent
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp), verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            item {
                Panel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                            HistoryMetric(T("Total", "الإجمالي"), stats.total.toString(), Icons.Rounded.People)
                            HistoryMetric(T("Answered", "تم الرد"), stats.answered.toString(), Icons.Rounded.Call)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                            HistoryMetric(T("Unanswered", "بلا رد"), stats.noAnswer.toString(), Icons.Rounded.CallMissed)
                            HistoryMetric(T("Answer rate", "نسبة الرد"), "${stats.answerRate}%", Icons.Rounded.Percent)
                        }
                        Text(T("Campaign duration: ${fmtDur(historyDuration(h))}", "مدة الحملة: ${fmtDur(historyDuration(h))}"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                    listOf(0 to T("All", "الكل"), 1 to T("Answered", "تم الرد"), 2 to T("Unanswered", "بلا رد"), 3 to T("Failed", "فشل"), 4 to T("Skipped", "تم التخطي")).forEach { (id, label) ->
                        FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) })
                    }
                }
            }
            items(entries, key = { it.id }) { e ->
                Panel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(Sp.m), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(e.name.ifBlank { e.number }, if (e.stage != Stg.NONE) Stg.color(e.stage) else statusColor(e.status))
                            Spacer(Modifier.width(Sp.m))
                            Column(Modifier.weight(1f)) {
                                Text(e.name.ifBlank { T("Unnamed contact", "جهة اتصال بدون اسم") }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                NumText(e.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(e.status)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            if (e.calledAt > 0) Pill(fmtTime(e.calledAt), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.History)
                            Pill(fmtDur(e.duration), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.Schedule)
                            Pill(T("Attempt #${e.attempts}", "المحاولة #${e.attempts}"), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.Replay)
                            if (e.stage != Stg.NONE) StagePill(e.stage) { }
                        }
                        if (e.feedback.isNotBlank()) Text(e.feedback, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(onMenu: () -> Unit) {
    val histories = remember { mutableStateOf(Store.campaignHistory()) }
    var selected by remember { mutableStateOf<CampaignHistory?>(null) }
    LaunchedEffect(Unit) { histories.value = Store.campaignHistory() }
    if (selected != null) {
        HistoryDetail(selected!!, onBack = { selected = null })
        return
    }
    Scaffold(
        topBar = { BlendBar(T("Campaign History", "سجل الحملات"), onMenu, subtitle = T("Completed campaign archive", "أرشيف الحملات المكتملة")) },
        containerColor = Color.Transparent
    ) { pad ->
        if (histories.value.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(Sp.xl), contentAlignment = Alignment.Center) {
                EmptyState(Icons.Rounded.History, T("No campaign history yet", "لا يوجد سجل حملات بعد"), T("Completed campaigns will stay here for future reference.", "ستظل الحملات المكتملة هنا للرجوع إليها لاحقًا."))
            }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                item {
                    Text(T("Your campaigns", "حملاتك"), style = MaterialTheme.typography.headlineSmall)
                    Text(T("A durable snapshot of every finished campaign.", "نسخة محفوظة من كل حملة انتهت."), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(histories.value, key = { it.id }) { h -> HistoryCard(h) { selected = h } }
            }
        }
    }
}
