@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import com.o2dialer.app.core.data.Store
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
private fun InfoRow(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Sp.m))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun LiveScreen(act: MainActivity, onMenu: () -> Unit) {
    val c = Store.camp
    val active = Store.campActive()
    val compact = isCompact()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(active, c.callStartedAt, c.offhookAt, c.status) {
        while (active) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    val list = Store.lists.find { it.id == c.listId }
    val showLive = (active || c.status == CS.FINISHED) && list != null

    Scaffold(
        topBar = { BlendBar(T("Live campaign", "الحملة المباشرة"), onMenu) },
        bottomBar = { if (active) LiveControls(compact) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.xl, vertical = Sp.s),
            verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            PermissionBanner(act)

            if (showLive && list != null) {
                val p = Store.prog(list)
                LiveHero(c, p, now, compact)
                LiveStats(p, compact)

                if (c.status == CS.FINISHED) {
                    Banner(if (c.error) Tk.ERROR else Tk.SUCCESS, c.message)
                } else if (active && !Store.cfg.shuffle) {
                    UpNext(list)
                }

                if (c.status == CS.FINISHED && !c.error) {
                    BButton(
                        T("View campaign results", "عرض نتائج الحملة"),
                        { Store.resultsListId = c.listId; Store.tab = 2 },
                        Modifier.fillMaxWidth(),
                        kind = BtnKind.Tonal,
                        icon = Icons.Rounded.BarChart
                    )
                }
            } else {
                Launcher(act)
            }
            Spacer(Modifier.height(Sp.l))
        }
    }
}

@Composable
private fun LiveHero(c: CampState, p: Prog, now: Long, compact: Boolean) {
    val inCall = c.status == CS.RUNNING && c.currentNumber.isNotBlank()
    val paused = c.status == CS.PAUSED
    val waiting = c.status == CS.WAITING
    val hasCurrent = c.currentNumber.isNotBlank()

    val elapsedBase = when {
        c.offhookAt > 0L -> c.offhookAt
        c.callStartedAt > 0L -> c.callStartedAt
        else -> 0L
    }
    val elapsed = if (elapsedBase > 0L && (inCall || paused))
        ((now - elapsedBase).coerceAtLeast(0L) / 1000L).toInt()
    else 0

    val statusText = when {
        paused -> T("Campaign paused", "الحملة متوقفة مؤقتًا")
        inCall -> T("Calling now", "جارٍ الاتصال الآن")
        waiting && c.awaitingStage -> T("Waiting for result", "في انتظار نتيجة المكالمة")
        waiting -> T("Preparing next call", "تجهيز المكالمة التالية")
        else -> T("Ready", "جاهزة")
    }

    val statusIcon = when {
        paused -> Icons.Rounded.PauseCircle
        inCall -> Icons.Rounded.PhoneInTalk
        waiting -> Icons.Rounded.HourglassTop
        else -> Icons.Rounded.PlayCircle
    }

    val nextText = when {
        paused -> T("Resume to continue from the exact current position.", "استأنف للمتابعة من نفس الموضع بالضبط.")
        inCall -> T("The call is in progress. The next contact will follow automatically.", "المكالمة جارية. سيتم الانتقال للجهة التالية تلقائيًا.")
        c.awaitingStage -> T("Choose the call result when the conversation is complete.", "اختر نتيجة المكالمة عند انتهاء المحادثة.")
        else -> T("Next contact will be called automatically.", "سيتم الاتصال بالجهة التالية تلقائيًا.")
    }

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Rd.xl))
            .background(Brand)
            .padding(if (compact) Sp.xl else Sp.xxl)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(Sp.l), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(statusIcon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(Sp.s))
                Text(statusText, color = Color.White.copy(alpha = .92f), style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text(
                    c.listName,
                    color = Color.White.copy(alpha = .72f),
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 150.dp)
                )
            }

            // The contact is deliberately the visual center of gravity.
            Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(
                    if (hasCurrent) c.currentName.ifBlank { T("Current contact", "جهة الاتصال الحالية") }
                    else T("Preparing next contact", "تجهيز جهة الاتصال التالية"),
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = if (compact) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineLarge
                )
                Text(
                    if (hasCurrent) c.currentNumber else T("Please wait…", "برجاء الانتظار…"),
                    color = Color.White.copy(alpha = .9f),
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                    Text(T("Call duration", "مدة المكالمة"), color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.labelMedium)
                    Text(
                        formatDuration(elapsed),
                        color = Color.White,
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                ProgressRing(
                    p.pct / 100f,
                    86.dp,
                    8.dp,
                    Color.White,
                    Color.White.copy(alpha = .24f)
                ) {
                    Text("${p.pct}%", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(T("Campaign progress", "تقدم الحملة"), color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text("${p.called}/${p.total}", color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                }
                LinearProgressIndicator(
                    progress = { (p.pct / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = .2f)
                )
            }

            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).background(Color.White.copy(alpha = .09f)).padding(Sp.m),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.ArrowForward, null, tint = Color.White.copy(alpha = .78f), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(Sp.s))
                Text(nextText, color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun LiveStats(p: Prog, compact: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(Sp.s)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            LiveStat(T("Total", "الإجمالي"), p.total, Icons.Rounded.Groups, Modifier.weight(1f))
            LiveStat(T("Called", "تم الاتصال"), p.called, Icons.Rounded.PhoneCallback, Modifier.weight(1f))
            LiveStat(T("Remaining", "المتبقي"), p.remaining, Icons.Rounded.Schedule, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            LiveStat(T("Answered", "تم الرد"), p.answered, Icons.Rounded.CheckCircle, Modifier.weight(1f))
            LiveStat(T("Unanswered", "لم يرد"), p.noAnswer, Icons.Rounded.PhoneMissed, Modifier.weight(1f))
            LiveStat(T("Failed", "فشل"), p.failed, Icons.Rounded.ErrorOutline, Modifier.weight(1f))
        }
    }
}

@Composable
private fun LiveStat(label: String, value: Int, icon: ImageVector, modifier: Modifier) {
    Panel(modifier) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = Sp.m, horizontal = Sp.s),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(Sp.xs)
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text("$value", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

private fun formatDuration(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
private fun UpNext(list: CallList) {
    val next = list.entries.filter { it.status == St.PENDING }.take(3)
    if (next.isNotEmpty()) {
        Panel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionLabel(T("Up next", "التالي"), Modifier.weight(1f))
                    Text("${next.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                next.forEach { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(e.name.ifBlank { e.number }, size = 34.dp)
                        Spacer(Modifier.width(Sp.m))
                        Column(Modifier.weight(1f)) {
                            Text(e.name.ifBlank { e.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (e.name.isNotBlank()) NumText(e.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun LivePostCallWorkflow(compact: Boolean) {
    val c = Store.camp
    val ctx = LocalContext.current
    val list = Store.lists.find { it.id == c.listId }
    val entry = list?.entries?.find { it.id == c.currentEntryId }
        ?: list?.entries?.find { it.number == c.currentNumber }

    if (entry == null) return

    var selected by remember(entry.id, entry.stage) { mutableIntStateOf(entry.stage) }
    var feedback by remember(entry.id, entry.feedback) { mutableStateOf(entry.feedback) }

    fun finishStage(stage: Int, note: String = "") {
        Store.setStage(c.listId, entry.id, stage, note.trim())
        Store.notify(Tk.SUCCESS, T("Saved — moving to the next contact", "تم الحفظ — الانتقال للجهة التالية"))
        DialerService.send(ctx, DialerService.ACT_STAGE_DONE)
    }

    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 16.dp) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = if (compact) Sp.m else Sp.xl, vertical = Sp.m),
            verticalArrangement = Arrangement.spacedBy(Sp.s)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(T("How did the call go?", "ما نتيجة المكالمة؟"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        entry.name.ifBlank { entry.number },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Text("${entry.duration}s", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Five high-frequency choices stay visible at once: no navigation, no modal, no scrolling.
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Stg.all.forEach { stage ->
                    LiveStageChoice(
                        stage = stage,
                        selected = selected == stage,
                        compact = compact,
                        modifier = Modifier.weight(1f)
                    ) {
                        selected = stage
                        if (!Stg.needsFeedback(stage)) finishStage(stage)
                    }
                }
            }

            if (Stg.needsFeedback(selected)) {
                BTextField(
                    feedback,
                    { feedback = it },
                    singleLine = true,
                    label = T("Feedback", "ملاحظات"),
                    placeholder = when (selected) {
                        Stg.POTENTIAL -> T("What makes this lead promising?", "ما الذي يجعل العميل مهتمًا؟")
                        Stg.CALL_BACK -> T("Best time or reason to call back", "أفضل وقت أو سبب للاتصال مجددًا")
                        else -> T("WhatsApp details", "تفاصيل واتساب")
                    }
                )
                BButton(
                    T("Save & continue", "حفظ ومتابعة"),
                    { finishStage(selected, feedback) },
                    Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.ArrowForward
                )
            } else {
                Text(
                    T("Tap a result to continue instantly.", "اضغط على النتيجة للمتابعة فورًا."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun LiveStageChoice(
    stage: Int,
    selected: Boolean,
    compact: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = Stg.color(stage)
    Surface(
        modifier = modifier
            .height(if (compact) 66.dp else 74.dp)
            .semantics {
                contentDescription = Stg.label(stage)
                role = Role.RadioButton
            }
            .clip(RoundedCornerShape(Rd.m))
            .clickable(onClick = onClick),
        color = if (selected) accent.copy(alpha = 0.16f) else accent.copy(alpha = 0.06f),
        shape = RoundedCornerShape(Rd.m),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            accent.copy(alpha = if (selected) 1f else 0.30f)
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(stageIcon(stage), null, tint = accent, modifier = Modifier.size(if (compact) 20.dp else 22.dp))
            Spacer(Modifier.height(3.dp))
            Text(
                Stg.label(stage),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LiveControls(compact: Boolean) {
    val c = Store.camp
    val ctx = LocalContext.current
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m),
            horizontalArrangement = Arrangement.spacedBy(Sp.s),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (c.status == CS.PAUSED) {
                BButton(
                    T("Resume", "استئناف"),
                    { DialerService.send(ctx, DialerService.ACT_RESUME) },
                    Modifier.weight(1.35f),
                    icon = Icons.Rounded.PlayArrow,
                    compact = true
                )
            } else {
                BButton(
                    T("Pause", "إيقاف مؤقت"),
                    { DialerService.send(ctx, DialerService.ACT_PAUSE) },
                    Modifier.weight(1.35f),
                    kind = BtnKind.Tonal,
                    icon = Icons.Rounded.Pause,
                    compact = true
                )
            }
            BButton(
                T("Skip", "تخطي"),
                { DialerService.send(ctx, DialerService.ACT_SKIP) },
                Modifier.weight(1f),
                kind = BtnKind.Outline,
                icon = Icons.Rounded.SkipNext,
                compact = true,
                iconOnly = compact
            )
            BButton(
                T("Stop", "إيقاف"),
                { DialerService.send(ctx, DialerService.ACT_STOP) },
                Modifier.weight(1f),
                kind = BtnKind.Danger,
                icon = Icons.Rounded.Stop,
                compact = true,
                iconOnly = compact
            )
        }
    }
}

@Composable
private fun Launcher(act: MainActivity) {
    val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
    val selList = Store.lists.find { it.id == sel }
    val p = selList?.let { Store.prog(it) }

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            SectionLabel(T("Choose a campaign", "اختر الحملة"))
            if (Store.lists.isEmpty()) {
                Text(T("Create a campaign first.", "أنشئ حملة أولاً."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                BButton(T("Go to campaigns", "الذهاب إلى الحملات"), { Store.tab = 0 }, kind = BtnKind.Tonal, compact = true)
            }
            Store.lists.forEach { l ->
                val lp = Store.prog(l)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).clickable { Store.runListId = l.id }
                        .background(if (l.id == sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                        .padding(horizontal = Sp.s, vertical = Sp.xs),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = l.id == sel, onClick = { Store.runListId = l.id })
                    Column(Modifier.weight(1f)) {
                        Text(l.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(T("${lp.total} contacts · ${lp.remaining} left", "${lp.total} جهة · ${lp.remaining} متبقي"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (sel != null && p != null && p.total > 0) {
        val resumable = p.called > 0 && p.remaining > 0
        BButton(
            when {
                resumable -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                p.called > 0 -> T("Restart campaign", "إعادة تشغيل الحملة")
                else -> T("Start campaign", "ابدأ الحملة")
            },
            { act.startCampaign(sel, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
        )
        if (resumable) {
            BButton(T("Restart from the beginning", "ابدأ من الأول"), { act.startCampaign(sel, true) }, Modifier.fillMaxWidth(), kind = BtnKind.Outline, icon = Icons.Rounded.Refresh)
        }
    }

    val s = Store.cfg
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionLabel(T("Run setup", "إعدادات التشغيل"), Modifier.weight(1f))
                TextButton(onClick = { Store.openSettings() }) { Text(T("Change", "تعديل")) }
            }
            val gap = if (s.randomDelay) "${s.delaySec}–${s.delayMaxSec}s" else "${s.delaySec}s"
            InfoRow(Icons.Rounded.Timer, T("Delay between calls: $gap", "الانتظار بين المكالمات: $gap"))
            InfoRow(Icons.Rounded.Replay, T("Retries: ${s.retries} · Rounds: ${s.loops}", "إعادة المحاولة: ${s.retries} · الجولات: ${s.loops}"))
            InfoRow(Icons.Rounded.VolumeUp, T("Speaker & muted mic: ${if (s.autoSpeaker) "on" else "off"}", "السماعة وكتم المايك: ${if (s.autoSpeaker) "مفعّل" else "مغلق"}"))
        }
    }
}
