package com.o2dialer.app.core.domain.campaign

import com.o2dialer.app.core.domain.model.CallStatus
import com.o2dialer.app.core.domain.model.CampaignContact
import com.o2dialer.app.core.domain.model.CampaignStatistics

object CampaignStatisticsCalculator {
    fun calculate(entries: List<CampaignContact>): CampaignStatistics {
        val called = entries.count { it.status != CallStatus.PENDING && it.status != CallStatus.CALLING }
        val answered = entries.count { it.status == CallStatus.ANSWERED || it.status == CallStatus.DONE }
        val durations = entries.filter { it.duration > 0 }.map { it.duration.toLong() }
        val totalDuration = durations.sum()
        return CampaignStatistics(
            total = entries.size,
            called = called,
            answered = answered,
            noAnswer = entries.count { it.status == CallStatus.NO_ANSWER },
            failed = entries.count { it.status == CallStatus.FAILED },
            skipped = entries.count { it.status == CallStatus.SKIPPED },
            totalCallTimeSeconds = totalDuration,
            averageCallDurationSeconds = if (durations.isEmpty()) 0 else (totalDuration / durations.size).toInt()
        )
    }
}
