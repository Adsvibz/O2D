# O2Dialer — Full Project Audit

## 1. Project inventory

| Area | Current state | Assessment |
|---|---|---|
| Build | AGP 8.2.2, Kotlin 1.9.22, Compose compiler 1.5.8, compile/target 34 | Stable baseline, but dated dependency set |
| Module structure | Single `:app` module | Good for current product size; avoid premature multi-module split |
| Activity | One `MainActivity` | Correct direction |
| UI | Jetpack Compose + Material 3 | Good foundation |
| State | Global `Store` + Compose mutable state | Main architectural weakness |
| Persistence | SharedPreferences + JSON | Functional, but tightly coupled; now behind repositories |
| Calling | Foreground `DialerService` + TelecomManager/TelephonyManager | Valuable working behavior; preserve behind a boundary |
| Navigation | Integer tab state in global store | Replace with typed navigation state |
| Campaign logic | Mostly embedded in service | Extract to domain engine |
| Permissions | Activity-owned request launchers | Functional but feature-coupled |
| Theme | Central tokens/theme | Good starting point |
| CI | GitHub Actions, Gradle 8.5, Java 17 | Good; artifact was renamed to O2Dialer |

## 2. Gradle audit

### Strengths
- AndroidX is enabled.
- Java/Kotlin target 17 is appropriate.
- Compose BOM is used, preventing individual Compose version drift.
- Coroutines are already present.
- No unnecessary dependency explosion.

### Changes made
- Application namespace/id changed to `com.o2dialer.app`.
- Project name changed to `O2Dialer`.
- Lifecycle ViewModel + lifecycle-aware Compose collection dependencies were added because the target architecture explicitly requires ViewModel-driven state and lifecycle-aware collection.

### Remaining upgrade decision
Do not blindly upgrade every dependency in this command. First stabilize architecture, then run a dedicated dependency/security upgrade pass with actual build/test feedback.

## 3. Manifest and OS integration

### Current permissions
- `CALL_PHONE`
- `READ_PHONE_STATE`
- `READ_CALL_LOG`
- `ANSWER_PHONE_CALLS`
- `READ_CONTACTS`
- `MODIFY_AUDIO_SETTINGS`
- `FOREGROUND_SERVICE`
- `FOREGROUND_SERVICE_SPECIAL_USE`
- `POST_NOTIFICATIONS`
- `WAKE_LOCK`
- `VIBRATE`

The app should continue to request only the permissions required for the enabled feature. `READ_CALL_LOG` and `ANSWER_PHONE_CALLS` are particularly sensitive and should be feature-gated in later work.

The foreground service is declared as `specialUse` with subtype `sequential_auto_dialer`. That is a deliberate platform integration and should not be casually replaced with a generic service type.

## 4. Activity / lifecycle audit

`MainActivity` currently owns:
- permission launchers
- campaign start orchestration
- screen-keep-awake behavior
- drawer/navigation state
- back navigation
- root composition

The first foundation step moves root observable state toward `AppViewModel` + `StateFlow`. The Activity should eventually only provide OS entry points and Compose content.

## 5. Compose audit

The UI is visually centralized through `DesignSystem.kt`, `Theme.kt`, and reusable components. This is a strong base for the later O2Dialer visual rebuild.

The largest issue is state ownership:
- screens read `Store.*` directly;
- event handlers mutate `Store.*` directly;
- navigation, persistence and runtime state are all in the same object.

The migration target is:

`Screen -> ViewModel event -> domain/repository -> immutable UiState -> Screen`

## 6. Campaign execution audit

The existing campaign implementation is valuable and should be preserved semantically.

Important behavior identified:
- pending-number queue
- optional shuffle
- retry scheduling
- repeated rounds/loops
- quiet-hour window
- SIM phone-account selection
- 25-second no-call timeout
- telephony call-state monitoring
- optional call-log based answer detection
- max call duration
- speaker/microphone handling
- stage/feedback workflow
- foreground notification controls
- partial wake lock
- completion notification + vibration

These behaviors should be treated as regression-protected product behavior during the rebuild.

### Architectural problem
`DialerService` currently owns both OS integration and campaign decisions. This makes the campaign algorithm hard to unit test and creates a direct dependency from runtime logic to UI/global state.

A domain `CampaignEngine` was added as the first extraction seam. The next step is to migrate the service to it without changing campaign semantics.

## 7. Data audit

The old Store persisted configuration, lists and logs directly with JSON. That behavior is retained, but persistence now sits behind:
- `SettingsRepository`
- `CampaignRepository`
- `AppContainer`

This avoids a premature database migration and keeps the current on-device data format intact.

## 8. Navigation audit

Current integer tabs are simple but fragile. They encode screen identity as magic numbers and require global back-state (`prevTab`).

Target:
- typed destinations
- a navigation state owned by presentation
- explicit back-stack behavior
- campaign completion events handled by the root ViewModel

Do not introduce Navigation Compose until the screen graph is actually migrated; adding it before that would create a second navigation system.

## 9. Performance audit

### Positive
- Lazy lists are used for contact/entry lists.
- Heavy contact loading is dispatched to `Dispatchers.IO`.
- Calling execution is kept in a foreground service rather than Compose.
- The app already uses a partial wake lock during campaigns.

### Risks
- Entire lists/logs are serialized on each mutation.
- `Store` exposes large mutable lists globally, increasing recomposition risk.
- Campaign progress is represented by repeated full-list scans.
- Service notifications are rebuilt on state updates.
- Main-thread `Handler` timing is harder to test and reason about than a coroutine-based state machine.

The performance work should follow profiling, not assumptions. Do not optimize by adding libraries before measuring.

## 10. Safety / reliability audit

The most important reliability rule is to preserve the existing telephony semantics while changing architecture.

Regression tests should cover:
- duplicate number rejection
- resume after process recreation
- retry counts
- loops
- quiet-hour transitions
- no-answer vs answered detection
- call-state callback ordering
- service destruction while a call is active
- stage timeout
- explicit stop/pause/resume
- SIM selection
- missing permissions

## 11. Current migration status

### Done in Command 01
- O2Dialer branding/application identity
- repository boundaries
- application dependency container
- runtime immutable state channel
- AppViewModel foundation
- domain CampaignEngine seam
- architecture/audit documentation
- no unnecessary third-party libraries

### Intentionally deferred
- screen-by-screen visual redesign
- full Store removal
- full ViewModel migration of every screen
- full service-to-domain-engine migration
- navigation rewrite
- persistence technology replacement

This sequencing minimizes the chance of destroying working telephony/campaign behavior while rebuilding the architecture.


## Command 09 — Calling engine audit

### Fixed
- Campaign queue was process-local; it is now persisted.
- Retry counters were process-local; they are now persisted.
- Current contact was process-local; it is now persisted as a durable claim.
- Resume could rebuild from contact statuses; resume now restores the exact journal.
- Service recreation could leave `ACT_RESUME` without an initialized campaign; resume now rehydrates the session.
- `onDestroy()` previously converted an active campaign to `FINISHED`; it now preserves the journal for recovery.
- Pause lost timing information; `nextAt` is retained so resume continues the same timing point.
- Runtime persistence now uses `commit()` for crash-critical checkpoints.
- Telephony failures are isolated from campaign orchestration and do not blindly terminate the whole campaign.
