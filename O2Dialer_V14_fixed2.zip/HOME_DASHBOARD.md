# O2Dialer Home Dashboard — Command 06

The Home screen is now a dashboard-first workspace designed for one-second comprehension.

## Hierarchy

1. Active campaign becomes the dominant element while a campaign is running.
2. Today's activity is summarized in a compact metric strip rather than a wall of cards.
3. Remaining calls are surfaced separately for the active campaign.
4. Recent activity provides immediate context without overwhelming the dashboard.
5. Workspace shortcuts remain secondary.

## Empty state

When no campaigns exist, Home becomes an onboarding-style state with one primary action: **Create Campaign**. The action enters the existing campaign creation flow through Lists, preserving current functionality.

## Data source

Home observes the immutable `AppUiState` through `AppViewModel` and `collectAsStateWithLifecycle()`. It does not read mutable `Store` collections directly.

Derived metrics are calculated locally from the immutable snapshot:

- total campaigns
- today's calls
- today's answered calls
- today's unanswered calls
- answer rate
- active campaign progress
- active campaign remaining calls
- recent activity

No new dependency was introduced.
