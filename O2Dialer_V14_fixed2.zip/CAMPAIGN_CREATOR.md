# O2Dialer Campaign Creator — COMMAND 08

Version 3.5 / versionCode 8.

The Campaigns area now provides a workflow-oriented creator instead of treating campaign setup as a settings form.

## Workflow
1. Campaign identity
2. Contact list
3. SIM selection
4. Calling behavior
5. Retry behavior
6. Timing
7. Quiet hours
8. Audio behavior
9. Completion behavior

A live summary is shown before launch. The primary action is **Start Campaign** and the secondary action is **Save Campaign**.

Campaign profiles are persisted independently from global settings and keyed to their contact list. Legacy global settings remain compatible and are applied when a saved campaign is started.

Audio configuration now separates speaker behavior from microphone mute behavior while retaining compatibility with the existing calling service.
