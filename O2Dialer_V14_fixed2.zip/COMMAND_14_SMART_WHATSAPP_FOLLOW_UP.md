# COMMAND 14 — Smart WhatsApp Follow-up

## Behavior
- Potential, Call Back, and WhatsApp stages expose a WhatsApp action.
- Numbers are normalized through the existing country-aware `smartNumber()` path.
- Only international-looking numbers in the E.164 digit range (8–15 digits) with a recognized country-code prefix are opened.
- The action prefers the installed WhatsApp package, then WhatsApp Business.
- If neither is available, the feature falls back to an Android `wa.me` handler when one exists; otherwise it shows a non-blocking error notification.
- Invalid or unsupported numbers never launch an intent and never crash the app.
- Android package visibility is declared for both WhatsApp packages.

## UX
The action is a compact green chat button with an accessible content description. It is available directly from Results and Lists for the three requested stages, avoiding unnecessary navigation.
