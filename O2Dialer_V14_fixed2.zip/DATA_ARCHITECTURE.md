# O2Dialer — Command 05 Data Architecture

## Goal

Replace fragile global mutable business state with immutable domain models and repository boundaries while preserving the existing SharedPreferences data keys and application ID so an installed O2Dialer build can be upgraded in place.

## Layers

```text
Compose UI
   ↓ events / immutable UI state
ViewModels / application facade
   ↓
Domain models + pure campaign calculations
   ↓ repository interfaces
Persistence implementation (currently SharedPreferences)
   ↓
Existing O2Dialer preference store
```

The calling engine remains independent of Compose. Android telephony is an adapter around the campaign domain rather than a source of UI state.

## Canonical immutable models

- `Contact`
- `ContactList`
- `Campaign`
- `CampaignContact`
- `CallAttempt`
- `CallResult`
- `CallStage`
- `Feedback`
- `CampaignStatistics`
- `AppSettings`
- `CampaignRuntimeState`
- `TelephonyState`

Legacy names (`Entry`, `CallList`, `Cfg`, `CampState`, `LogItem`) are compatibility typealiases so existing campaign/telephony code can migrate incrementally without changing persisted data or breaking behavior.

## Repository boundaries

`DataRepository` is the current aggregate persistence boundary and is exposed through the narrower `SettingsRepository` and `CampaignRepository` interfaces. The implementation uses the existing `o2dialer` SharedPreferences file and existing `cfg`, `lists`, and `log` keys.

A dedicated `campaign_runtime` record now persists temporary campaign execution state. On application restart, an interrupted RUNNING/WAITING campaign is recovered into PAUSED state so the user can explicitly resume it rather than silently losing progress or starting duplicate calls.

This interface is intentionally replaceable: a future Room/database implementation can be introduced without changing Compose screens or the telephony engine.

## State separation

- **Persisted data:** contacts/lists, call history, settings, campaign runtime snapshot.
- **Temporary campaign state:** queue, retry counters, current call, telephony callbacks, wake lock — owned by the calling service/domain engine.
- **UI state:** navigation, selected IDs, drawer state, toasts and screen presentation — exposed through immutable `AppUiState`.
- **Telephony state:** call-state callbacks and active call timing — owned by `DialerService` and represented by `TelephonyState` at the domain boundary.

`Store` is retained only as a compatibility/application facade during migration. Screens call its intent-level operations instead of directly writing repository records; new code should use ViewModels and repositories.

## Upgrade safety

The `applicationId` remains `com.o2dialer.app`, the SharedPreferences file remains `o2dialer`, and existing preference keys remain intact. Version code is incremented from 4 to 5. Android will treat a signed build with the same application ID and signing key as an update, preserving app data; it must not be uninstalled first.
