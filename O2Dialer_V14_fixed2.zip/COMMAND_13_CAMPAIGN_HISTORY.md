# COMMAND 13 — Campaign History

## Durable archive
Completed/finished campaign sessions are archived independently from the live runtime queue. Each archive stores:

- campaign name
- session id
- start/end timestamps
- completion state
- complete contact snapshots
- call status, duration, timestamp and attempts
- stage and feedback

## UX
The History destination is a calm list of finished campaigns. Each card exposes total contacts, answered, answer rate, unanswered count and campaign duration. Opening a card shows the complete historical result set with filters for answered, unanswered, failed and skipped calls.

## Data safety
History is persisted under `campaign_history_v1` and is not tied to the active campaign runtime key. The archive is therefore still available after the live session is cleared or a new campaign is started. Up to 100 archived sessions are retained.
