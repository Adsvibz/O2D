# O2Dialer Design System — Command 03

The O2Dialer UI is built around a small, explicit visual language designed for a premium productivity/SaaS experience: calm surfaces, strong hierarchy, restrained color, generous spacing, and fast interaction feedback.

## Source of truth

- `app/src/main/java/com/o2dialer/app/DesignTokens.kt` — all visual tokens.
- `app/src/main/java/com/o2dialer/app/Theme.kt` — Material 3 color schemes, typography, shapes and system-bar treatment.
- `app/src/main/java/com/o2dialer/app/O2Components.kt` — reusable product components.
- `app/src/main/java/com/o2dialer/app/DesignSystem.kt` — existing compatibility layer and legacy components that remain available while screens are migrated.

## Tokens

### Color
`O2Colors` contains brand, light/dark surfaces, semantic status colors, WhatsApp, and campaign-stage accents.

### Typography
`O2TypographyMetrics` defines the size scale used to construct the Material 3 typography. Outfit remains the Latin display/UI font; Arabic falls back to the system family.

### Spacing
`O2Spacing` uses a compact 4/8/12/16/20/24/32 rhythm, plus larger layout constants.

### Shape
`O2Radii` defines small, medium, large, extra-large and pill shapes. Screens should not create arbitrary corner radii.

### Interaction
`O2Motion` defines standard animation timings. `O2ButtonSizes`, `O2IconSizes`, `O2CardSizes`, `O2Elevation`, and `O2Borders` define interaction and component geometry.

### Layout
`O2Layout` defines standard screen padding and content-width constraints. `Responsive` remains available for the current screen layer.

## Components

`O2Components.kt` provides the reusable building blocks required by future screens:

- `O2AppBar`, `O2BackAppBar`
- `O2NavigationItem`
- `O2Card`
- `O2Button`, `O2IconButton`
- `O2TextField`, `O2SearchField`
- `O2SegmentedControl`
- `O2Chip`, `O2Badge`
- `O2ProgressBar`, `O2ProgressRing`
- `O2EmptyState`
- `O2ConfirmationDialog`
- `O2BottomSheet`
- `O2StatusIndicator`
- `O2ListRow`
- `O2StatCard`

## Migration rule

New UI must use `O2*` components and tokens. Do not introduce screen-local colors, spacing, radii, elevations, button heights, or animation durations.

The existing `B*`/legacy components are intentionally retained as a compatibility layer for the current application. They consume the centralized token layer where practical and can be migrated screen-by-screen without changing campaign or telephony behavior.

## Product direction

The system intentionally avoids gradients, shadows, decorative surfaces, or animation unless they communicate hierarchy or state. The brand gradient remains available for high-value hero moments, while ordinary application surfaces use flat Material 3 surfaces and subtle borders.
