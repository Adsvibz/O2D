# COMMAND 10 — Live Campaign Experience

The live campaign screen is now a focused operational dashboard.

## UX priorities
1. Current contact is the visual center of gravity.
2. During a call, the user sees the contact name, number, call state and live elapsed duration without scrolling.
3. Progress is shown both as a percentage ring and a full-width progress bar.
4. Campaign counters are separated into Total, Called, Remaining, Answered, Unanswered and Failed.
5. Controls are limited to Pause/Resume, Skip and Stop.
6. A compact "what happens next" explanation is always visible during an active session.
7. The screen remains usable on compact devices by keeping secondary information below the primary call surface.

## State source
The UI is a projection of `Store.camp` plus the persisted campaign list. It does not own campaign execution, queue state, retry state, or telephony behavior.

## Duration
Duration is derived from the persisted `offhookAt`/`callStartedAt` timestamps, so the visible timer is based on engine state rather than a Compose-only stopwatch.

## COMMAND 11 — Post-call workflow

The live campaign screen now owns the post-call classification flow when the campaign engine is awaiting a result. Five stage choices are visible simultaneously: Potential, Not Interested, Call Back, WhatsApp, and Voicemail. Each has its own icon/accent, selected state, and accessible semantic role.

Potential, Call Back, and WhatsApp reveal an inline feedback field and a single Save & continue action. Not Interested and Voicemail commit immediately on selection, minimizing interaction for high-frequency campaign work. The workflow stays in the live screen and does not require navigation or a modal sheet.

The existing persisted `stage` and `feedback` fields remain the single source of truth, and completion is handed back to the campaign service through `ACT_STAGE_DONE` only after the result is committed.
