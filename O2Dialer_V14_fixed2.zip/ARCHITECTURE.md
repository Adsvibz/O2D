# O2Dialer — Architecture Reset (Command 01)

## Audit verdict

The existing app contains valuable campaign/telephony behavior, but its boundaries are too tightly coupled:

- `Store` is a process-wide mutable singleton that mixes persistence, domain operations, UI navigation, Compose state, toasts, permissions and campaign runtime state.
- `Models.kt` contains both domain models and Android/JSON/Compose concerns.
- `MainActivity` owns permission workflows, campaign commands and navigation state.
- `DialerService` contains telephony integration, campaign orchestration, persistence calls, UI state mutation and notification rendering in one class.
- Screens read and mutate global state directly instead of receiving immutable state and dispatching intents.
- Persistence is synchronous `SharedPreferences` + JSON and is executed from UI/service paths without a repository boundary.
- Campaign timing uses a main-thread `Handler`; this is workable for a foreground service but makes the execution model difficult to test and reason about.
- Navigation is integer-tab based and global.
- `T()` reads global mutable configuration, so even presentation text is coupled to the store.
- Permissions are requested as a single bundle even though some permissions are optional depending on features.
- There is no explicit application-level dependency container or lifecycle-aware state pipeline.

## Target architecture

```text
                 ┌───────────────────────────┐
                 │       Compose UI          │
                 │ Screens / Components      │
                 └─────────────┬─────────────┘
                               │ UI intents
                               ▼
                 ┌───────────────────────────┐
                 │       ViewModels          │
                 │ immutable UiState         │
                 │ StateFlow + events        │
                 └─────────────┬─────────────┘
                               │
                               ▼
                 ┌───────────────────────────┐
                 │          Domain           │
                 │ campaign rules / models   │
                 │ no Compose / UI imports   │
                 └───────┬─────────┬─────────┘
                         │         │
             repository │         │ calling ports
                         ▼         ▼
              ┌──────────────┐  ┌────────────────┐
              │    Data      │  │ Calling engine │
              │ repositories │  │ + telephony    │
              └──────┬───────┘  └───────┬────────┘
                     │                  │
                     ▼                  ▼
               SharedPreferences   Android Telecom/
               JSON (temporary)    Telephony APIs

Foreground service is an Android execution adapter. It owns lifecycle and OS callbacks,
while campaign decisions belong to the domain engine.
```

## Foundation implemented in this reset

1. Established the O2Dialer product identity across Gradle application identity, app label, storage namespace, and CI artifact naming.
2. Added an application dependency container so repositories and domain services have explicit ownership and lifecycle.
3. Added repository boundaries for settings and campaign persistence without introducing a new dependency.
4. Added a domain-level campaign engine contract/model that can be tested without Compose or Android UI.
5. Kept the current `Store` as a compatibility adapter during this first migration step. Existing screens therefore keep their working behavior while the new boundaries are introduced underneath them.
6. Kept the foreground `DialerService` and telephony behavior intact for this command; the next migration step is to make the service an adapter around the domain campaign engine rather than the engine itself.

## Deliberately not changed yet

- Visual redesign.
- Campaign semantics, retry rules, call-result detection, SIM selection, speaker handling or notification behavior.
- Screen-by-screen navigation rewrite.
- Database migration.

This is intentional: the first reset establishes stable seams before changing behavior.

## Dependency policy

No new third-party library was added. Existing Compose, AndroidX and coroutines dependencies remain the baseline. SharedPreferences/JSON is retained behind repositories until a measured need for a database/DataStore migration exists.

## Build validation

The source tree was statically audited and the CI configuration was updated. A local Gradle build could not be executed in this environment because Gradle is not installed and outbound network access is unavailable, so no claim of a locally verified APK build is made.


## Command 09 — Calling engine hardening

The campaign execution path now follows a durable-engine / Android-adapter split:

```text
Compose UI
   │ commands / immutable state
   ▼
Runtime campaign journal
   │
   ▼
CampaignEngine  ───────────────► persisted queue + cursor + retry state
   │
   │ PlaceCall / Wait / Stage / Completed
   ▼
DialerService (Android adapter)
   │
   ▼
TelecomManager / TelephonyManager
```

The persisted `CampaignRuntimeState` is now an execution journal, not merely UI state. It records:

- exact remaining queue order
- retry counters per contact
- current claimed contact
- execution phase
- loop number
- next-action timestamp
- call start/off-hook timestamps
- selected SIM slot
- session ID and checkpoint timestamp

A campaign is therefore **resumed from its journal**, not reconstructed from contact status. Rebuilding the queue is reserved for a new campaign or an explicit restart.

Recovery also distinguishes an interrupted `CALLING` claim from a normal pending contact. The service checks the actual phone state before deciding whether to re-bind an active call or return the claimed contact to the front of the queue.

Runtime checkpoints use synchronous persistence because losing the queue cursor immediately after a call transition could otherwise cause duplicate or skipped calls.

The existing Telecom/Telephony behavior was preserved and isolated as the Android execution adapter. Invalid numbers, missing permissions, unavailable SIM accounts, unexpected call termination and service recreation are handled without making Compose responsible for telephony execution.
